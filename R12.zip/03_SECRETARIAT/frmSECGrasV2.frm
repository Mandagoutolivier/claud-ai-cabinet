VERSION 5.00
Begin VB.UserForm frmSECGrasV2 
   Caption         =   "Validation du gras"
   ClientHeight    =   3300
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   7200
   StartUpPosition =   1  'CenterOwner
   Begin VB.Label lblInstruction
      Caption         =   "Passage en gras inconnu :"
      Height          =   315
      Left            =   240
      Top             =   180
      Width           =   6480
   End
   Begin VB.TextBox txtTerme
      Height          =   900
      Left            =   240
      MultiLine       =   -1  'True
      ScrollBars      =   2  'fmScrollBarsVertical
      TabIndex        =   0
      Top             =   540
      Width           =   6480
   End
   Begin VB.Label lblAide
      Caption         =   "Choisissez le devenir de ce gras. Le texte peut etre corrige avant validation."
      Height          =   420
      Left            =   240
      Top             =   1560
      Width           =   6480
   End
   Begin VB.CommandButton cmdMedicament
      Caption         =   "M�dicaments"
      Height          =   480
      Left            =   240
      TabIndex        =   1
      Top             =   2220
      Width           =   1500
   End
   Begin VB.CommandButton cmdExpression
      Caption         =   "Expression"
      Height          =   480
      Left            =   1860
      TabIndex        =   2
      Top             =   2220
      Width           =   1500
   End
   Begin VB.CommandButton cmdPonctuel
      Caption         =   "Ponctuel"
      Height          =   480
      Left            =   3480
      TabIndex        =   3
      Top             =   2220
      Width           =   1500
   End
   Begin VB.CommandButton cmdAnnulerGras
      Caption         =   "Annuler"
      Height          =   480
      Left            =   5100
      TabIndex        =   4
      Top             =   2220
      Width           =   1620
   End
End
Attribute VB_Name = "frmSECGrasV2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public Choix As Long
Public TermeChoisi As String

Public Sub Preparer(ByVal terme As String)
    Choix = SEC_CHOIX_AUCUN
    TermeChoisi = terme
    txtTerme.Text = terme
    txtTerme.SelStart = 0
    txtTerme.SelLength = Len(txtTerme.Text)
End Sub

Private Sub cmdMedicament_Click()
    TermeChoisi = Trim$(txtTerme.Text)
    Choix = SEC_CHOIX_MEDICAMENT
    Me.Hide
End Sub

Private Sub cmdExpression_Click()
    TermeChoisi = Trim$(txtTerme.Text)
    Choix = SEC_CHOIX_EXPRESSION
    Me.Hide
End Sub

Private Sub cmdPonctuel_Click()
    TermeChoisi = Trim$(txtTerme.Text)
    Choix = SEC_CHOIX_PONCTUEL
    Me.Hide
End Sub

Private Sub cmdAnnulerGras_Click()
    TermeChoisi = Trim$(txtTerme.Text)
    Choix = SEC_CHOIX_ANNULER
    Me.Hide
End Sub

Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = 0 Then
        Cancel = True
        Choix = SEC_CHOIX_AUCUN
        Me.Hide
    End If
End Sub
