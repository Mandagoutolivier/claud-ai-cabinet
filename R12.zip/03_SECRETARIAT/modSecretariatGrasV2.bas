Attribute VB_Name = "modSecretariatGrasV2"
Option Explicit

'===============================================================================
' SECRETARIAT - GRAS V2 : RECONSTRUCTION COMPLETE AVANT IMPRESSION
'
' 100 % local / NAS. Aucun appel API.
' - Alt+V : validation et reconstruction du gras, sans imprimer.
' - Ctrl+P : validation et reconstruction, puis boite d'impression.
' - FilePrintDefault : validation puis impression rapide.
' - compare le gras actuel au gras attendu avant toute modification ;
' - ouvre le formulaire 4 boutons pour chaque gras inconnu ;
' - detecte un document anormalement tout en gras ;
' - remet les zones medicales en non-gras puis reapplique toutes les regles.
'===============================================================================

Private Const SEC_DOSSIER_CONFIG As String = _
    "\\DS224\home\logiciel_chatgpt_cabinet"
Private Const SEC_DOSSIER_SORTIE As String = _
    "\\DS224\home\sortiedragon"
Private Const SEC_FICHIER_MEDICAMENTS As String = _
    "\\DS224\home\logiciel_chatgpt_cabinet\medicaments.txt"
Private Const SEC_FICHIER_EXPRESSIONS As String = _
    "\\DS224\home\logiciel_chatgpt_cabinet\termes_gras.txt"
Private Const SEC_FICHIER_EXAMENS As String = _
    "\\DS224\home\logiciel_chatgpt_cabinet\examens_complementaires.txt"
Private Const SEC_FICHIER_JOURNAL As String = _
    "\\DS224\home\logiciel_chatgpt_cabinet\journal_apprentissage.txt"
Private Const SEC_FICHIER_VERROU As String = _
    "\\DS224\home\logiciel_chatgpt_cabinet\dictionnaires_gras_v2.lock"

Private Const SEC_PREFIXE_ZONE As String = "MCP_ZONE_MED_"
Private Const SEC_VAR_IDENTITE As String = "MCP_IDENTITE_PATIENT_V1"
Private Const SEC_VAR_PONCTUELS As String = "MCP_GRAS_PONCTUEL_V2"
Private Const SEC_VAR_STATUT As String = "MCP_STATUT_R12"
Private Const SEC_SEPARATEUR As String = "|||SEC_V2|||"
Private Const SEC_MARQUEUR_BROUILLON As String = _
    "[[A_COMPLETER_AVANT_IMPRESSION"

Public Const SEC_CHOIX_AUCUN As Long = 0
Public Const SEC_CHOIX_MEDICAMENT As Long = 1
Public Const SEC_CHOIX_EXPRESSION As Long = 2
Public Const SEC_CHOIX_PONCTUEL As Long = 3
Public Const SEC_CHOIX_ANNULER As Long = 4

Private mDernierTraitementOK As Boolean

'-------------------------------------------------------------------------------
' COMMANDES PUBLIQUES
'-------------------------------------------------------------------------------

Public Sub SEC_ValiderGrasSansImprimer()
    If SEC_ValiderEtReconstruireGras() Then
        ActiveDocument.Save
    End If
End Sub

Public Sub SEC_MettreEnGras()
    SEC_ValiderGrasSansImprimer
End Sub

Public Sub SEC_ValiderEtFermer()
    If SEC_ValiderEtReconstruireGras() Then
        ActiveDocument.Save
        ActiveDocument.Close SaveChanges:=wdDoNotSaveChanges
    End If
End Sub

Public Sub SEC_ImprimerAvecValidation()

    On Error GoTo GestionErreur

    If Documents.Count = 0 Then Exit Sub

    If SEC_EstCourrierSortieDragon(ActiveDocument) Then
        If Not SEC_ValiderEtReconstruireGras() Then Exit Sub
        ActiveDocument.Save
    End If

    Dialogs(wdDialogFilePrint).Show
    Exit Sub

GestionErreur:
    MsgBox "Impression interrompue :" & vbCrLf & _
        Err.Number & " - " & Err.Description, _
        vbExclamation, "Gras V2"
End Sub

Public Sub FilePrint()
    SEC_ImprimerAvecValidation
End Sub

Public Sub SEC_ImpressionRapideAvecValidation()

    On Error GoTo GestionErreur

    If Documents.Count = 0 Then Exit Sub

    If SEC_EstCourrierSortieDragon(ActiveDocument) Then
        If Not SEC_ValiderEtReconstruireGras() Then Exit Sub
        ActiveDocument.Save
    End If

    ActiveDocument.PrintOut Background:=False
    Exit Sub

GestionErreur:
    MsgBox "Impression rapide interrompue :" & vbCrLf & _
        Err.Number & " - " & Err.Description, _
        vbExclamation, "Gras V2"
End Sub

Public Sub FilePrintDefault()
    SEC_ImpressionRapideAvecValidation
End Sub

Public Sub SEC_InstallerRaccourcisGrasV2()

    On Error GoTo GestionErreur

    CustomizationContext = NormalTemplate

    On Error Resume Next
    FindKey(BuildKeyCode(wdKeyControl, wdKeyP)).Clear
    FindKey(BuildKeyCode(wdKeyAlt, wdKeyV)).Clear
    On Error GoTo GestionErreur

    KeyBindings.Add _
        KeyCategory:=wdKeyCategoryMacro, _
        Command:="SEC_ImprimerAvecValidation", _
        KeyCode:=BuildKeyCode(wdKeyControl, wdKeyP)

    KeyBindings.Add _
        KeyCategory:=wdKeyCategoryMacro, _
        Command:="SEC_ValiderGrasSansImprimer", _
        KeyCode:=BuildKeyCode(wdKeyAlt, wdKeyV)

    NormalTemplate.Save

    MsgBox "Raccourcis Gras V2 installes :" & vbCrLf & vbCrLf & _
        "Ctrl+P : validation puis impression" & vbCrLf & _
        "Alt+V : validation sans impression", _
        vbInformation, "Gras V2"
    Exit Sub

GestionErreur:
    MsgBox "Installation des raccourcis impossible :" & vbCrLf & _
        Err.Number & " - " & Err.Description, _
        vbExclamation, "Gras V2"
End Sub

Public Sub SEC_InstallerInterceptionImpression()
    SEC_InstallerRaccourcisGrasV2
End Sub

Public Sub SEC_VerifierInstallation()

    Dim message As String
    Dim formOK As Boolean

    message = "GRAS V2" & vbCrLf & vbCrLf
    message = message & "Ctrl+P -> " & _
        FindKey(BuildKeyCode(wdKeyControl, wdKeyP)).Command & vbCrLf
    message = message & "Alt+V -> " & _
        FindKey(BuildKeyCode(wdKeyAlt, wdKeyV)).Command & vbCrLf & vbCrLf

    message = message & SEC_EtatFichier(SEC_FICHIER_MEDICAMENTS) & vbCrLf
    message = message & SEC_EtatFichier(SEC_FICHIER_EXPRESSIONS) & vbCrLf
    message = message & SEC_EtatFichier(SEC_FICHIER_EXAMENS) & vbCrLf
    message = message & SEC_EtatFichier(SEC_FICHIER_JOURNAL) & vbCrLf

    On Error Resume Next
    formOK = (frmSECGrasV2.Name = "frmSECGrasV2")
    On Error GoTo 0

    message = message & vbCrLf & "Formulaire 4 boutons : " & _
        IIf(formOK, "OK", "ABSENT")

    MsgBox message, IIf(formOK, vbInformation, vbExclamation), "Gras V2"
End Sub

Public Sub SEC_TesterInstallation()
    SEC_VerifierInstallation
End Sub

Public Sub SEC_TesterDialogue()

    Dim choix As Long
    Dim terme As String

    terme = "expression medicale fictive"
    choix = SEC_DemanderClassement(terme)

    MsgBox "Choix retourne : " & CStr(choix) & vbCrLf & _
        "Terme : " & terme, vbInformation, "Test formulaire Gras V2"
End Sub

Public Sub SEC_DiagnostiquerGrasInconnus()

    Dim doc As Document
    Dim zones As Collection
    Dim candidats As Object
    Dim attendu() As Boolean
    Dim dMed As Object
    Dim dExp As Object
    Dim dExam As Object
    Dim cle As Variant
    Dim message As String

    If Documents.Count = 0 Then Exit Sub
    Set doc = ActiveDocument

    If Not SEC_ConfigurationDisponible(True) Then Exit Sub

    Set zones = SEC_ObtenirZonesMedicales(doc)
    If zones.Count = 0 Then
        MsgBox "Aucune zone medicale n'a ete identifiee.", _
            vbExclamation, "Diagnostic Gras V2"
        Exit Sub
    End If

    ReDim attendu(0 To doc.Content.End + 1)
    Set dMed = SEC_ChargerDictionnaire(SEC_FICHIER_MEDICAMENTS, True)
    Set dExp = SEC_ChargerDictionnaire(SEC_FICHIER_EXPRESSIONS, False)
    Set dExam = SEC_ChargerExamens()

    SEC_ConstruireMasqueAttendu doc, zones, dMed, dExp, dExam, attendu
    Set candidats = SEC_CollecterCandidats(doc, zones, attendu)

    message = CStr(candidats.Count) & " passage(s) en gras inconnu(s)." & vbCrLf
    For Each cle In candidats.Keys
        message = message & vbCrLf & "- " & CStr(cle)
    Next cle

    MsgBox message, vbInformation, "Diagnostic Gras V2"
End Sub

'-------------------------------------------------------------------------------
' MOTEUR CENTRAL
'-------------------------------------------------------------------------------

Private Function SEC_ValiderEtReconstruireGras() As Boolean

    Dim doc As Document
    Dim zones As Collection
    Dim dMed As Object
    Dim dExp As Object
    Dim dExam As Object
    Dim candidats As Object
    Dim ponctuels As Object
    Dim attendu() As Boolean
    Dim cle As Variant
    Dim terme As String
    Dim termeChoisi As String
    Dim choix As Long
    Dim ratio As Double
    Dim reponse As VbMsgBoxResult

    On Error GoTo GestionErreur

    SEC_ValiderEtReconstruireGras = False
    mDernierTraitementOK = False

    If Documents.Count = 0 Then Exit Function
    Set doc = ActiveDocument

    If Not SEC_EstCourrierSortieDragon(doc) Then
        MsgBox "Cette validation est reservee aux courriers situes dans :" & _
            vbCrLf & SEC_DOSSIER_SORTIE, vbExclamation, "Gras V2"
        Exit Function
    End If

    If SEC_BrouillonNonComplete(doc) Then Exit Function
    If Not SEC_ConfigurationDisponible(True) Then Exit Function

    Set zones = SEC_ObtenirZonesMedicales(doc)
    If zones.Count = 0 Then
        MsgBox "Aucune zone medicale n'a ete identifiee. " & _
            "La validation est interrompue pour eviter de modifier l'en-tete.", _
            vbExclamation, "Gras V2"
        Exit Function
    End If

    Application.ScreenUpdating = False
    Application.StatusBar = "Analyse du gras actuel..."

    Set dMed = SEC_ChargerDictionnaire(SEC_FICHIER_MEDICAMENTS, True)
    Set dExp = SEC_ChargerDictionnaire(SEC_FICHIER_EXPRESSIONS, False)
    Set dExam = SEC_ChargerExamens()
    Set ponctuels = SEC_ChargerPonctuelsDocument(doc)

    ReDim attendu(0 To doc.Content.End + 1)
    SEC_ConstruireMasqueAttendu doc, zones, dMed, dExp, dExam, attendu
    SEC_MarquerDictionnaireDansMasque doc, zones, ponctuels, attendu

    ratio = SEC_ProportionGras(doc, zones)

    If ratio >= 0.35 Then
        Application.ScreenUpdating = True
        Application.StatusBar = False

        reponse = MsgBox( _
            "Une proportion anormalement importante du corps medical est en gras (" & _
            Format$(ratio, "0%") & ")." & vbCrLf & vbCrLf & _
            "OUI : reinitialiser tout le gras selon les dictionnaires" & vbCrLf & _
            "NON : conserver exceptionnellement le gras actuel" & vbCrLf & _
            "ANNULER : interrompre la validation", _
            vbYesNoCancel + vbExclamation, "Anomalie globale de gras")

        If reponse = vbCancel Then Exit Function
        If reponse = vbNo Then
            doc.Save
            SEC_ValiderStatutDocument doc
            SEC_ValiderEtReconstruireGras = True
            mDernierTraitementOK = True
            Exit Function
        End If

        Application.ScreenUpdating = False
    Else
        Set candidats = SEC_CollecterCandidats(doc, zones, attendu)

        For Each cle In candidats.Keys
            terme = CStr(cle)
            termeChoisi = terme

            Application.ScreenUpdating = True
            Application.StatusBar = False
            choix = SEC_DemanderClassement(termeChoisi)

            If choix = SEC_CHOIX_AUCUN Then Exit Function

            Application.ScreenUpdating = False
            Application.StatusBar = "Classement du nouveau gras..."

            Select Case choix
                Case SEC_CHOIX_MEDICAMENT
                    termeChoisi = UCase$(SEC_NettoyerNomMedicament(termeChoisi))
                    If termeChoisi <> "" Then
                        If Not SEC_AjouterLigneSecurisee( _
                            SEC_FICHIER_MEDICAMENTS, termeChoisi) Then Exit Function
                        SEC_Journaliser "AJOUT_MEDICAMENT", termeChoisi, doc.Name
                        dMed(LCase$(termeChoisi)) = termeChoisi
                    End If

                Case SEC_CHOIX_EXPRESSION
                    termeChoisi = SEC_NettoyerCandidat(termeChoisi)
                    If termeChoisi <> "" Then
                        If Not SEC_AjouterLigneSecurisee( _
                            SEC_FICHIER_EXPRESSIONS, termeChoisi) Then Exit Function
                        SEC_Journaliser "AJOUT_EXPRESSION", termeChoisi, doc.Name
                        dExp(LCase$(termeChoisi)) = termeChoisi
                    End If

                Case SEC_CHOIX_PONCTUEL
                    termeChoisi = SEC_NettoyerCandidat(termeChoisi)
                    If termeChoisi <> "" Then
                        ponctuels(LCase$(termeChoisi)) = termeChoisi
                        SEC_Journaliser "PONCTUEL", termeChoisi, doc.Name
                    End If

                Case SEC_CHOIX_ANNULER
                    SEC_Journaliser "ANNULATION_GRAS", terme, doc.Name
            End Select
        Next cle
    End If

    Application.StatusBar = "Reconstruction complete du gras..."

    SEC_ReinitialiserZones zones
    SEC_AppliquerDictionnaire doc, zones, dMed, True
    SEC_AppliquerDictionnaire doc, zones, dExp, False
    SEC_AppliquerDictionnaire doc, zones, dExam, False
    SEC_AppliquerReglesStructurelles doc, zones
    SEC_AppliquerIdentitePatient doc, zones
    SEC_AppliquerDictionnaire doc, zones, ponctuels, False
    SEC_MemoriserPonctuelsDocument doc, ponctuels
    SEC_ValiderStatutDocument doc

    doc.Save

    Application.ScreenUpdating = True
    Application.StatusBar = False
    SEC_ValiderEtReconstruireGras = True
    mDernierTraitementOK = True
    Exit Function

GestionErreur:
    Application.ScreenUpdating = True
    Application.StatusBar = False
    mDernierTraitementOK = False

    MsgBox "Validation du gras interrompue :" & vbCrLf & _
        Err.Number & " - " & Err.Description, _
        vbExclamation, "Gras V2"
End Function

'-------------------------------------------------------------------------------
' DIALOGUE ET BROUILLONS
'-------------------------------------------------------------------------------

Private Function SEC_DemanderClassement(ByRef terme As String) As Long

    On Error GoTo GestionErreur

    Load frmSECGrasV2
    frmSECGrasV2.Preparer terme
    frmSECGrasV2.Show vbModal

    SEC_DemanderClassement = frmSECGrasV2.Choix
    terme = Trim$(frmSECGrasV2.TermeChoisi)
    Unload frmSECGrasV2
    Exit Function

GestionErreur:
    On Error Resume Next
    Unload frmSECGrasV2
    SEC_DemanderClassement = SEC_CHOIX_AUCUN
    MsgBox "Le formulaire Gras V2 n'a pas pu etre ouvert :" & vbCrLf & _
        Err.Number & " - " & Err.Description, vbExclamation, "Gras V2"
End Function

Private Function SEC_BrouillonNonComplete(ByVal doc As Document) As Boolean

    Dim rng As Range
    Dim statut As String

    Set rng = doc.Content.Duplicate
    With rng.Find
        .ClearFormatting
        .Text = SEC_MARQUEUR_BROUILLON
        .Forward = True
        .Wrap = wdFindStop
        .MatchWildcards = False
    End With

    If rng.Find.Execute Then
        rng.Select
        MsgBox "Ce document contient encore une rubrique a completer avant impression." & _
            vbCrLf & vbCrLf & "Corrigez le passage selectionne, supprimez le marqueur, " & _
            "puis relancez Alt+V ou Ctrl+P.", _
            vbExclamation, "Brouillon incomplet"
        SEC_BrouillonNonComplete = True
        Exit Function
    End If

    statut = SEC_LireVariable(doc, SEC_VAR_STATUT)
    If UCase$(statut) = "BROUILLON_A_COMPLETER" Then
        'Le marqueur visible a ete retire : la validation pourra passer le statut a COMPLET.
    End If
End Function

Private Sub SEC_ValiderStatutDocument(ByVal doc As Document)
    If InStr(1, doc.Content.Text, SEC_MARQUEUR_BROUILLON, vbTextCompare) = 0 Then
        SEC_DefinirVariable doc, SEC_VAR_STATUT, "COMPLET"
    End If
End Sub

'-------------------------------------------------------------------------------
' ZONES MEDICALES
'-------------------------------------------------------------------------------

Private Function SEC_ObtenirZonesMedicales(ByVal doc As Document) As Collection

    Dim c As New Collection
    Dim b As Bookmark
    Dim p As Paragraph
    Dim debut As Long
    Dim fin As Long
    Dim texte As String

    For Each b In doc.Bookmarks
        If Left$(b.Name, Len(SEC_PREFIXE_ZONE)) = SEC_PREFIXE_ZONE Then
            c.Add b.Range.Duplicate
        End If
    Next b

    If c.Count > 0 Then
        Set SEC_ObtenirZonesMedicales = c
        Exit Function
    End If

    debut = 0
    For Each p In doc.Paragraphs
        texte = SEC_NormaliserTexteSimple(p.Range.Text)

        If debut = 0 Then
            If SEC_EstFormuleAppel(texte) Then debut = p.Range.End
        Else
            If SEC_EstFinCorps(texte) Then
                fin = p.Range.Start
                If fin > debut Then c.Add doc.Range(debut, fin)
                debut = 0
            End If
        End If
    Next p

    If debut > 0 Then
        fin = doc.Content.End - 1
        If fin > debut Then c.Add doc.Range(debut, fin)
    End If

    Set SEC_ObtenirZonesMedicales = c
End Function

Private Function SEC_EstFormuleAppel(ByVal t As String) As Boolean
    If Len(t) = 0 Or Len(t) > 90 Then Exit Function
    SEC_EstFormuleAppel = _
        Left$(t, 5) = "cher " Or Left$(t, 6) = "chere " Or _
        Left$(t, 9) = "mon cher " Or Left$(t, 9) = "ma chere " Or _
        Left$(t, 14) = "mon tres cher " Or Left$(t, 14) = "ma tres chere " Or _
        t = "cher ami" Or t = "chere amie" Or _
        t = "madame" Or t = "monsieur" Or t = "madame monsieur"
End Function

Private Function SEC_EstFinCorps(ByVal t As String) As Boolean
    SEC_EstFinCorps = _
        InStr(1, t, "merci de votre confiance", vbTextCompare) > 0 Or _
        InStr(1, t, "je vous remercie de votre confiance", vbTextCompare) > 0 Or _
        InStr(1, t, "je vous prie", vbTextCompare) > 0 Or _
        InStr(1, t, "bien confraternellement", vbTextCompare) > 0 Or _
        t = "amities" Or t = "amitie" Or t = "cordialement" Or _
        InStr(1, t, "docteur olivier mandagout", vbTextCompare) > 0
End Function

'-------------------------------------------------------------------------------
' MASQUE ATTENDU ET CANDIDATS
'-------------------------------------------------------------------------------

Private Sub SEC_ConstruireMasqueAttendu( _
    ByVal doc As Document, _
    ByVal zones As Collection, _
    ByVal dMed As Object, _
    ByVal dExp As Object, _
    ByVal dExam As Object, _
    ByRef attendu() As Boolean)

    SEC_MarquerDictionnaireDansMasque doc, zones, dMed, attendu
    SEC_MarquerDictionnaireDansMasque doc, zones, dExp, attendu
    SEC_MarquerDictionnaireDansMasque doc, zones, dExam, attendu
    SEC_MarquerReglesStructurelles doc, zones, attendu
    SEC_MarquerIdentitePatient doc, zones, attendu
End Sub

Private Sub SEC_MarquerDictionnaireDansMasque( _
    ByVal doc As Document, _
    ByVal zones As Collection, _
    ByVal d As Object, _
    ByRef attendu() As Boolean)

    Dim cle As Variant
    For Each cle In d.Keys
        SEC_MarquerOccurrences doc, zones, CStr(cle), attendu
    Next cle
End Sub

Private Sub SEC_MarquerReglesStructurelles( _
    ByVal doc As Document, _
    ByVal zones As Collection, _
    ByRef attendu() As Boolean)

    Dim termes As Variant
    Dim t As Variant

    termes = Array( _
        "examen clinique", "electrocardiogramme", _
        "echocardiographie", "echographie cardiaque", _
        "biologie", "bilan biologique", "au total")

    For Each t In termes
        SEC_MarquerOccurrences doc, zones, CStr(t), attendu
    Next t
End Sub

Private Sub SEC_MarquerIdentitePatient( _
    ByVal doc As Document, _
    ByVal zones As Collection, _
    ByRef attendu() As Boolean)

    Dim identite As String

    identite = SEC_LireVariable(doc, SEC_VAR_IDENTITE)
    If identite <> "" Then SEC_MarquerOccurrences doc, zones, identite, attendu
End Sub

Private Sub SEC_MarquerOccurrences( _
    ByVal doc As Document, _
    ByVal zones As Collection, _
    ByVal terme As String, _
    ByRef attendu() As Boolean)

    Dim z As Range
    Dim r As Range
    Dim i As Long

    terme = Trim$(terme)
    If terme = "" Then Exit Sub

    For Each z In zones
        Set r = z.Duplicate
        With r.Find
            .ClearFormatting
            .Text = terme
            .Forward = True
            .Wrap = wdFindStop
            .MatchCase = False
            .MatchWholeWord = False
            .MatchWildcards = False
        End With

        Do While r.Find.Execute
            If SEC_BornesValides(doc, r, terme) Then
                For i = r.Start To r.End - 1
                    If i >= LBound(attendu) And i <= UBound(attendu) Then
                        attendu(i) = True
                    End If
                Next i
            End If
            r.Collapse wdCollapseEnd
            r.End = z.End
        Loop
    Next z
End Sub

Private Function SEC_CollecterCandidats( _
    ByVal doc As Document, _
    ByVal zones As Collection, _
    ByRef attendu() As Boolean) As Object

    Dim d As Object
    Dim z As Range
    Dim i As Long
    Dim debut As Long
    Dim dansRun As Boolean
    Dim r As Range
    Dim terme As String

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    For Each z In zones
        dansRun = False
        debut = -1

        For i = z.Start To z.End - 1
            Set r = doc.Range(i, i + 1)

            If r.Font.Bold = True And Not attendu(i) Then
                If Not dansRun Then
                    debut = i
                    dansRun = True
                End If
            Else
                If dansRun Then
                    terme = SEC_NettoyerCandidat(doc.Range(debut, i).Text)
                    SEC_AjouterCandidat d, terme
                    dansRun = False
                    debut = -1
                End If
            End If
        Next i

        If dansRun And debut >= 0 Then
            terme = SEC_NettoyerCandidat(doc.Range(debut, z.End).Text)
            SEC_AjouterCandidat d, terme
        End If
    Next z

    Set SEC_CollecterCandidats = d
End Function

Private Sub SEC_AjouterCandidat(ByVal d As Object, ByVal terme As String)

    Dim morceaux As Variant
    Dim m As Variant
    Dim valeur As String

    terme = Replace(terme, vbCrLf, vbLf)
    terme = Replace(terme, vbCr, vbLf)
    morceaux = Split(terme, vbLf)

    For Each m In morceaux
        valeur = SEC_NettoyerCandidat(CStr(m))
        If SEC_CandidatValide(valeur) Then
            If Not d.Exists(valeur) Then d.Add valeur, True
        End If
    Next m
End Sub

Private Function SEC_CandidatValide(ByVal terme As String) As Boolean
    Dim i As Long
    terme = Trim$(terme)
    If Len(terme) < 2 Or Len(terme) > 2000 Then Exit Function
    For i = 1 To Len(terme)
        If LCase$(Mid$(terme, i, 1)) <> UCase$(Mid$(terme, i, 1)) Then
            SEC_CandidatValide = True
            Exit Function
        End If
    Next i
End Function

Private Function SEC_ProportionGras( _
    ByVal doc As Document, _
    ByVal zones As Collection) As Double

    Dim z As Range
    Dim i As Long
    Dim r As Range
    Dim total As Long
    Dim gras As Long
    Dim c As String

    For Each z In zones
        For i = z.Start To z.End - 1
            Set r = doc.Range(i, i + 1)
            c = r.Text
            If c <> " " And c <> vbCr And c <> vbTab And c <> vbLf Then
                total = total + 1
                If r.Font.Bold = True Then gras = gras + 1
            End If
        Next i
    Next z

    If total > 0 Then SEC_ProportionGras = gras / total
End Function

'-------------------------------------------------------------------------------
' RECONSTRUCTION
'-------------------------------------------------------------------------------

Private Sub SEC_ReinitialiserZones(ByVal zones As Collection)
    Dim z As Range
    For Each z In zones
        z.Font.Bold = False
    Next z
End Sub

Private Sub SEC_AppliquerDictionnaire( _
    ByVal doc As Document, _
    ByVal zones As Collection, _
    ByVal d As Object, _
    ByVal modifierCasse As Boolean)

    Dim cle As Variant
    For Each cle In d.Keys
        SEC_AppliquerTermeZones doc, zones, CStr(cle), _
            CStr(d(cle)), modifierCasse
    Next cle
End Sub

Private Sub SEC_AppliquerReglesStructurelles( _
    ByVal doc As Document, _
    ByVal zones As Collection)

    Dim termes As Variant
    Dim t As Variant

    termes = Array( _
        "examen clinique", "electrocardiogramme", _
        "echocardiographie", "echographie cardiaque", _
        "biologie", "bilan biologique", "au total")

    For Each t In termes
        SEC_AppliquerTermeZones doc, zones, CStr(t), CStr(t), False
    Next t
End Sub

Private Sub SEC_AppliquerIdentitePatient( _
    ByVal doc As Document, _
    ByVal zones As Collection)

    Dim identite As String
    identite = SEC_LireVariable(doc, SEC_VAR_IDENTITE)
    If identite <> "" Then
        SEC_AppliquerTermeZones doc, zones, identite, identite, False
    End If
End Sub

Private Sub SEC_AppliquerTermeZones( _
    ByVal doc As Document, _
    ByVal zones As Collection, _
    ByVal recherche As String, _
    ByVal canonique As String, _
    ByVal modifierCasse As Boolean)

    Dim z As Range
    Dim r As Range

    recherche = Trim$(recherche)
    If recherche = "" Then Exit Sub

    For Each z In zones
        Set r = z.Duplicate
        With r.Find
            .ClearFormatting
            .Text = recherche
            .Forward = True
            .Wrap = wdFindStop
            .MatchCase = False
            .MatchWholeWord = False
            .MatchWildcards = False
        End With

        Do While r.Find.Execute
            If SEC_BornesValides(doc, r, recherche) Then
                If modifierCasse And canonique <> "" Then
                    If StrComp(r.Text, canonique, vbBinaryCompare) <> 0 Then
                        r.Text = canonique
                    End If
                End If
                r.Font.Bold = True
            End If
            r.Collapse wdCollapseEnd
            r.End = z.End
        Loop
    Next z
End Sub

Private Function SEC_BornesValides( _
    ByVal doc As Document, _
    ByVal r As Range, _
    ByVal terme As String) As Boolean

    Dim avant As String
    Dim apres As String

    SEC_BornesValides = True

    If SEC_EstCaractereMot(Left$(terme, 1)) And r.Start > 0 Then
        avant = doc.Range(r.Start - 1, r.Start).Text
        If SEC_EstCaractereMot(avant) Then SEC_BornesValides = False
    End If

    If Not SEC_BornesValides Then Exit Function

    If SEC_EstCaractereMot(Right$(terme, 1)) And _
       r.End < doc.Content.End - 1 Then
        apres = doc.Range(r.End, r.End + 1).Text
        If SEC_EstCaractereMot(apres) Then SEC_BornesValides = False
    End If
End Function

Private Function SEC_EstCaractereMot(ByVal c As String) As Boolean
    If Len(c) = 0 Then Exit Function
    c = Left$(c, 1)
    SEC_EstCaractereMot = _
        ((c >= "0" And c <= "9") Or LCase$(c) <> UCase$(c))
End Function

'-------------------------------------------------------------------------------
' DICTIONNAIRES ET PONCTUELS
'-------------------------------------------------------------------------------

Private Function SEC_ChargerDictionnaire( _
    ByVal chemin As String, _
    ByVal estMedicament As Boolean) As Object

    Dim d As Object
    Dim contenu As String
    Dim lignes As Variant
    Dim ligne As Variant
    Dim parties As Variant
    Dim p As Variant
    Dim canonique As String
    Dim aliasTexte As String

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    contenu = SEC_LireFichier(chemin)
    contenu = Replace(contenu, vbCrLf, vbLf)
    contenu = Replace(contenu, vbCr, vbLf)
    lignes = Split(contenu, vbLf)

    For Each ligne In lignes
        aliasTexte = Trim$(CStr(ligne))
        If aliasTexte <> "" And Left$(aliasTexte, 1) <> "#" Then
            parties = Split(aliasTexte, "|")
            canonique = Trim$(CStr(parties(0)))
            If estMedicament Then canonique = UCase$(canonique)

            For Each p In parties
                aliasTexte = Trim$(CStr(p))
                If aliasTexte <> "" Then d(LCase$(aliasTexte)) = canonique
            Next p
            If canonique <> "" Then d(LCase$(canonique)) = canonique
        End If
    Next ligne

    Set SEC_ChargerDictionnaire = d
End Function

Private Function SEC_ChargerExamens() As Object

    Dim d As Object
    Dim contenu As String
    Dim lignes As Variant
    Dim ligne As Variant
    Dim parties As Variant
    Dim expression As String

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    contenu = SEC_LireFichier(SEC_FICHIER_EXAMENS)
    contenu = Replace(contenu, vbCrLf, vbLf)
    contenu = Replace(contenu, vbCr, vbLf)
    lignes = Split(contenu, vbLf)

    For Each ligne In lignes
        expression = Trim$(CStr(ligne))
        If expression <> "" And Left$(expression, 1) <> "#" Then
            parties = Split(expression, "|")
            expression = Trim$(CStr(parties(0)))
            If expression <> "" Then d(LCase$(expression)) = expression
        End If
    Next ligne

    Set SEC_ChargerExamens = d
End Function

Private Function SEC_ChargerPonctuelsDocument(ByVal doc As Document) As Object

    Dim d As Object
    Dim valeur As String
    Dim parties As Variant
    Dim p As Variant

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    valeur = SEC_LireVariable(doc, SEC_VAR_PONCTUELS)
    If valeur <> "" Then
        parties = Split(valeur, SEC_SEPARATEUR)
        For Each p In parties
            If Trim$(CStr(p)) <> "" Then d(LCase$(Trim$(CStr(p)))) = Trim$(CStr(p))
        Next p
    End If

    Set SEC_ChargerPonctuelsDocument = d
End Function

Private Sub SEC_MemoriserPonctuelsDocument( _
    ByVal doc As Document, _
    ByVal d As Object)

    Dim cle As Variant
    Dim valeur As String

    For Each cle In d.Keys
        If valeur <> "" Then valeur = valeur & SEC_SEPARATEUR
        valeur = valeur & CStr(d(cle))
    Next cle

    SEC_DefinirVariable doc, SEC_VAR_PONCTUELS, valeur
End Sub

Private Function SEC_AjouterLigneSecurisee( _
    ByVal chemin As String, _
    ByVal valeur As String) As Boolean

    Dim fLock As Integer
    Dim f As Integer
    Dim tentative As Long
    Dim acquis As Boolean
    Dim debut As Single

    SEC_AjouterLigneSecurisee = False
    valeur = Trim$(valeur)
    If valeur = "" Then Exit Function

    For tentative = 1 To 20
        On Error Resume Next
        Err.Clear
        fLock = FreeFile
        Open SEC_FICHIER_VERROU For Binary Access Read Write Lock Read Write As #fLock
        acquis = (Err.Number = 0)
        Err.Clear
        On Error GoTo 0

        If acquis Then Exit For
        debut = Timer
        Do While Timer - debut < 0.1
            DoEvents
        Loop
    Next tentative

    If Not acquis Then
        MsgBox "Les dictionnaires sont momentanement utilises par un autre poste.", _
            vbExclamation, "Gras V2"
        Exit Function
    End If

    On Error GoTo GestionErreur

    If Not SEC_LigneExiste(chemin, valeur) Then
        f = FreeFile
        Open chemin For Append As #f
        Print #f, valeur
        Close #f
    End If

    Close #fLock
    On Error Resume Next
    Kill SEC_FICHIER_VERROU
    On Error GoTo 0

    SEC_AjouterLigneSecurisee = True
    Exit Function

GestionErreur:
    On Error Resume Next
    Close #f
    Close #fLock
    Kill SEC_FICHIER_VERROU
    On Error GoTo 0
    MsgBox "Impossible de modifier :" & vbCrLf & chemin & vbCrLf & _
        Err.Number & " - " & Err.Description, vbExclamation, "Gras V2"
End Function

Private Function SEC_LigneExiste( _
    ByVal chemin As String, _
    ByVal valeur As String) As Boolean

    Dim contenu As String
    Dim lignes As Variant
    Dim l As Variant

    contenu = SEC_LireFichier(chemin)
    contenu = Replace(contenu, vbCrLf, vbLf)
    contenu = Replace(contenu, vbCr, vbLf)
    lignes = Split(contenu, vbLf)

    For Each l In lignes
        If StrComp(Trim$(CStr(l)), valeur, vbTextCompare) = 0 Then
            SEC_LigneExiste = True
            Exit Function
        End If
    Next l
End Function

Private Function SEC_LireFichier(ByVal chemin As String) As String
    Dim f As Integer
    On Error GoTo Fin
    f = FreeFile
    Open chemin For Binary Access Read As #f
    If LOF(f) > 0 Then SEC_LireFichier = Input$(LOF(f), #f)
Fin:
    On Error Resume Next
    Close #f
End Function

Private Sub SEC_Journaliser( _
    ByVal action As String, _
    ByVal terme As String, _
    ByVal document As String)

    Dim f As Integer
    On Error Resume Next
    f = FreeFile
    Open SEC_FICHIER_JOURNAL For Append As #f
    Print #f, Format$(Now, "yyyy-mm-dd hh:nn:ss") & " | " & _
        Environ$("USERNAME") & " | " & action & " | " & terme & " | " & document
    Close #f
    On Error GoTo 0
End Sub

'-------------------------------------------------------------------------------
' OUTILS
'-------------------------------------------------------------------------------

Private Function SEC_ConfigurationDisponible(ByVal afficher As Boolean) As Boolean
    Dim msg As String

    If Dir$(SEC_FICHIER_MEDICAMENTS) = "" Then msg = SEC_FICHIER_MEDICAMENTS
    If msg = "" And Dir$(SEC_FICHIER_EXPRESSIONS) = "" Then msg = SEC_FICHIER_EXPRESSIONS
    If msg = "" And Dir$(SEC_FICHIER_EXAMENS) = "" Then msg = SEC_FICHIER_EXAMENS

    If msg <> "" Then
        If afficher Then MsgBox "Fichier introuvable :" & vbCrLf & msg, _
            vbExclamation, "Gras V2"
        Exit Function
    End If

    If Dir$(SEC_FICHIER_JOURNAL) = "" Then
        Dim f As Integer
        f = FreeFile
        Open SEC_FICHIER_JOURNAL For Append As #f
        Close #f
    End If

    SEC_ConfigurationDisponible = True
End Function

Private Function SEC_EstCourrierSortieDragon(ByVal doc As Document) As Boolean
    If doc Is Nothing Then Exit Function
    If Trim$(doc.Path) = "" Then Exit Function
    SEC_EstCourrierSortieDragon = _
        (InStr(1, doc.FullName, SEC_DOSSIER_SORTIE & "\", vbTextCompare) = 1)
End Function

Private Function SEC_EtatFichier(ByVal chemin As String) As String
    SEC_EtatFichier = IIf(Dir$(chemin) <> "", "OK - ", "ABSENT - ") & chemin
End Function

Private Function SEC_NormaliserTexteSimple(ByVal texte As String) As String
    texte = LCase$(texte)
    texte = Replace(texte, ChrW(8217), "'")
    texte = Replace(texte, vbCr, " ")
    texte = Replace(texte, vbLf, " ")
    texte = Replace(texte, vbTab, " ")
    texte = Replace(texte, Chr$(160), " ")
    texte = SEC_SansAccents(texte)
    Do While InStr(1, texte, "  ", vbBinaryCompare) > 0
        texte = Replace(texte, "  ", " ")
    Loop
    texte = Trim$(texte)
    Do While Len(texte) > 0 And InStr(1, ".,:;!?", Right$(texte, 1)) > 0
        texte = Trim$(Left$(texte, Len(texte) - 1))
    Loop
    SEC_NormaliserTexteSimple = texte
End Function

Private Function SEC_SansAccents(ByVal texte As String) As String
    Dim a As Variant, b As Variant, i As Long
    a = Array("a", "a", "a", "a", "a", "c", "e", "e", "e", "e", _
        "i", "i", "i", "o", "o", "o", "o", "u", "u", "u", "u", "y", "oe")
    b = Array("a", "a", "a", "a", "a", "c", "e", "e", "e", "e", _
        "i", "i", "i", "o", "o", "o", "o", "u", "u", "u", "u", "y", "oe")
    'La comparaison est deja insensible aux accents dans Word Find ; cette
    'fonction conserve surtout une normalisation stable des ponctuations.
    SEC_SansAccents = texte
End Function

Private Function SEC_NettoyerCandidat(ByVal texte As String) As String
    Dim c As String
    texte = Replace(texte, Chr$(160), " ")
    texte = Replace(texte, vbTab, " ")
    Do While InStr(1, texte, "  ", vbBinaryCompare) > 0
        texte = Replace(texte, "  ", " ")
    Loop
    texte = Trim$(texte)

    Do While Len(texte) > 0
        c = Left$(texte, 1)
        If InStr(1, " .,:;!?()[]{}<>""", c, vbBinaryCompare) > 0 Then
            texte = Mid$(texte, 2)
        Else
            Exit Do
        End If
    Loop

    Do While Len(texte) > 0
        c = Right$(texte, 1)
        If InStr(1, " .,:;!?()[]{}<>""", c, vbBinaryCompare) > 0 Then
            texte = Left$(texte, Len(texte) - 1)
        Else
            Exit Do
        End If
    Loop

    SEC_NettoyerCandidat = Trim$(texte)
End Function

Private Function SEC_NettoyerNomMedicament(ByVal texte As String) As String
    Dim re As Object
    texte = SEC_NettoyerCandidat(texte)
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "[ ]+[0-9]+([,.][0-9]+)?[ ]*(mg|mcg|ug|g|ml|%)?.*$"
    SEC_NettoyerNomMedicament = Trim$(re.Replace(texte, ""))
End Function

Private Function SEC_LireVariable( _
    ByVal doc As Document, _
    ByVal nom As String) As String
    On Error Resume Next
    SEC_LireVariable = Trim$(doc.Variables(nom).Value)
    On Error GoTo 0
End Function

Private Sub SEC_DefinirVariable( _
    ByVal doc As Document, _
    ByVal nom As String, _
    ByVal valeur As String)
    On Error Resume Next
    doc.Variables(nom).Delete
    On Error GoTo 0
    doc.Variables.Add Name:=nom, Value:=valeur
End Sub
