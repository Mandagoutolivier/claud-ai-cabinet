﻿R12 - PROFILS PAR EXAMEN + TROISIEME APPEL DE REVISION + GRAS V2
===================================================================

POINT DE DEPART
---------------
R12 repart du R7 valide. La logique du premier appel API reste conservee.

ARCHITECTURE DES LETTRES COMPLEMENTAIRES
----------------------------------------
1. API 1 corrige le courrier principal.
2. Le PC detecte les demandes avec DDE et charge le profil INI correspondant.
3. API 2 remplit uniquement les rubriques autorisees par le profil.
4. Le VBA assemble un brouillon local avec un paragraphe par rubrique.
5. API 3 revise uniquement la redaction des profils pour lesquels APPEL_API=OUI.
6. Le VBA refuse l'API 3 si les tags, les valeurs critiques ou [[PATIENT]] changent.
7. En cas d'echec de l'API 3, le brouillon local est conserve.

GRAS V2 DANS NORMAL.DOTM
------------------------
- Ctrl+P appelle directement SEC_ImprimerAvecValidation.
- Alt+V appelle directement SEC_ValiderGrasSansImprimer.
- les nouveaux passages en gras ouvrent un vrai formulaire a 4 boutons ;
- un courrier presque entierement en gras declenche une alerte globale ;
- le moteur remet les zones medicales en non-gras puis reconstruit le gras attendu ;
- aucune API n'est utilisee pour le gras.

INSTALLATION RAPIDE
-------------------
1. Extraire R12.zip vers C:\R12.
2. Fermer Word.
3. Lancer 05_INSTALLATION\01_CREER_MODELE_TEST_R12.cmd.
4. Ouvrir C:\ModeleCourrierChatGPT_TEST\ModeleCourrierChatGPT_TEST_R12_PROFILS_3_API.dotm.
5. Alt+F11 > Debogage > Compiler TemplateProject > Ctrl+S.
6. Fermer Word et lancer 02_ACTIVER_MODELE_TEST_R12.cmd.
7. Fermer Word et lancer 06_INSTALLER_GRAS_V2_DANS_NORMAL.cmd.
8. Ouvrir Word, compiler Normal.dotm, enregistrer.
9. Lancer SEC_InstallerRaccourcisGrasV2 puis SEC_VerifierInstallation.
10. Lancer RAC_InstallerRaccourcis pour Alt+G, Alt+D, Alt+A et Alt+X.

IMPORTANT
---------
RAC_InstallerRaccourcis ne modifie plus Alt+V. Alt+V et Ctrl+P appartiennent
exclusivement au moteur Gras V2 de Normal.dotm.

Cette mouture reste une branche TEST tant que les profils et l'API 3 n'ont pas
ete valides sur des courriers reels.
