Attribute VB_Name = "modProfilsExamensR12"
Option Explicit
Option Private Module

'===============================================================================
' R12 - PROFILS EXTERNES PAR TYPE D'EXAMEN
'===============================================================================

Public Const R12_VERSION_PROFILS As String = "R12-PROFILS-EXAMENS-1"
Public Const R12_DOSSIER_PROFILS As String = _
    "\\DS224\home\logiciel_chatgpt_cabinet\profils_examens"
Public Const R12_PROFIL_SECOURS As String = "AUTRE_EXAMEN"

Public Function R12_ProfilPourType( _
    ByVal typeDetecte As String, _
    ByVal expressionTrouvee As String, _
    ByVal phraseSource As String) As String

    Dim t As String

    typeDetecte = UCase$(Trim$(typeDetecte))
    t = R12_NormaliserTexte(phraseSource & " " & expressionTrouvee)

    'Extensibilite R12 : si le type canonique du dictionnaire porte exactement
    'le nom d'un profil INI existant, aucun changement VBA n'est necessaire.
    If typeDetecte <> "" Then
        If R12_ProfilExiste(typeDetecte) Then
            R12_ProfilPourType = typeDetecte
            Exit Function
        End If
    End If

    Select Case typeDetecte

        Case "IRM_STRESS", "IRM_DE_STRESS"
            R12_ProfilPourType = "IRM_DE_STRESS"

        Case "IRM", "IRM_CARDIAQUE"
            If InStr(1, t, "stress", vbTextCompare) > 0 Then
                R12_ProfilPourType = "IRM_DE_STRESS"
            Else
                R12_ProfilPourType = "IRM_CARDIAQUE"
            End If

        Case "AVIS_NEUROLOGIE", "AVIS_NEUROLOGIQUE"
            R12_ProfilPourType = "AVIS_NEUROLOGIQUE"

        Case "AVIS_GASTROENTEROLOGIE", "AVIS_GASTROENTEROLOGIQUE"
            R12_ProfilPourType = "AVIS_GASTROENTEROLOGIQUE"

        Case "AVIS_RYTHMOLOGIE", "AVIS_RYTHMOLOGIQUE"
            R12_ProfilPourType = "AVIS_RYTHMOLOGIQUE"

        Case "AVIS_PNEUMOLOGIE", "AVIS_PNEUMOLOGIQUE"
            R12_ProfilPourType = "AVIS_PNEUMOLOGIQUE"

        Case "AVIS_NEPHROLOGIE", "AVIS_NEPHROLOGIQUE"
            R12_ProfilPourType = "AVIS_NEPHROLOGIQUE"

        Case "AVIS_HEMATOLOGIE", "AVIS_HEMATOLOGIQUE"
            R12_ProfilPourType = "AVIS_HEMATOLOGIQUE"

        Case "AVIS_VASCULAIRE", "AVIS_SPECIALISE"
            If typeDetecte = "AVIS_VASCULAIRE" Then
                R12_ProfilPourType = "AVIS_VASCULAIRE"
            Else
                R12_ProfilPourType = "AVIS_SPECIALISE"
            End If

        Case "ECHODOPPLER_ARTERIEL_TSA_ET_MEMBRES_INFERIEURS"
            R12_ProfilPourType = _
                "ECHODOPPLER_ARTERIEL_TSA_ET_MEMBRES_INFERIEURS"

        Case "ECHODOPPLER_ARTERIEL"
            If R12_ContientTSA(t) And R12_ContientMembresInferieurs(t) Then
                R12_ProfilPourType = _
                    "ECHODOPPLER_ARTERIEL_TSA_ET_MEMBRES_INFERIEURS"
            Else
                R12_ProfilPourType = _
                    "ECHODOPPLER_ARTERIEL_MEMBRES_INFERIEURS"
            End If

        Case "ECHODOPPLER_TSA"
            R12_ProfilPourType = "ECHODOPPLER_TSA"

        Case "ECHODOPPLER_MI"
            If InStr(1, t, "veine", vbTextCompare) > 0 Then
                R12_ProfilPourType = "ECHODOPPLER_VEINEUX"
            ElseIf InStr(1, t, "arter", vbTextCompare) > 0 Then
                R12_ProfilPourType = _
                    "ECHODOPPLER_ARTERIEL_MEMBRES_INFERIEURS"
            Else
                R12_ProfilPourType = "ECHODOPPLER_MEMBRES_INFERIEURS"
            End If

        Case "ECHODOPPLER_VEINEUX"
            R12_ProfilPourType = "ECHODOPPLER_VEINEUX"

        Case "ANGIOSCANNER"
            R12_ProfilPourType = R12_ProfilAngioscannerSelonTexte(t)

        Case "SCANNER"
            R12_ProfilPourType = R12_ProfilScannerSelonTexte(t)

        Case "SCORE_CALCIQUE", "TEST_EFFORT", _
             "SCINTIGRAPHIE_MYOCARDIQUE", "COROSCANNER", _
             "SCANNER_THORACIQUE", "ANGIOSCANNER_PULMONAIRE", _
             "RECHERCHE_SAOS", "ANGIOSCANNER_TSA", _
             "ANGIOSCANNER_AORTE_MEMBRES_INFERIEURS", _
             "ANGIOSCANNER_ARTERES_RENALES", "SCANNER_RENAL", _
             "SCANNER_SURRENALIEN", "ANGIOSCANNER_RENAL_SURRENALIEN", _
             "HOSPITALISATION_CCN", "HOSPITALISATION_AUTRE_CENTRE", _
             "CORONAROGRAPHIE", "ECHODOPPLER_MEMBRES_INFERIEURS", _
             "ECHODOPPLER_ARTERIEL_MEMBRES_INFERIEURS"

            R12_ProfilPourType = typeDetecte

        Case Else
            If InStr(1, t, "hospital", vbTextCompare) > 0 Then
                If InStr(1, t, "ccn", vbTextCompare) > 0 Then
                    R12_ProfilPourType = "HOSPITALISATION_CCN"
                Else
                    R12_ProfilPourType = "HOSPITALISATION_AUTRE_CENTRE"
                End If
            Else
                R12_ProfilPourType = R12_PROFIL_SECOURS
            End If

    End Select

    If Not R12_ProfilExiste(R12_ProfilPourType) Then
        R12_ProfilPourType = R12_PROFIL_SECOURS
    End If

End Function


Public Function R12_RevisionFinaleActive(ByVal profil As Object) As Boolean
    R12_RevisionFinaleActive = _
        (UCase$(Trim$(R12_ProfilValeur(profil, "REVISION_FINALE", "APPEL_API", "NON"))) = "OUI")
End Function

Private Function R12_ProfilAngioscannerSelonTexte( _
    ByVal t As String) As String

    If InStr(1, t, "pulmona", vbTextCompare) > 0 Or _
       InStr(1, t, "embolie", vbTextCompare) > 0 Then

        R12_ProfilAngioscannerSelonTexte = "ANGIOSCANNER_PULMONAIRE"

    ElseIf R12_ContientTSA(t) Then

        R12_ProfilAngioscannerSelonTexte = "ANGIOSCANNER_TSA"

    ElseIf InStr(1, t, "aorte", vbTextCompare) > 0 Or _
           R12_ContientMembresInferieurs(t) Then

        R12_ProfilAngioscannerSelonTexte = _
            "ANGIOSCANNER_AORTE_MEMBRES_INFERIEURS"

    ElseIf InStr(1, t, "surrenal", vbTextCompare) > 0 And _
           (InStr(1, t, "renal", vbTextCompare) > 0 Or _
            InStr(1, t, "rein", vbTextCompare) > 0) Then

        R12_ProfilAngioscannerSelonTexte = _
            "ANGIOSCANNER_RENAL_SURRENALIEN"

    ElseIf InStr(1, t, "arteres renales", vbTextCompare) > 0 Or _
           InStr(1, t, "artere renale", vbTextCompare) > 0 Then

        R12_ProfilAngioscannerSelonTexte = _
            "ANGIOSCANNER_ARTERES_RENALES"

    Else
        R12_ProfilAngioscannerSelonTexte = R12_PROFIL_SECOURS
    End If

End Function

Private Function R12_ProfilScannerSelonTexte( _
    ByVal t As String) As String

    If InStr(1, t, "thorac", vbTextCompare) > 0 Then
        R12_ProfilScannerSelonTexte = "SCANNER_THORACIQUE"
    ElseIf InStr(1, t, "surrenal", vbTextCompare) > 0 Then
        R12_ProfilScannerSelonTexte = "SCANNER_SURRENALIEN"
    ElseIf InStr(1, t, "renal", vbTextCompare) > 0 Or _
           InStr(1, t, "rein", vbTextCompare) > 0 Then
        R12_ProfilScannerSelonTexte = "SCANNER_RENAL"
    Else
        R12_ProfilScannerSelonTexte = R12_PROFIL_SECOURS
    End If

End Function

Private Function R12_ContientTSA(ByVal t As String) As Boolean

    R12_ContientTSA = _
        InStr(1, t, "tsa", vbTextCompare) > 0 Or _
        InStr(1, t, "troncs supra", vbTextCompare) > 0 Or _
        InStr(1, t, "vaisseaux du cou", vbTextCompare) > 0 Or _
        InStr(1, t, "carotide", vbTextCompare) > 0

End Function

Private Function R12_ContientMembresInferieurs( _
    ByVal t As String) As Boolean

    R12_ContientMembresInferieurs = _
        InStr(1, t, "membres inferieurs", vbTextCompare) > 0 Or _
        InStr(1, t, "jambes", vbTextCompare) > 0 Or _
        InStr(1, t, "arteres des membres", vbTextCompare) > 0

End Function

Public Function R12_ChargerProfil(ByVal codeProfil As String) As Object

    Dim profil As Object
    Dim chemin As String
    Dim contenu As String
    Dim lignes As Variant
    Dim ligne As Variant
    Dim section As String
    Dim positionEgal As Long
    Dim cle As String
    Dim valeur As String

    codeProfil = UCase$(Trim$(codeProfil))
    If codeProfil = "" Then codeProfil = R12_PROFIL_SECOURS

    chemin = R12_CheminProfil(codeProfil)

    If Dir$(chemin) = "" Then
        codeProfil = R12_PROFIL_SECOURS
        chemin = R12_CheminProfil(codeProfil)
    End If

    Set profil = CreateObject("Scripting.Dictionary")
    profil.CompareMode = vbTextCompare

    If Dir$(chemin) = "" Then
        Set R12_ChargerProfil = profil
        Exit Function
    End If

    contenu = R12_LireFichierTexte(chemin)
    contenu = Replace(contenu, vbCrLf, vbLf)
    contenu = Replace(contenu, vbCr, vbLf)
    lignes = Split(contenu, vbLf)

    section = ""

    For Each ligne In lignes

        ligne = Trim$(CStr(ligne))

        If ligne <> "" Then
            If Left$(ligne, 1) <> "#" And Left$(ligne, 1) <> ";" Then

                If Left$(ligne, 1) = "[" And Right$(ligne, 1) = "]" Then
                    section = UCase$(Trim$(Mid$(ligne, 2, Len(ligne) - 2)))
                Else
                    positionEgal = InStr(1, ligne, "=", vbBinaryCompare)
                    If positionEgal > 0 Then
                        cle = UCase$(Trim$(Left$(ligne, positionEgal - 1)))
                        valeur = Trim$(Mid$(ligne, positionEgal + 1))
                        profil(section & "." & cle) = valeur
                    End If
                End If

            End If
        End If

    Next ligne

    profil("_CHEMIN") = chemin
    profil("_CODE_DEMANDE") = codeProfil

    Set R12_ChargerProfil = profil

End Function

Public Function R12_ProfilValeur( _
    ByVal profil As Object, _
    ByVal section As String, _
    ByVal cle As String, _
    Optional ByVal valeurDefaut As String = "") As String

    Dim k As String

    R12_ProfilValeur = valeurDefaut
    If profil Is Nothing Then Exit Function

    k = UCase$(Trim$(section)) & "." & UCase$(Trim$(cle))

    If profil.Exists(k) Then
        R12_ProfilValeur = CStr(profil(k))
    End If

End Function

Public Function R12_ProfilExiste(ByVal codeProfil As String) As Boolean

    R12_ProfilExiste = _
        (Dir$(R12_CheminProfil(UCase$(Trim$(codeProfil)))) <> "")

End Function

Public Function R12_CheminProfil(ByVal codeProfil As String) As String

    R12_CheminProfil = _
        R12_DOSSIER_PROFILS & "\" & UCase$(Trim$(codeProfil)) & ".ini"

End Function

Public Function R12_DecouperListe(ByVal valeur As String) As Variant

    Dim morceaux As Variant
    Dim resultat() As String
    Dim i As Long
    Dim n As Long
    Dim element As String

    valeur = Replace(valeur, ",", ";")
    morceaux = Split(valeur, ";")
    n = -1

    For i = LBound(morceaux) To UBound(morceaux)
        element = UCase$(Trim$(CStr(morceaux(i))))
        If element <> "" Then
            n = n + 1
            ReDim Preserve resultat(0 To n)
            resultat(n) = element
        End If
    Next i

    If n < 0 Then
        R12_DecouperListe = Array()
    Else
        R12_DecouperListe = resultat
    End If

End Function

Public Function R12_ListeContient( _
    ByVal liste As String, _
    ByVal element As String) As Boolean

    Dim valeurs As Variant
    Dim valeur As Variant

    element = UCase$(Trim$(element))
    valeurs = R12_DecouperListe(liste)

    If Not IsArray(valeurs) Then Exit Function

    For Each valeur In valeurs
        If UCase$(Trim$(CStr(valeur))) = element Then
            R12_ListeContient = True
            Exit Function
        End If
    Next valeur

End Function

Public Function R12_LireFichierTexte(ByVal chemin As String) As String

    Dim f As Integer
    Dim contenu As String

    If Dir$(chemin) = "" Then Exit Function

    On Error GoTo GestionErreur

    f = FreeFile
    Open chemin For Binary Access Read As #f

    If LOF(f) > 0 Then
        contenu = Space$(LOF(f))
        Get #f, , contenu
    End If

    Close #f

    If Len(contenu) >= 3 Then
        If Asc(Mid$(contenu, 1, 1)) = 239 And _
           Asc(Mid$(contenu, 2, 1)) = 187 And _
           Asc(Mid$(contenu, 3, 1)) = 191 Then
            contenu = Mid$(contenu, 4)
        End If
    End If

    R12_LireFichierTexte = contenu
    Exit Function

GestionErreur:
    On Error Resume Next
    Close #f
    On Error GoTo 0

End Function

Public Function R12_NormaliserTexte(ByVal texte As String) As String

    texte = LCase$(texte)
    texte = Replace(texte, Chr(160), " ")
    texte = Replace(texte, vbTab, " ")
    texte = Replace(texte, vbCr, " ")
    texte = Replace(texte, vbLf, " ")
    texte = Replace(texte, "'", "'")
    texte = Replace(texte, "�", "e")
    texte = Replace(texte, "�", "e")
    texte = Replace(texte, "�", "e")
    texte = Replace(texte, "�", "e")
    texte = Replace(texte, "�", "a")
    texte = Replace(texte, "�", "a")
    texte = Replace(texte, "�", "a")
    texte = Replace(texte, "�", "i")
    texte = Replace(texte, "�", "i")
    texte = Replace(texte, "�", "o")
    texte = Replace(texte, "�", "o")
    texte = Replace(texte, "�", "u")
    texte = Replace(texte, "�", "u")
    texte = Replace(texte, "�", "u")
    texte = Replace(texte, "�", "c")
    texte = Replace(texte, "�", "oe")

    Do While InStr(1, texte, "  ", vbBinaryCompare) > 0
        texte = Replace(texte, "  ", " ")
    Loop

    R12_NormaliserTexte = Trim$(texte)

End Function

Public Sub R12_Core_TesterConfigurationProfils()

    Dim codesObligatoires As Variant
    Dim code As Variant
    Dim absents As String
    Dim nombre As Long
    Dim fichier As String

    codesObligatoires = Array( _
        "SCORE_CALCIQUE", "TEST_EFFORT", _
        "SCINTIGRAPHIE_MYOCARDIQUE", "SCANNER_THORACIQUE", _
        "RECHERCHE_SAOS", "ECHODOPPLER_VEINEUX", _
        "HOSPITALISATION_CCN", "HOSPITALISATION_AUTRE_CENTRE", _
        "ANGIOSCANNER_PULMONAIRE", "ANGIOSCANNER_TSA", _
        "ANGIOSCANNER_AORTE_MEMBRES_INFERIEURS", _
        "ANGIOSCANNER_ARTERES_RENALES", "IRM_DE_STRESS", _
        "ECHODOPPLER_ARTERIEL_TSA_ET_MEMBRES_INFERIEURS", _
        "AUTRE_EXAMEN")

    For Each code In codesObligatoires
        If Not R12_ProfilExiste(CStr(code)) Then
            absents = absents & CStr(code) & vbCrLf
        End If
    Next code

    fichier = Dir$(R12_DOSSIER_PROFILS & "\*.ini")
    Do While fichier <> ""
        nombre = nombre + 1
        fichier = Dir$()
    Loop

    If absents = "" Then
        MsgBox _
            "Configuration R12 disponible." & vbCrLf & vbCrLf & _
            "Dossier : " & R12_DOSSIER_PROFILS & vbCrLf & _
            "Profils INI lus : " & nombre, _
            vbInformation, _
            "R12 - profils d'examens"
    Else
        MsgBox _
            "Profils obligatoires absents :" & vbCrLf & vbCrLf & _
            absents, _
            vbExclamation, _
            "R12 - profils d'examens"
    End If

End Sub


Public Sub R12_Core_TesterTousProfils()

    Dim fso As Object
    Dim dossier As Object
    Dim fichierObjet As Object
    Dim code As String
    Dim profil As Object
    Dim ordre As Variant
    Dim champ As Variant
    Dim erreurs As String
    Dim nombre As Long
    Dim nombreValides As Long

    Set fso = CreateObject("Scripting.FileSystemObject")

    If Not fso.FolderExists(R12_DOSSIER_PROFILS) Then
        MsgBox _
            "Dossier de profils introuvable :" & vbCrLf & _
            R12_DOSSIER_PROFILS, _
            vbExclamation, _
            "Validation des profils R12"
        Exit Sub
    End If

    Set dossier = fso.GetFolder(R12_DOSSIER_PROFILS)

    For Each fichierObjet In dossier.Files

        If LCase$(fso.GetExtensionName(fichierObjet.Name)) = "ini" Then

            nombre = nombre + 1
            code = UCase$(fso.GetBaseName(fichierObjet.Name))
            Set profil = R12_ChargerProfil(code)

            If UCase$(R12_ProfilValeur( _
                profil, "IDENTITE", "CODE")) <> code Then

                erreurs = erreurs & code & _
                    " : CODE absent ou incoherent." & vbCrLf

            ElseIf R12_ProfilValeur( _
                profil, "IDENTITE", "LIBELLE") = "" Then

                erreurs = erreurs & code & " : LIBELLE absent." & vbCrLf

            ElseIf R12_ProfilValeur( _
                profil, _
                "PREMIER_PARAGRAPHE", _
                "MODELE") = "" Then

                erreurs = erreurs & code & _
                    " : MODELE du premier paragraphe absent." & vbCrLf

            ElseIf R12_ProfilValeur( _
                profil, "STRUCTURE", "ORDRE") = "" Then

                erreurs = erreurs & code & _
                    " : ORDRE des rubriques absent." & vbCrLf

            Else
                ordre = R12_DecouperListe( _
                    R12_ProfilValeur(profil, "STRUCTURE", "ORDRE"))

                For Each champ In ordre
                    If UCase$(CStr(champ)) <> "OBJECTIF" And _
                       UCase$(CStr(champ)) <> "QUESTION" And _
                       UCase$(CStr(champ)) <> _
                            "PRISE_EN_CHARGE_ATTENDUE" Then

                        If R12_ProfilValeur( _
                            profil, _
                            "SELECTION", _
                            CStr(champ)) = "" Then

                            erreurs = erreurs & code & _
                                " : SELECTION absente pour " & _
                                CStr(champ) & "." & vbCrLf
                        End If
                    End If
                Next champ

                If InStr( _
                    1, _
                    erreurs, _
                    code & " :", _
                    vbTextCompare) = 0 Then

                    nombreValides = nombreValides + 1
                End If
            End If

        End If

    Next fichierObjet

    If erreurs = "" And nombre > 0 Then
        MsgBox _
            "OK : " & nombreValides & "/" & nombre & _
            " profils R12 sont structurellement valides.", _
            vbInformation, _
            "Validation des profils R12"
    Else
        MsgBox _
            "Profils controles : " & nombre & vbCrLf & _
            "Profils valides : " & nombreValides & vbCrLf & vbCrLf & _
            erreurs, _
            vbExclamation, _
            "Validation des profils R12"
    End If

End Sub

Public Sub R12_Core_AfficherCatalogueProfils()

    Dim fichier As String
    Dim liste As String
    Dim nombre As Long

    fichier = Dir$(R12_DOSSIER_PROFILS & "\*.ini")

    Do While fichier <> ""
        nombre = nombre + 1
        liste = liste & Replace(fichier, ".ini", "") & vbCrLf
        fichier = Dir$()
    Loop

    MsgBox _
        nombre & " profil(s) disponible(s) :" & vbCrLf & vbCrLf & _
        liste, _
        vbInformation, _
        "Catalogue R12"

End Sub

Public Sub R12_Core_OuvrirDossierProfils()

    If Dir$(R12_DOSSIER_PROFILS, vbDirectory) = "" Then
        MsgBox _
            "Dossier introuvable :" & vbCrLf & R12_DOSSIER_PROFILS, _
            vbExclamation, _
            "Profils R12"
        Exit Sub
    End If

    Shell _
        "explorer.exe " & Chr$(34) & R12_DOSSIER_PROFILS & Chr$(34), _
        vbNormalFocus

End Sub

Public Sub R12_Core_OuvrirProfil()

    Dim code As String
    Dim chemin As String

    code = InputBox( _
        "Code du profil a ouvrir :", _
        "Profils R12", _
        "TEST_EFFORT")

    code = UCase$(Trim$(code))
    If code = "" Then Exit Sub

    chemin = R12_CheminProfil(code)

    If Dir$(chemin) = "" Then
        MsgBox "Profil introuvable :" & vbCrLf & chemin, vbExclamation
        Exit Sub
    End If

    Shell _
        "notepad.exe " & Chr$(34) & chemin & Chr$(34), _
        vbNormalFocus

End Sub
