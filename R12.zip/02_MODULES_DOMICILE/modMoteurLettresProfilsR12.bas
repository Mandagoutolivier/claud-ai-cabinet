Attribute VB_Name = "modMoteurLettresProfilsR12"
Option Explicit
Option Private Module

'===============================================================================
' R12 - MOTEUR DE SELECTION ET D'ASSEMBLAGE SELON LES PROFILS INI
'===============================================================================

Public Const R12_VERSION_MOTEUR As String = "R12-MOTEUR-PROFILS-1"
Public Const R12_MARQUEUR_BROUILLON As String = _
    "[[A_COMPLETER_AVANT_IMPRESSION]]"

Private Const R12_DEBUT_FICHE As String = "---FICHE_PROFIL_R12---"
Private Const R12_FIN_FICHE As String = "---FIN_FICHE_PROFIL_R12---"
Private Const R12_PREFIXE_ID As String = "ID_DEMANDE="
Private Const R12_PREFIXE_PROFIL As String = "CODE_PROFIL="
Private Const R12_DEBUT_CHAMP As String = "---CHAMP:"
Private Const R12_FIN_CHAMP As String = "---FIN_CHAMP:"

Public Function R12_ConstruirePromptProfils( _
    ByVal planDemandes As Collection, _
    ByVal courrierPrincipalCorrige As String) As String

    Dim p As String
    Dim demande As Object
    Dim profil As Object
    Dim ordre As Variant
    Dim champ As Variant
    Dim codeProfil As String
    Dim obligatoire As String
    Dim obligatoireSiPresent As String
    Dim interdit As String
    Dim selection As String
    Dim instruction As String
    Dim longueur As String
    Dim objectif As String

    If planDemandes Is Nothing Then Exit Function
    If planDemandes.Count = 0 Then Exit Function

    p = ""

    R12_AjouterLigne p, _
        "Tu extrais les informations medicales necessaires a des lettres " & _
        "complementaires, selon un profil local different pour chaque demande."
    R12_AjouterLigne p, _
        "Tu ne rediges jamais la lettre, son premier paragraphe, son destinataire, " & _
        "sa formule d'appel, sa formule de politesse ou sa signature."
    R12_AjouterLigne p, _
        "Le programme local a deja decide quelles demandes existent et quel " & _
        "profil doit etre applique. Ne fusionne, ne supprime et ne renomme rien."
    R12_AjouterLigne p, _
        "Chaque information doit figurer dans une seule rubrique. Ne duplique " & _
        "jamais une meme donnee dans plusieurs champs."
    R12_AjouterLigne p, _
        "Une rubrique doit contenir un paragraphe medical coherent. Si une phrase " & _
        "melange plusieurs categories, scinde son contenu entre les champs adaptes."
    R12_AjouterLigne p, _
        "Dans les champs techniques, ne repete pas le nom de la rubrique ni une " & _
        "amorce telle que L'examen clinique retrouve ou L'ECG montre : le VBA " & _
        "ajoutera localement l'amorce definie par le profil."
    R12_AjouterLigne p, _
        "Toutes les rubriques sont redigees a la troisieme personne, sans " & _
        "interlocuteur direct et sans identite du patient."
    R12_AjouterLigne p, _
        "N'utilise jamais je, j', nous, notre, nos, tu, te, toi, vous, votre, " & _
        "vos, me, moi, mon, ma, mes, ni une formule commencant par Merci."
    R12_AjouterLigne p, _
        "Ne reprends jamais les phrases relationnelles de fin du courrier, une " & _
        "promesse d'informer ou une phrase adressee au patient ou au medecin traitant."
    R12_AjouterLigne p, _
        "N'invente aucune donnee. Conserve exactement les dates, doses, valeurs, " & _
        "arteres, gestes, traitements et resultats utiles."
    R12_AjouterLigne p, _
        "Si une rubrique demandee est absente du courrier principal, ecris ABSENT."
    R12_AjouterLigne p, ""

    R12_AjouterLigne p, "DEMANDES ET PROFILS A TRAITER :"

    For Each demande In planDemandes

        codeProfil = UCase$(Trim$(CStr(demande("ProfilCode"))))
        Set profil = R12_ChargerProfil(codeProfil)

        obligatoire = _
            R12_ProfilValeur(profil, "STRUCTURE", "OBLIGATOIRE")
        obligatoireSiPresent = _
            R12_ProfilValeur( _
                profil, _
                "STRUCTURE", _
                "OBLIGATOIRE_SI_PRESENT")
        interdit = _
            R12_ProfilValeur(profil, "STRUCTURE", "INTERDIT")
        longueur = _
            R12_ProfilValeur(profil, "STYLE", "LONGUEUR", "MOYENNE")
        objectif = _
            R12_ProfilValeur(profil, "OBJECTIF", "MODELE")

        R12_AjouterLigne p, _
            "ID_DEMANDE : " & CStr(demande("IDDemande"))
        R12_AjouterLigne p, "CODE_PROFIL : " & codeProfil
        R12_AjouterLigne p, _
            "EXAMEN_OU_AVIS : " & CStr(demande("Intitules"))
        R12_AjouterLigne p, _
            "PASSAGE_DECISIONNEL : " & _
            R12_Aplatir(CStr(demande("PhraseSource")))
        R12_AjouterLigne p, "LONGUEUR_ATTENDUE : " & longueur
        R12_AjouterLigne p, "CHAMPS_OBLIGATOIRES : " & obligatoire
        R12_AjouterLigne p, _
            "CHAMPS_OBLIGATOIRES_SI_PRESENTS : " & obligatoireSiPresent
        R12_AjouterLigne p, "CHAMPS_INTERDITS : " & interdit
        R12_AjouterLigne p, _
            "OBJECTIF_LOCAL_DE_SECOURS : " & objectif

        ordre = R12_DecouperListe( _
            R12_ProfilValeur(profil, "STRUCTURE", "ORDRE"))

        If IsArray(ordre) Then
            For Each champ In ordre
                selection = R12_ProfilValeur( _
                    profil, _
                    "SELECTION", _
                    CStr(champ))
                instruction = R12_ProfilValeur( _
                    profil, _
                    "INSTRUCTIONS", _
                    CStr(champ))

                R12_AjouterLigne p, _
                    "RUBRIQUE " & CStr(champ) & " - SELECTION : " & selection
                R12_AjouterLigne p, _
                    "RUBRIQUE " & CStr(champ) & " - CONSIGNE : " & instruction
            Next champ
        End If

        R12_AjouterLigne p, _
            "MOTIF - CONSIGNE : formule medicale neutre commencant par pour, " & _
            "afin de, dans le cadre de, devant ou en raison de."
        R12_AjouterLigne p, ""

        R12_AjouterLigne p, "FORMAT OBLIGATOIRE POUR CETTE DEMANDE :"
        R12_AjouterLigne p, R12_DEBUT_FICHE
        R12_AjouterLigne p, _
            R12_PREFIXE_ID & CStr(demande("IDDemande"))
        R12_AjouterLigne p, R12_PREFIXE_PROFIL & codeProfil
        R12_AjouterLigne p, R12_DebutChamp("MOTIF")
        R12_AjouterLigne p, "Motif neutre ou ABSENT"
        R12_AjouterLigne p, R12_FinChamp("MOTIF")

        If IsArray(ordre) Then
            For Each champ In ordre
                R12_AjouterLigne p, R12_DebutChamp(CStr(champ))
                R12_AjouterLigne p, _
                    "Contenu de la rubrique " & CStr(champ) & " ou ABSENT"
                R12_AjouterLigne p, R12_FinChamp(CStr(champ))
            Next champ
        End If

        R12_AjouterLigne p, R12_FIN_FICHE
        R12_AjouterLigne p, ""

    Next demande

    R12_AjouterLigne p, _
        "N'ecris rien en dehors des fiches. N'utilise ni Markdown, ni JSON, " & _
        "ni liste a puces."
    R12_AjouterLigne p, ""
    R12_AjouterLigne p, "COURRIER PRINCIPAL CORRIGE ET ANONYMISE :"
    R12_AjouterLigne p, "--------------------"
    p = p & courrierPrincipalCorrige & vbCrLf
    R12_AjouterLigne p, "--------------------"

    R12_ConstruirePromptProfils = p

End Function

Public Function R12_ConvertirReponseProfils( _
    ByVal planDemandes As Collection, _
    ByVal reponseStructuree As String, _
    ByVal courrierPrincipalCorrige As String, _
    ByRef messageConversion As String, _
    ByRef nombreBrouillons As Long) As String

    Dim fiches As Object
    Dim demande As Object
    Dim profil As Object
    Dim brouillons As Collection
    Dim brouillon As Object
    Dim blocFiche As String
    Dim corpsTagge As String
    Dim corpsFinal As String
    Dim raisons As String
    Dim blocs As String
    Dim cleDestination As String
    Dim idDemande As String
    Dim codeProfil As String
    Dim messageRevision As String

    On Error GoTo GestionErreur

    messageConversion = ""
    nombreBrouillons = 0
    Set fiches = R12_ExtraireFiches(reponseStructuree)
    Set brouillons = New Collection

    For Each demande In planDemandes

        idDemande = CStr(demande("IDDemande"))
        codeProfil = UCase$(Trim$(CStr(demande("ProfilCode"))))
        Set profil = R12_ChargerProfil(codeProfil)

        blocFiche = ""
        If fiches.Exists(UCase$(idDemande)) Then
            blocFiche = CStr(fiches(UCase$(idDemande)))
        End If

        raisons = ""
        corpsTagge = R12_ConstruireCorpsSelonProfil( _
            demande, profil, blocFiche, courrierPrincipalCorrige, raisons)

        If Trim$(corpsTagge) = "" Then
            raisons = R12_AjouterRaison(raisons, "corps vide")
            corpsTagge = R12_TagChamp("A_COMPLETER") & vbCrLf & _
                R12_MarqueurACompleter(codeProfil, "CORPS")
        End If

        If raisons <> "" Then
            nombreBrouillons = nombreBrouillons + 1
            R12_AjouterChampTagge corpsTagge, "A_COMPLETER", _
                R12_MARQUEUR_BROUILLON & " : " & codeProfil & " - " & raisons
        End If

        cleDestination = UCase$(Trim$(CStr(demande("CleDestination"))))
        If cleDestination = "" Then cleDestination = "A_COMPLETER"

        Set brouillon = CreateObject("Scripting.Dictionary")
        brouillon.CompareMode = vbTextCompare
        brouillon("IDDemande") = idDemande
        brouillon("CodeProfil") = codeProfil
        brouillon("CleDestination") = cleDestination
        brouillon("CorpsTagge") = corpsTagge
        brouillon("Raisons") = raisons
        brouillon("RevisionActive") = R12_RevisionFinaleActive(profil)
        brouillons.Add brouillon

        If raisons <> "" Then
            messageConversion = messageConversion & _
                idDemande & " / " & codeProfil & " : " & raisons & vbCrLf
        End If

    Next demande

    R12_ReviserBrouillonsParAPI brouillons, messageRevision

    For Each brouillon In brouillons
        corpsFinal = R12_FinaliserCorpsTagge(CStr(brouillon("CorpsTagge")))

        If blocs <> "" Then blocs = blocs & vbCrLf & vbCrLf
        blocs = blocs & _
            BALISE_DEBUT_DEMANDE_DESTINATION & vbCrLf & _
            PREFIXE_CLE_DESTINATION & CStr(brouillon("CleDestination")) & vbCrLf & _
            BALISE_DEBUT_CORPS_DESTINATION & vbCrLf & _
            corpsFinal & vbCrLf & _
            BALISE_FIN_CORPS_DESTINATION & vbCrLf & _
            BALISE_FIN_DEMANDE_DESTINATION
    Next brouillon

    If nombreBrouillons = 0 Then
        messageConversion = planDemandes.Count & _
            " lettre(s) assemblee(s) selon les profils R12."
    Else
        messageConversion = planDemandes.Count & " lettre(s) assemblee(s), dont " & _
            nombreBrouillons & " brouillon(s) a completer." & vbCrLf & _
            messageConversion
    End If

    If Trim$(messageRevision) <> "" Then
        messageConversion = messageConversion & vbCrLf & messageRevision
    End If

    R12_ConvertirReponseProfils = blocs
    Exit Function

GestionErreur:
    messageConversion = "Erreur R12 : " & Err.Number & " - " & Err.Description
    R12_ConvertirReponseProfils = ""
End Function

Private Function R12_ConstruireCorpsSelonProfil( _
    ByVal demande As Object, _
    ByVal profil As Object, _
    ByVal blocFiche As String, _
    ByVal courrier As String, _
    ByRef raisons As String) As String

    Dim corps As String
    Dim motif As String
    Dim ordre As Variant
    Dim champ As Variant
    Dim valeur As String
    Dim obligatoire As String
    Dim obligatoireSiPresent As String
    Dim interdit As String
    Dim prefixe As String
    Dim objectifLocal As String
    Dim codeProfil As String

    codeProfil = UCase$(Trim$(CStr(demande("ProfilCode"))))

    If profil Is Nothing Then
        raisons = R12_AjouterRaison(raisons, "profil absent")
    End If

    motif = R12_ExtraireChamp(blocFiche, "MOTIF")
    motif = R12_ValiderValeur(motif, "MOTIF", raisons)

    If motif = "" Then motif = Trim$(CStr(demande("MotifLocal")))
    If motif = "" Then
        motif = R12_ProfilValeur( _
            profil, _
            "MOTIF", _
            "DEFAUT", _
            "dans le contexte expos� ci-dessous")
    End If

    motif = R12_NormaliserMotif(motif)

    corps = R12_TagChamp("INTRO") & vbCrLf & _
        R12_ConstruirePremierParagraphe( _
            demande, _
            profil, _
            courrier, _
            motif)

    obligatoire = _
        R12_ProfilValeur(profil, "STRUCTURE", "OBLIGATOIRE")
    obligatoireSiPresent = _
        R12_ProfilValeur( _
            profil, _
            "STRUCTURE", _
            "OBLIGATOIRE_SI_PRESENT")
    interdit = _
        R12_ProfilValeur(profil, "STRUCTURE", "INTERDIT")
    objectifLocal = _
        R12_ProfilValeur(profil, "OBJECTIF", "MODELE")

    ordre = R12_DecouperListe( _
        R12_ProfilValeur(profil, "STRUCTURE", "ORDRE"))

    If IsArray(ordre) Then
        For Each champ In ordre

            If Not R12_ListeContient(interdit, CStr(champ)) Then

                valeur = R12_ExtraireChamp(blocFiche, CStr(champ))
                valeur = R12_ValiderValeur(valeur, CStr(champ), raisons)

                If valeur = "" Then
                    valeur = R12_ExtraireChampLocal( _
                        courrier, _
                        CStr(champ), _
                        profil)
                    valeur = R12_ValiderValeur( _
                        valeur, _
                        CStr(champ) & " local", _
                        raisons)
                End If

                If (UCase$(CStr(champ)) = "OBJECTIF" Or _
                    UCase$(CStr(champ)) = "QUESTION" Or _
                    UCase$(CStr(champ)) = "PRISE_EN_CHARGE_ATTENDUE") And _
                    valeur = "" Then

                    valeur = objectifLocal
                End If

                If valeur = "" Then

                    If R12_ListeContient(obligatoire, CStr(champ)) Then
                        valeur = R12_MarqueurACompleter( _
                            codeProfil, _
                            CStr(champ))
                        raisons = R12_AjouterRaison( _
                            raisons, _
                            CStr(champ) & " obligatoire manquant")

                    ElseIf R12_ListeContient( _
                        obligatoireSiPresent, _
                        CStr(champ)) Then

                        If R12_SourceContientChamp( _
                            courrier, _
                            CStr(champ), _
                            profil) Then

                            valeur = R12_MarqueurACompleter( _
                                codeProfil, _
                                CStr(champ))
                            raisons = R12_AjouterRaison( _
                                raisons, _
                                CStr(champ) & " present mais non extrait")
                        End If
                    End If
                End If

                If valeur <> "" Then
                    prefixe = R12_ProfilValeur( _
                        profil, _
                        "PREFIXES", _
                        CStr(champ))
                    valeur = R12_AvecPrefixe(valeur, prefixe)
                    R12_AjouterChampTagge corps, CStr(champ), valeur
                End If

            End If

        Next champ
    End If

    R12_ConstruireCorpsSelonProfil = corps

End Function

Private Function R12_TagChamp(ByVal champ As String) As String
    R12_TagChamp = "[[R12_CHAMP:" & UCase$(Trim$(champ)) & "]]"
End Function

Private Sub R12_AjouterChampTagge( _
    ByRef corps As String, _
    ByVal champ As String, _
    ByVal texte As String)

    texte = Trim$(texte)
    If texte = "" Then Exit Sub

    If corps <> "" Then corps = corps & vbCrLf
    corps = corps & R12_TagChamp(champ) & vbCrLf & texte
End Sub

Private Function R12_ConstruirePremierParagraphe( _
    ByVal demande As Object, _
    ByVal profil As Object, _
    ByVal courrier As String, _
    ByVal motif As String) As String

    Dim modele As String
    Dim patient As String
    Dim age As String
    Dim ageSegment As String
    Dim examen As String
    Dim article As String

    modele = R12_ProfilValeur( _
        profil, _
        "PREMIER_PARAGRAPHE", _
        "MODELE", _
        "Merci de r�aliser {ARTICLE_EXAMEN} � {PATIENT}{AGE_SEGMENT}, {MOTIF}.")

    patient = Trim$(gPatient.civilite & " " & MARQUEUR_PATIENT)
    If Trim$(gPatient.civilite) = "" Then
        patient = "Monsieur/Madame " & MARQUEUR_PATIENT
    End If

    age = R12_ExtraireAgeTexte(courrier)
    If age <> "" Then ageSegment = ", " & age & " ans"

    examen = R12_ProfilValeur(profil, "IDENTITE", "LIBELLE")

    If UCase$(CStr(demande("ProfilCode"))) = R12_PROFIL_SECOURS Then
        examen = CStr(demande("Intitules"))
    End If

    article = R12_ProfilValeur(profil, "IDENTITE", "ARTICLE", "un")

    modele = Replace(modele, "{PATIENT}", patient, 1, -1, vbTextCompare)
    modele = Replace(modele, "{AGE}", age, 1, -1, vbTextCompare)
    modele = Replace( _
        modele, _
        "{AGE_SEGMENT}", _
        ageSegment, _
        1, _
        -1, _
        vbTextCompare)
    modele = Replace(modele, "{EXAMEN}", examen, 1, -1, vbTextCompare)
    modele = Replace( _
        modele, _
        "{ARTICLE_EXAMEN}", _
        article & " " & examen, _
        1, _
        -1, _
        vbTextCompare)
    modele = Replace(modele, "{MOTIF}", motif, 1, -1, vbTextCompare)

    R12_ConstruirePremierParagraphe = _
        R12_CorrigerEspacesPonctuation(modele)

End Function

Private Function R12_ExtraireFiches(ByVal texte As String) As Object

    Dim resultat As Object
    Dim positionRecherche As Long
    Dim positionDebut As Long
    Dim positionFin As Long
    Dim bloc As String
    Dim idDemande As String

    Set resultat = CreateObject("Scripting.Dictionary")
    resultat.CompareMode = vbTextCompare

    positionRecherche = 1

    Do
        positionDebut = InStr( _
            positionRecherche, _
            texte, _
            R12_DEBUT_FICHE, _
            vbTextCompare)

        If positionDebut = 0 Then Exit Do

        positionFin = InStr( _
            positionDebut + Len(R12_DEBUT_FICHE), _
            texte, _
            R12_FIN_FICHE, _
            vbTextCompare)

        If positionFin = 0 Then Exit Do

        bloc = Mid$( _
            texte, _
            positionDebut, _
            positionFin - positionDebut + Len(R12_FIN_FICHE))

        idDemande = R12_LireLigneApresPrefixe(bloc, R12_PREFIXE_ID)

        If idDemande <> "" Then
            resultat(UCase$(idDemande)) = bloc
        End If

        positionRecherche = positionFin + Len(R12_FIN_FICHE)
    Loop

    Set R12_ExtraireFiches = resultat

End Function

Private Function R12_ExtraireChamp( _
    ByVal bloc As String, _
    ByVal champ As String) As String

    Dim debut As String
    Dim fin As String
    Dim positionDebut As Long
    Dim positionFin As Long
    Dim positionTexte As Long

    If Trim$(bloc) = "" Then Exit Function

    debut = R12_DebutChamp(champ)
    fin = R12_FinChamp(champ)

    positionDebut = InStr(1, bloc, debut, vbTextCompare)
    If positionDebut = 0 Then Exit Function

    positionTexte = positionDebut + Len(debut)
    positionFin = InStr(positionTexte, bloc, fin, vbTextCompare)
    If positionFin = 0 Then Exit Function

    R12_ExtraireChamp = Mid$( _
        bloc, _
        positionTexte, _
        positionFin - positionTexte)

End Function

Private Function R12_DebutChamp(ByVal champ As String) As String
    R12_DebutChamp = R12_DEBUT_CHAMP & UCase$(Trim$(champ)) & "---"
End Function

Private Function R12_FinChamp(ByVal champ As String) As String
    R12_FinChamp = R12_FIN_CHAMP & UCase$(Trim$(champ)) & "---"
End Function

Private Function R12_LireLigneApresPrefixe( _
    ByVal texte As String, _
    ByVal prefixe As String) As String

    Dim position As Long
    Dim positionFin As Long

    position = InStr(1, texte, prefixe, vbTextCompare)
    If position = 0 Then Exit Function

    position = position + Len(prefixe)
    positionFin = InStr(position, texte, vbCr, vbBinaryCompare)
    If positionFin = 0 Then
        positionFin = InStr(position, texte, vbLf, vbBinaryCompare)
    End If
    If positionFin = 0 Then positionFin = Len(texte) + 1

    R12_LireLigneApresPrefixe = _
        Trim$(Mid$(texte, position, positionFin - position))

End Function

Private Function R12_ValiderValeur( _
    ByVal valeur As String, _
    ByVal nomRubrique As String, _
    ByRef raisons As String) As String

    valeur = R12_NettoyerValeur(valeur)
    valeur = R12_NeutraliserAdresseDirecteSimple(valeur, nomRubrique)

    If valeur = "" Then Exit Function

    If R12_ContientAdresseDirecte(valeur) Then
        raisons = R12_AjouterRaison( _
            raisons, _
            nomRubrique & " contient une adresse directe")
        Exit Function
    End If

    If InStr(1, valeur, MARQUEUR_PATIENT, vbTextCompare) > 0 Then
        raisons = R12_AjouterRaison( _
            raisons, _
            nomRubrique & " contient l'identite patient")
        Exit Function
    End If

    R12_ValiderValeur = valeur

End Function

Private Function R12_NeutraliserAdresseDirecteSimple( _
    ByVal valeur As String, _
    ByVal nomRubrique As String) As String

    Dim t As String

    valeur = Trim$(valeur)
    t = LCase$(valeur)

    valeur = Replace(valeur, "Il me signale", "Il signale", 1, -1, vbTextCompare)
    valeur = Replace(valeur, "Elle me signale", "Elle signale", 1, -1, vbTextCompare)
    valeur = Replace(valeur, "Il m'indique", "Il indique", 1, -1, vbTextCompare)
    valeur = Replace(valeur, "Elle m'indique", "Elle indique", 1, -1, vbTextCompare)
    valeur = Replace(valeur, "Il me rapporte", "Il rapporte", 1, -1, vbTextCompare)
    valeur = Replace(valeur, "Elle me rapporte", "Elle rapporte", 1, -1, vbTextCompare)

    If InStr(1, UCase$(nomRubrique), "EXAMEN_CLINIQUE", vbTextCompare) > 0 Then
        If Left$(LCase$(valeur), 12) = "je retrouve " Then
            valeur = "L'examen clinique retrouve " & Mid$(valeur, 13)
        End If
    ElseIf InStr(1, UCase$(nomRubrique), "ECG", vbTextCompare) > 0 Then
        If Left$(LCase$(valeur), 12) = "je retrouve " Then
            valeur = "L'electrocardiogramme montre " & Mid$(valeur, 13)
        End If
    End If

    R12_NeutraliserAdresseDirecteSimple = valeur
End Function

Private Function R12_NettoyerValeur(ByVal valeur As String) As String

    valeur = Replace(valeur, vbCrLf, " ")
    valeur = Replace(valeur, vbCr, " ")
    valeur = Replace(valeur, vbLf, " ")
    valeur = Replace(valeur, vbTab, " ")
    valeur = Replace(valeur, Chr$(160), " ")
    valeur = Replace(valeur, "**", "")
    valeur = Replace(valeur, "```", "")

    Do While InStr(1, valeur, "  ", vbBinaryCompare) > 0
        valeur = Replace(valeur, "  ", " ")
    Loop

    valeur = Trim$(valeur)

    If UCase$(valeur) = "ABSENT" Or _
       UCase$(valeur) = "NEANT" Or _
       UCase$(valeur) = "AUCUN" Then
        valeur = ""
    End If

    R12_NettoyerValeur = valeur

End Function

Private Function R12_ContientAdresseDirecte(ByVal texte As String) As Boolean

    Dim t As String
    Dim mots As Variant
    Dim mot As Variant

    t = R12_NormaliserTexte(texte)
    t = Replace(t, "'", " ")
    t = Replace(t, ".", " ")
    t = Replace(t, ",", " ")
    t = Replace(t, ";", " ")
    t = Replace(t, ":", " ")
    t = Replace(t, "!", " ")
    t = Replace(t, "?", " ")
    t = " " & t & " "

    mots = Array( _
        " je ", " j ", " nous ", " notre ", " nos ", _
        " tu ", " te ", " toi ", " vous ", " votre ", " vos ", _
        " me ", " moi ", " mon ", " ma ", " mes ", " merci ")

    For Each mot In mots
        If InStr(1, t, CStr(mot), vbTextCompare) > 0 Then
            R12_ContientAdresseDirecte = True
            Exit Function
        End If
    Next mot

End Function

Private Function R12_ExtraireChampLocal( _
    ByVal courrier As String, _
    ByVal champ As String, _
    ByVal profil As Object) As String

    Dim paragraphes As Variant
    Dim paragraphe As Variant
    Dim selection As String
    Dim resultat As String
    Dim texte As String

    selection = R12_ProfilValeur(profil, "SELECTION", champ)
    If Trim$(selection) = "" Then Exit Function

    paragraphes = R12_Paragraphes(courrier)

    For Each paragraphe In paragraphes
        texte = Trim$(CStr(paragraphe))
        If texte <> "" Then
            If Not R12_EstParagrapheRelationnel(texte) Then
                If R12_ParagrapheCorrespondChamp( _
                    texte, _
                    champ, _
                    selection) Then

                    R12_AjouterTexteSansDoublon resultat, texte
                End If
            End If
        End If
    Next paragraphe

    R12_ExtraireChampLocal = resultat

End Function

Private Function R12_SourceContientChamp( _
    ByVal courrier As String, _
    ByVal champ As String, _
    ByVal profil As Object) As Boolean

    R12_SourceContientChamp = _
        (R12_ExtraireChampLocal(courrier, champ, profil) <> "")

End Function

Private Function R12_ParagrapheCorrespondChamp( _
    ByVal paragraphe As String, _
    ByVal champ As String, _
    ByVal selection As String) As Boolean

    Dim t As String
    Dim termes As Variant
    Dim terme As Variant

    t = R12_NormaliserTexte(paragraphe)
    champ = UCase$(Trim$(champ))

    Select Case champ
        Case "EXAMEN_CLINIQUE", "EXAMEN_VASCULAIRE"
            If InStr(1, t, "examen clinique", vbTextCompare) > 0 Or _
               InStr(1, t, "pression arterielle", vbTextCompare) > 0 Or _
               InStr(1, t, "bruits du coeur", vbTextCompare) > 0 Or _
               InStr(1, t, "auscultation", vbTextCompare) > 0 Or _
               InStr(1, t, "pouls", vbTextCompare) > 0 Then
                R12_ParagrapheCorrespondChamp = True
                Exit Function
            End If

        Case "ECG"
            If InStr(1, t, "electrocardiogramme", vbTextCompare) > 0 Or _
               InStr(1, t, " ecg ", vbTextCompare) > 0 Then
                R12_ParagrapheCorrespondChamp = True
                Exit Function
            End If

        Case "ECHOGRAPHIE"
            If InStr(1, t, "echocardiograph", vbTextCompare) > 0 Or _
               InStr(1, t, "echographie cardiaque", vbTextCompare) > 0 Or _
               InStr(1, t, "echoscopie", vbTextCompare) > 0 Then
                R12_ParagrapheCorrespondChamp = True
                Exit Function
            End If

        Case "HOLTER"
            If InStr(1, t, "holter", vbTextCompare) > 0 Then
                R12_ParagrapheCorrespondChamp = True
                Exit Function
            End If

        Case "MAPA", "HTA_MAPA"
            If InStr(1, t, "mapa", vbTextCompare) > 0 Or _
               InStr(1, t, "holter tensionnel", vbTextCompare) > 0 Or _
               InStr(1, t, "non dipper", vbTextCompare) > 0 Then
                R12_ParagrapheCorrespondChamp = True
                Exit Function
            End If

        Case Else
            If InStr(1, champ, "BIOLOGIE", vbTextCompare) > 0 Then
                If InStr(1, t, "biologie", vbTextCompare) > 0 Or _
                   InStr(1, t, "bilan biologique", vbTextCompare) > 0 Then
                    R12_ParagrapheCorrespondChamp = True
                    Exit Function
                End If
            End If
    End Select

    termes = Split(selection, ";")

    For Each terme In termes
        terme = R12_NormaliserTexte(CStr(terme))
        If terme <> "" Then
            If InStr(1, t, CStr(terme), vbTextCompare) > 0 Then
                R12_ParagrapheCorrespondChamp = True
                Exit Function
            End If
        End If
    Next terme

End Function

Private Function R12_EstParagrapheRelationnel( _
    ByVal texte As String) As Boolean

    Dim t As String

    t = R12_NormaliserTexte(texte)

    R12_EstParagrapheRelationnel = _
        InStr(1, t, "merci de votre confiance", vbTextCompare) > 0 Or _
        InStr(1, t, "je vous remercie", vbTextCompare) > 0 Or _
        InStr(1, t, "je vous tiendrai", vbTextCompare) > 0 Or _
        InStr(1, t, "je te tiendrai", vbTextCompare) > 0 Or _
        InStr(1, t, "amities", vbTextCompare) > 0 Or _
        InStr(1, t, "bien confraternellement", vbTextCompare) > 0 Or _
        InStr(1, t, "docteur olivier mandagout", vbTextCompare) > 0

End Function

Private Sub R12_AjouterTexteSansDoublon( _
    ByRef resultat As String, _
    ByVal texte As String)

    If InStr(1, resultat, texte, vbTextCompare) > 0 Then Exit Sub

    If resultat <> "" Then resultat = resultat & " "
    resultat = resultat & Trim$(texte)

End Sub

Private Function R12_AvecPrefixe( _
    ByVal valeur As String, _
    ByVal prefixe As String) As String

    Dim tValeur As String
    Dim tPrefixe As String

    valeur = Trim$(valeur)
    prefixe = Trim$(prefixe)

    If valeur = "" Then Exit Function

    If Left$(valeur, 2) = "[[" Then
        R12_AvecPrefixe = valeur
        Exit Function
    End If

    If prefixe <> "" Then
        tValeur = R12_NormaliserTexte(valeur)
        tPrefixe = R12_NormaliserTexte(prefixe)

        If Left$(tValeur, Len(tPrefixe)) = tPrefixe Then
            'L'amorce attendue est deja presente : ne rien dupliquer.
        ElseIf R12_ValeurDejaRedigee(valeur) Then
            'La rubrique contient deja une phrase medicale autonome.
            valeur = R12_MajusculeInitiale(valeur)
        Else
            valeur = prefixe & " " & R12_MinusculeInitiale(valeur)
        End If
    Else
        valeur = R12_MajusculeInitiale(valeur)
    End If

    valeur = Trim$(valeur)

    If Right$(valeur, 1) <> "." And _
       Right$(valeur, 1) <> ";" And _
       Right$(valeur, 1) <> ":" And _
       Right$(valeur, 1) <> "?" And _
       Right$(valeur, 1) <> "!" Then
        valeur = valeur & "."
    End If

    R12_AvecPrefixe = valeur

End Function

Private Function R12_ValeurDejaRedigee( _
    ByVal valeur As String) As Boolean

    Dim t As String
    Dim amorces As Variant
    Dim amorce As Variant
    Dim verbes As Variant
    Dim verbe As Variant

    t = " " & R12_NormaliserTexte(valeur) & " "

    amorces = Array( _
        " l'examen clinique ", " a l'examen clinique ", _
        " l'electrocardiogramme ", " l'ecg ", _
        " l'echocardiographie ", " l'echographie cardiaque ", _
        " le holter ", " la mapa ", _
        " le bilan biologique ", " la biologie ", _
        " le traitement ", " son traitement ", _
        " le patient ", " la patiente ", " il ", " elle ")

    For Each amorce In amorces
        If Left$(t, Len(CStr(amorce))) = CStr(amorce) Then
            R12_ValeurDejaRedigee = True
            Exit Function
        End If
    Next amorce

    verbes = Array( _
        " est ", " sont ", " presente ", " presente ", _
        " montre ", " retrouve ", " revele ", " comprend ", _
        " associe ", " repose ", " recoit ", " beneficie ", _
        " reste ", " rapporte ", " signale ")

    For Each verbe In verbes
        If InStr(1, Left$(t, 160), CStr(verbe), vbTextCompare) > 0 Then
            R12_ValeurDejaRedigee = True
            Exit Function
        End If
    Next verbe

End Function

Private Function R12_NormaliserMotif(ByVal motif As String) As String

    Dim t As String

    motif = Trim$(motif)
    motif = R12_RetirerPonctuationFin(motif)
    t = R12_NormaliserTexte(motif)

    If motif = "" Then
        R12_NormaliserMotif = "dans le contexte expos� ci-dessous"
        Exit Function
    End If

    If Left$(t, 5) = "pour " Or _
       Left$(t, 8) = "afin de " Or _
       Left$(t, 17) = "dans le cadre de " Or _
       Left$(t, 17) = "dans ce contexte " Or _
       Left$(t, 17) = "dans un contexte " Or _
       Left$(t, 7) = "devant " Or _
       Left$(t, 12) = "en raison de " Or _
       Left$(t, 14) = "compte tenu de" Or _
       Left$(t, 10) = "du fait de" Or _
       Left$(t, 12) = "d'autant que" Or _
       Left$(t, 19) = "compte tenu du fait" Then

        R12_NormaliserMotif = motif
    Else
        R12_NormaliserMotif = "dans le contexte de " & _
            R12_MinusculeInitiale(motif)
    End If

End Function

Private Function R12_RetirerPonctuationFin( _
    ByVal texte As String) As String

    texte = Trim$(texte)

    Do While Len(texte) > 0
        If Right$(texte, 1) = "." Or _
           Right$(texte, 1) = ";" Or _
           Right$(texte, 1) = "," Or _
           Right$(texte, 1) = ":" Then
            texte = Trim$(Left$(texte, Len(texte) - 1))
        Else
            Exit Do
        End If
    Loop

    R12_RetirerPonctuationFin = texte

End Function

Private Function R12_CorrigerEspacesPonctuation( _
    ByVal texte As String) As String

    Do While InStr(1, texte, "  ", vbBinaryCompare) > 0
        texte = Replace(texte, "  ", " ")
    Loop

    texte = Replace(texte, " ,", ",")
    texte = Replace(texte, " .", ".")
    texte = Replace(texte, ", ,", ",")
    texte = Replace(texte, "..", ".")
    texte = Replace(texte, ",.", ".")

    R12_CorrigerEspacesPonctuation = Trim$(texte)

End Function

Private Function R12_ExtraireAgeTexte(ByVal texte As String) As String

    Dim regex As Object
    Dim correspondances As Object

    Set regex = CreateObject("VBScript.RegExp")

    With regex
        .Global = False
        .IgnoreCase = True
        .Pattern = "([0-9]{1,3})[ ]*ans"
    End With

    If regex.Test(texte) Then
        Set correspondances = regex.Execute(texte)
        R12_ExtraireAgeTexte = correspondances(0).SubMatches(0)
    End If

End Function

Private Function R12_Paragraphes(ByVal texte As String) As Variant

    texte = Replace(texte, vbCrLf, vbCr)
    texte = Replace(texte, vbLf, vbCr)
    texte = Replace(texte, Chr$(11), vbCr)
    texte = Replace(texte, Chr$(12), vbCr)
    R12_Paragraphes = Split(texte, vbCr)

End Function

Private Sub R12_AjouterParagraphe( _
    ByRef corps As String, _
    ByVal texte As String)

    texte = Trim$(texte)
    If texte = "" Then Exit Sub

    If corps <> "" Then corps = corps & vbCr
    corps = corps & texte

End Sub

Private Function R12_MarqueurACompleter( _
    ByVal codeProfil As String, _
    ByVal champ As String) As String

    R12_MarqueurACompleter = _
        "[[A_COMPLETER_AVANT_IMPRESSION : " & _
        UCase$(Trim$(codeProfil)) & "/" & _
        UCase$(Trim$(champ)) & "]]"

End Function

Private Function R12_AjouterRaison( _
    ByVal raisons As String, _
    ByVal raison As String) As String

    raison = Trim$(raison)
    If raison = "" Then
        R12_AjouterRaison = raisons
        Exit Function
    End If

    If InStr(1, raisons, raison, vbTextCompare) > 0 Then
        R12_AjouterRaison = raisons
        Exit Function
    End If

    If raisons <> "" Then raisons = raisons & "; "
    R12_AjouterRaison = raisons & raison

End Function

Private Function R12_Aplatir(ByVal texte As String) As String

    texte = Replace(texte, vbCr, " ")
    texte = Replace(texte, vbLf, " ")
    texte = Replace(texte, vbTab, " ")

    Do While InStr(1, texte, "  ", vbBinaryCompare) > 0
        texte = Replace(texte, "  ", " ")
    Loop

    R12_Aplatir = Trim$(texte)

End Function

Private Function R12_MajusculeInitiale(ByVal texte As String) As String

    texte = Trim$(texte)
    If texte = "" Then Exit Function

    R12_MajusculeInitiale = UCase$(Left$(texte, 1)) & Mid$(texte, 2)

End Function

Private Function R12_MinusculeInitiale(ByVal texte As String) As String

    Dim c1 As String
    Dim c2 As String

    texte = Trim$(texte)
    If texte = "" Then Exit Function

    'Ne jamais casser un medicament, un acronyme ou une valeur commencant par
    'deux majuscules : BISOPROLOL, ECG, NT-proBNP, etc.
    If Len(texte) >= 2 Then
        c1 = Left$(texte, 1)
        c2 = Mid$(texte, 2, 1)

        If c1 = UCase$(c1) And c1 <> LCase$(c1) And _
           c2 = UCase$(c2) And c2 <> LCase$(c2) Then

            R12_MinusculeInitiale = texte
            Exit Function
        End If
    End If

    R12_MinusculeInitiale = LCase$(Left$(texte, 1)) & Mid$(texte, 2)

End Function

Private Sub R12_AjouterLigne( _
    ByRef p As String, _
    ByVal ligne As String)

    p = p & ligne & vbCrLf

End Sub
