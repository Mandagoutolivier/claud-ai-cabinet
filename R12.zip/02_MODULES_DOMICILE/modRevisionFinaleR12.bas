Attribute VB_Name = "modRevisionFinaleR12"
Option Explicit
Option Private Module

'===============================================================================
' R12 - TROISIEME APPEL API : REVISION REDACTIONNELLE CONTROLEE
'
' L'API 3 ne selectionne aucune nouvelle donnee. Elle revise uniquement les
' paragraphes deja assembles par le VBA, en conservant les tags, l'ordre des
' rubriques, les valeurs numeriques et le marqueur [[PATIENT]].
'===============================================================================

Public Const R12_VERSION_REVISION As String = "R12-REVISION-FINALE-1"
Public Const R12_MARQUEUR_PARAGRAPHE As String = "[[R12_PARA]]"

Private Const R12_DEBUT_REVISION As String = "---REVISION_LETTRE_R12---"
Private Const R12_FIN_REVISION As String = "---FIN_REVISION_LETTRE_R12---"
Private Const R12_PREFIXE_ID_REVISION As String = "ID_DEMANDE="
Private Const R12_PREFIXE_CORPS As String = "CORPS_TAGGE:"

Public Sub R12_ReviserBrouillonsParAPI( _
    ByVal brouillons As Collection, _
    ByRef messageRevision As String)

    Dim prompt As String
    Dim reponse As String
    Dim blocs As Object
    Dim brouillon As Object
    Dim bloc As String
    Dim corpsRevise As String
    Dim raison As String
    Dim nombreEligibles As Long
    Dim nombreRevises As Long
    Dim idDemande As String
    Dim profil As Object

    messageRevision = ""
    If brouillons Is Nothing Then Exit Sub

    prompt = R12_ConstruirePromptRevision(brouillons, nombreEligibles)

    If nombreEligibles = 0 Then
        messageRevision = "Revision API 3 non requise par les profils." 
        Exit Sub
    End If

    Application.StatusBar = _
        "Revision finale des courriers complementaires..."
    DoEvents

    reponse = AppelerOpenAI(prompt)

    If Trim$(reponse) = "" Then
        messageRevision = _
            "L'appel API 3 n'a pas produit de texte : les brouillons locaux " & _
            "ont ete conserves sans revision finale."
        Exit Sub
    End If

    Set blocs = R12_ExtraireBlocsRevision(reponse)

    For Each brouillon In brouillons

        If CBool(brouillon("RevisionActive")) Then

            If InStr(1, CStr(brouillon("CorpsTagge")), _
                "[[A_COMPLETER_AVANT_IMPRESSION", vbTextCompare) = 0 Then

                idDemande = UCase$(Trim$(CStr(brouillon("IDDemande"))))
                bloc = ""

                If blocs.Exists(idDemande) Then
                    bloc = CStr(blocs(idDemande))
                End If

                corpsRevise = R12_ExtraireCorpsRevision(bloc)
                raison = ""

                If R12_RevisionValide( _
                    CStr(brouillon("CorpsTagge")), _
                    corpsRevise, _
                    raison) Then

                    brouillon("CorpsTagge") = corpsRevise
                    nombreRevises = nombreRevises + 1

                Else
                    If raison = "" Then raison = "reponse absente ou non conforme"
                    messageRevision = messageRevision & _
                        idDemande & " : revision API 3 ignoree (" & raison & ")." & vbCrLf
                End If
            End If
        End If

    Next brouillon

    messageRevision = _
        CStr(nombreRevises) & "/" & CStr(nombreEligibles) & _
        " lettre(s) revisee(s) par l'API 3." & _
        IIf(Trim$(messageRevision) <> "", vbCrLf & messageRevision, "")

End Sub

Private Function R12_ConstruirePromptRevision( _
    ByVal brouillons As Collection, _
    ByRef nombreEligibles As Long) As String

    Dim p As String
    Dim brouillon As Object
    Dim profil As Object
    Dim niveau As String

    nombreEligibles = 0
    p = ""

    R12_AjouterLigneRevision p, _
        "Tu revises la redaction de courriers medicaux complementaires deja assembles."
    R12_AjouterLigneRevision p, _
        "Tu es un editeur final : tu n'ajoutes, ne supprimes et ne deplaces aucune information medicale."
    R12_AjouterLigneRevision p, _
        "Conserve exactement tous les tags [[R12_CHAMP:...]], dans le meme ordre, un seul exemplaire chacun."
    R12_AjouterLigneRevision p, _
        "Ne fusionne jamais deux rubriques et ne cree aucune rubrique nouvelle."
    R12_AjouterLigneRevision p, _
        "Conserve exactement [[PATIENT]], l'examen demande, les dates, doses, valeurs, pourcentages, arteres, gestes et traitements."
    R12_AjouterLigneRevision p, _
        "Ameliore uniquement la grammaire, les transitions, la fluidite et les repetitions a l'interieur de chaque rubrique."
    R12_AjouterLigneRevision p, _
        "Hors du champ INTRO, redige a la troisieme personne, sans je, nous, tu, vous, votre, vos ni promesse d'information."
    R12_AjouterLigneRevision p, _
        "N'ajoute ni formule d'appel, ni politesse, ni signature."
    R12_AjouterLigneRevision p, _
        "Retourne uniquement les blocs au format demande, sans Markdown ni commentaire."
    R12_AjouterLigneRevision p, ""

    For Each brouillon In brouillons
        If CBool(brouillon("RevisionActive")) Then
            If InStr(1, CStr(brouillon("CorpsTagge")), _
                "[[A_COMPLETER_AVANT_IMPRESSION", vbTextCompare) = 0 Then

                nombreEligibles = nombreEligibles + 1
                Set profil = R12_ChargerProfil(CStr(brouillon("CodeProfil")))
                niveau = R12_ProfilValeur( _
                    profil, "REVISION_FINALE", "NIVEAU", "LEGER")

                R12_AjouterLigneRevision p, R12_DEBUT_REVISION
                R12_AjouterLigneRevision p, _
                    R12_PREFIXE_ID_REVISION & CStr(brouillon("IDDemande"))
                R12_AjouterLigneRevision p, _
                    "CODE_PROFIL=" & CStr(brouillon("CodeProfil"))
                R12_AjouterLigneRevision p, "NIVEAU=" & niveau
                R12_AjouterLigneRevision p, R12_PREFIXE_CORPS
                p = p & CStr(brouillon("CorpsTagge")) & vbCrLf
                R12_AjouterLigneRevision p, R12_FIN_REVISION
                R12_AjouterLigneRevision p, ""
            End If
        End If
    Next brouillon

    R12_ConstruirePromptRevision = p
End Function

Private Function R12_ExtraireBlocsRevision(ByVal texte As String) As Object

    Dim resultat As Object
    Dim posRecherche As Long
    Dim posDebut As Long
    Dim posFin As Long
    Dim bloc As String
    Dim identifiant As String

    Set resultat = CreateObject("Scripting.Dictionary")
    resultat.CompareMode = vbTextCompare
    posRecherche = 1

    Do
        posDebut = InStr(posRecherche, texte, R12_DEBUT_REVISION, vbTextCompare)
        If posDebut = 0 Then Exit Do

        posFin = InStr(posDebut + Len(R12_DEBUT_REVISION), _
            texte, R12_FIN_REVISION, vbTextCompare)
        If posFin = 0 Then Exit Do

        bloc = Mid$(texte, posDebut, _
            posFin - posDebut + Len(R12_FIN_REVISION))
        identifiant = R12_LireLigneRevision(bloc, R12_PREFIXE_ID_REVISION)

        If identifiant <> "" Then
            resultat(UCase$(identifiant)) = bloc
        End If

        posRecherche = posFin + Len(R12_FIN_REVISION)
    Loop

    Set R12_ExtraireBlocsRevision = resultat
End Function

Private Function R12_ExtraireCorpsRevision(ByVal bloc As String) As String

    Dim pos As Long
    Dim posFin As Long

    If Trim$(bloc) = "" Then Exit Function

    pos = InStr(1, bloc, R12_PREFIXE_CORPS, vbTextCompare)
    If pos = 0 Then Exit Function
    pos = pos + Len(R12_PREFIXE_CORPS)

    Do While pos <= Len(bloc)
        If Mid$(bloc, pos, 1) = vbCr Or Mid$(bloc, pos, 1) = vbLf Then
            pos = pos + 1
        Else
            Exit Do
        End If
    Loop

    posFin = InStr(pos, bloc, R12_FIN_REVISION, vbTextCompare)
    If posFin = 0 Then Exit Function

    R12_ExtraireCorpsRevision = Trim$(Mid$(bloc, pos, posFin - pos))
End Function

Private Function R12_RevisionValide( _
    ByVal original As String, _
    ByVal revise As String, _
    ByRef raison As String) As Boolean

    raison = ""
    revise = Trim$(revise)

    If revise = "" Then
        raison = "corps revise vide"
        Exit Function
    End If

    If R12_SequenceTags(original) <> R12_SequenceTags(revise) Then
        raison = "tags absents, ajoutes ou reordonnes"
        Exit Function
    End If

    If R12_CompterOccurrences(original, "[[PATIENT]]") <> _
       R12_CompterOccurrences(revise, "[[PATIENT]]") Then
        raison = "marqueur patient modifie"
        Exit Function
    End If

    If Not R12_TokensCritiquesEgaux(original, revise) Then
        raison = "valeur numerique, dose ou pourcentage modifie"
        Exit Function
    End If

    If R12_ContientAdresseDirecteHorsIntro(revise) Then
        raison = "adresse directe ajoutee dans une rubrique medicale"
        Exit Function
    End If

    R12_RevisionValide = True
End Function

Private Function R12_SequenceTags(ByVal texte As String) As String

    Dim re As Object
    Dim matches As Object
    Dim m As Object
    Dim resultat As String

    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "\[\[R12_CHAMP:([A-Z0-9_]+)\]\]"

    Set matches = re.Execute(texte)
    For Each m In matches
        If resultat <> "" Then resultat = resultat & "|"
        resultat = resultat & UCase$(CStr(m.SubMatches(0)))
    Next m

    R12_SequenceTags = resultat
End Function

Private Function R12_TokensCritiquesEgaux( _
    ByVal texte1 As String, _
    ByVal texte2 As String) As Boolean

    Dim d1 As Object
    Dim d2 As Object
    Dim cle As Variant

    Set d1 = R12_DictionnaireTokensCritiques(texte1)
    Set d2 = R12_DictionnaireTokensCritiques(texte2)

    If d1.Count <> d2.Count Then Exit Function

    For Each cle In d1.Keys
        If Not d2.Exists(CStr(cle)) Then Exit Function
        If CLng(d1(cle)) <> CLng(d2(cle)) Then Exit Function
    Next cle

    R12_TokensCritiquesEgaux = True
End Function

Private Function R12_DictionnaireTokensCritiques( _
    ByVal texte As String) As Object

    Dim d As Object
    Dim re As Object
    Dim matches As Object
    Dim m As Object
    Dim token As String

    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbTextCompare

    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "[0-9]+([,.][0-9]+)?([ ]*(mg|mcg|ug|g|ml|mmhg|bpm|/min|%|ms|cm|mm|ans|x[ ]*[0-9]+))?"

    Set matches = re.Execute(LCase$(texte))

    For Each m In matches
        token = Replace(CStr(m.Value), " ", "")
        token = Replace(token, ",", ".")
        If d.Exists(token) Then
            d(token) = CLng(d(token)) + 1
        Else
            d.Add token, 1
        End If
    Next m

    Set R12_DictionnaireTokensCritiques = d
End Function

Private Function R12_ContientAdresseDirecteHorsIntro( _
    ByVal corpsTagge As String) As Boolean

    Dim tags As Variant
    Dim i As Long
    Dim nomChamp As String
    Dim valeur As String

    tags = Split(R12_SequenceTags(corpsTagge), "|")

    For i = LBound(tags) To UBound(tags)
        nomChamp = UCase$(Trim$(CStr(tags(i))))
        If nomChamp <> "" And nomChamp <> "INTRO" And _
           nomChamp <> "A_COMPLETER" Then

            valeur = R12_ExtraireValeurChampTagge(corpsTagge, nomChamp)
            If R12_TexteContientAdresseDirecte(valeur) Then
                R12_ContientAdresseDirecteHorsIntro = True
                Exit Function
            End If
        End If
    Next i
End Function

Private Function R12_TexteContientAdresseDirecte( _
    ByVal texte As String) As Boolean

    Dim t As String
    Dim mots As Variant
    Dim mot As Variant

    t = LCase$(texte)
    t = Replace(t, ChrW(8217), "'")
    t = Replace(t, "'", " ")
    t = Replace(t, ".", " ")
    t = Replace(t, ",", " ")
    t = Replace(t, ";", " ")
    t = Replace(t, ":", " ")
    t = Replace(t, "!", " ")
    t = Replace(t, "?", " ")
    t = " " & t & " "

    mots = Array( _
        " je ", " j ", " nous ", " notre ", " nos ", _
        " tu ", " te ", " toi ", " vous ", " votre ", " vos ", _
        " me ", " moi ", " mon ", " ma ", " mes ")

    For Each mot In mots
        If InStr(1, t, CStr(mot), vbTextCompare) > 0 Then
            R12_TexteContientAdresseDirecte = True
            Exit Function
        End If
    Next mot
End Function

Private Function R12_ExtraireValeurChampTagge( _
    ByVal corpsTagge As String, _
    ByVal champ As String) As String

    Dim tag As String
    Dim pos As Long
    Dim posSuivant As Long
    Dim re As Object
    Dim matches As Object
    Dim m As Object

    tag = "[[R12_CHAMP:" & UCase$(Trim$(champ)) & "]]"
    pos = InStr(1, corpsTagge, tag, vbTextCompare)
    If pos = 0 Then Exit Function
    pos = pos + Len(tag)

    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "\[\[R12_CHAMP:[A-Z0-9_]+\]\]"

    Set matches = re.Execute(Mid$(corpsTagge, pos))
    posSuivant = Len(corpsTagge) + 1

    For Each m In matches
        If CLng(m.FirstIndex) > 0 Then
            posSuivant = pos + CLng(m.FirstIndex)
            Exit For
        End If
    Next m

    R12_ExtraireValeurChampTagge = _
        Trim$(Mid$(corpsTagge, pos, posSuivant - pos))
End Function

Public Function R12_FinaliserCorpsTagge( _
    ByVal corpsTagge As String) As String

    Dim re As Object
    Dim matches As Object
    Dim i As Long
    Dim posDebutValeur As Long
    Dim posFinValeur As Long
    Dim valeur As String
    Dim resultat As String

    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "\[\[R12_CHAMP:[A-Z0-9_]+\]\]"
    Set matches = re.Execute(corpsTagge)

    For i = 0 To matches.Count - 1
        posDebutValeur = CLng(matches(i).FirstIndex) + _
            CLng(matches(i).Length) + 1

        If i < matches.Count - 1 Then
            posFinValeur = CLng(matches(i + 1).FirstIndex) + 1
        Else
            posFinValeur = Len(corpsTagge) + 1
        End If

        valeur = Mid$(corpsTagge, posDebutValeur, _
            posFinValeur - posDebutValeur)
        valeur = R12_NettoyerParagrapheRevision(valeur)

        If valeur <> "" Then
            If resultat <> "" Then resultat = resultat & R12_MARQUEUR_PARAGRAPHE
            resultat = resultat & valeur
        End If
    Next i

    R12_FinaliserCorpsTagge = resultat
End Function

Private Function R12_NettoyerParagrapheRevision( _
    ByVal texte As String) As String

    texte = Replace(texte, vbCrLf, " ")
    texte = Replace(texte, vbCr, " ")
    texte = Replace(texte, vbLf, " ")
    texte = Replace(texte, vbTab, " ")
    texte = Replace(texte, Chr$(160), " ")
    texte = Replace(texte, "**", "")

    Do While InStr(1, texte, "  ", vbBinaryCompare) > 0
        texte = Replace(texte, "  ", " ")
    Loop

    R12_NettoyerParagrapheRevision = Trim$(texte)
End Function

Public Function R12_MaterialiserParagraphes( _
    ByVal texte As String) As String

    texte = Replace(texte, R12_MARQUEUR_PARAGRAPHE, vbCr)
    R12_MaterialiserParagraphes = texte
End Function

Private Function R12_LireLigneRevision( _
    ByVal texte As String, _
    ByVal prefixe As String) As String

    Dim pos As Long
    Dim posFin As Long

    pos = InStr(1, texte, prefixe, vbTextCompare)
    If pos = 0 Then Exit Function
    pos = pos + Len(prefixe)

    posFin = InStr(pos, texte, vbCr, vbBinaryCompare)
    If posFin = 0 Then posFin = InStr(pos, texte, vbLf, vbBinaryCompare)
    If posFin = 0 Then posFin = Len(texte) + 1

    R12_LireLigneRevision = Trim$(Mid$(texte, pos, posFin - pos))
End Function

Private Function R12_CompterOccurrences( _
    ByVal texte As String, _
    ByVal motif As String) As Long

    Dim pos As Long

    If motif = "" Then Exit Function
    pos = 1

    Do
        pos = InStr(pos, texte, motif, vbTextCompare)
        If pos = 0 Then Exit Do
        R12_CompterOccurrences = R12_CompterOccurrences + 1
        pos = pos + Len(motif)
    Loop
End Function

Private Sub R12_AjouterLigneRevision( _
    ByRef p As String, _
    ByVal ligne As String)

    p = p & ligne & vbCrLf
End Sub

Public Sub R12_Core_TesterRevisionFinale()

    Dim t As String
    Dim f As String

    t = "[[R12_CHAMP:INTRO]]" & vbCrLf & _
        "Merci de realiser un test d'effort a Madame [[PATIENT]], 70 ans." & vbCrLf & _
        "[[R12_CHAMP:ECG]]" & vbCrLf & _
        "L'electrocardiogramme montre un rythme sinusal a 65/min."

    f = R12_FinaliserCorpsTagge(t)

    If InStr(1, f, R12_MARQUEUR_PARAGRAPHE, vbBinaryCompare) > 0 And _
       InStr(1, R12_MaterialiserParagraphes(f), vbCr, vbBinaryCompare) > 0 Then
        MsgBox "OK : tags R12 et paragraphes proteges operationnels.", _
            vbInformation, "R12"
    Else
        MsgBox "ECHEC : structure taggee R12 non operationnelle.", _
            vbExclamation, "R12"
    End If
End Sub
