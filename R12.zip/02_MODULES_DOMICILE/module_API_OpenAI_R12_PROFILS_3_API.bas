Attribute VB_Name = "modOpenAI_v22_corrige"
Option Explicit

'===============================================================================
' MODULE API OPENAI
' VERSION : v22-P5 - relance automatique et second appel cibl� silencieux
'
' Ce module conserve les noms publics historiques afin de ne pas casser
' les appels provenant des autres modules.
'
' D�pendances attendues dans le projet :
' - OPENAI_MODEL
' - OPENAI_API_URL
' - BALISE_DEBUT_DEMANDE_DESTINATION
' - BALISE_FIN_DEMANDE_DESTINATION
' - PREFIXE_CLE_DESTINATION
' - BALISE_DEBUT_CORPS_DESTINATION
' - BALISE_FIN_CORPS_DESTINATION
' - TexteContientDemandeExamenEligible(...)
' - ConstruirePromptDemandeExamenSeule(...)
'===============================================================================

Public Function LireCleOpenAI() As String

    LireCleOpenAI = Environ$("OPENAI_API_KEY")

End Function

Public Function CleOpenAIDisponible() As Boolean

    CleOpenAIDisponible = (Len(Trim$(LireCleOpenAI())) > 0)

End Function

Public Function JsonEscape(ByVal s As String) As String

    s = Replace(s, "\", "\\")
    s = Replace(s, """", "\""")
    s = Replace(s, vbCrLf, "\n")
    s = Replace(s, vbCr, "\n")
    s = Replace(s, vbLf, "\n")
    s = Replace(s, vbTab, "\t")

    JsonEscape = s

End Function

Public Function ConstruireJsonResponsesAPI( _
    ByVal prompt As String, _
    Optional ByVal maxOutputTokens As Long = 8000) As String

    Dim json As String

    If maxOutputTokens < 256 Then
        maxOutputTokens = 8000
    End If

    json = "{"
    json = json & _
        """model"":""" & JsonEscape(OPENAI_MODEL) & ""","
    json = json & _
        """input"":""" & JsonEscape(prompt) & ""","
    json = json & _
        """max_output_tokens"":" & CStr(maxOutputTokens)
    json = json & "}"

    ConstruireJsonResponsesAPI = json

End Function

Public Function AppelerOpenAIRaw( _
    ByVal prompt As String, _
    Optional ByVal maxOutputTokens As Long = 8000) As String

    Dim http As Object
    Dim jsonBody As String
    Dim cleAPI As String
    Dim statut As Long
    Dim reponse As String

    AppelerOpenAIRaw = ""

    cleAPI = LireCleOpenAI()

    If Len(Trim$(cleAPI)) = 0 Then

        MsgBox _
            "Cl� API OpenAI introuvable dans OPENAI_API_KEY.", _
            vbExclamation

        Exit Function

    End If

    jsonBody = _
        ConstruireJsonResponsesAPI( _
            prompt, _
            maxOutputTokens)

    On Error GoTo ErreurHTTP

    Set http = CreateObject("WinHttp.WinHttpRequest.5.1")

    http.Open "POST", OPENAI_API_URL, False

    'Timeouts en millisecondes :
    'Resolve, Connect, Send, Receive.
    http.SetTimeouts 10000, 30000, 30000, 120000

    http.SetRequestHeader _
        "Content-Type", _
        "application/json; charset=utf-8"

    http.SetRequestHeader _
        "Authorization", _
        "Bearer " & cleAPI

    http.Send jsonBody

    statut = CLng(http.Status)
    reponse = CStr(http.ResponseText)

    If statut < 200 Or statut >= 300 Then

        MsgBox _
            "Erreur API OpenAI." & vbCrLf & _
            "Statut HTTP : " & statut & vbCrLf & vbCrLf & _
            Left$(reponse, 2000), _
            vbExclamation

        Exit Function

    End If

    AppelerOpenAIRaw = reponse
    Exit Function

ErreurHTTP:

    MsgBox _
        "Erreur lors de l'appel HTTP � l'API OpenAI :" & vbCrLf & _
        Err.Number & " - " & Err.description, _
        vbExclamation

End Function

Public Function ExtraireTexteOpenAI( _
    ByVal reponseJson As String) As String

    Dim resultat As String

    ExtraireTexteOpenAI = ""

    If Len(Trim$(reponseJson)) = 0 Then Exit Function

    'Le JSON de la Responses API contient un tableau output pouvant comporter
    'plusieurs �l�ments. L'ordre des propri�t�s d'un objet JSON n'est pas
    'garanti : "text" peut donc se trouver avant ou apr�s "type":"output_text".
    'On localise chaque objet de contenu de type output_text, puis on lit son
    'champ text � l'int�rieur de cet objet, ind�pendamment de l'ordre des cl�s.
    resultat = ExtraireTousTextesOutput(reponseJson)

    'S�curit� pour une �ventuelle propri�t� agr�g�e output_text renvoy�e sous
    'forme de cha�ne par une autre version de l'API ou un proxy interm�diaire.
    If Len(Trim$(resultat)) = 0 Then
        resultat = ExtraireValeurChaineJsonParCle( _
            reponseJson, _
            "output_text", _
            1)
    End If

    'Dernier repli : rechercher une cha�ne "text" dans la zone output.
    'Ce repli n'est utilis� que si aucun objet output_text n'a �t� exploitable.
    If Len(Trim$(resultat)) = 0 Then
        resultat = ExtrairePremierTexteDansOutput(reponseJson)
    End If

    ExtraireTexteOpenAI = resultat

End Function

Private Function ExtraireTousTextesOutput( _
    ByVal json As String) As String

    Dim positionRecherche As Long
    Dim positionType As Long
    Dim positionDebutObjet As Long
    Dim positionFinObjet As Long

    Dim objet As String
    Dim texteContenu As String
    Dim resultat As String

    positionRecherche = 1
    resultat = ""

    Do

        positionType = InStr( _
            positionRecherche, _
            json, _
            """output_text""", _
            vbTextCompare)

        If positionType = 0 Then Exit Do

        positionDebutObjet = _
            TrouverDebutObjetJsonContenant( _
                json, _
                positionType)

        If positionDebutObjet > 0 Then

            positionFinObjet = _
                TrouverFinObjetJsonDepuis( _
                    json, _
                    positionDebutObjet)

            If positionFinObjet >= positionType Then

                objet = Mid$( _
                    json, _
                    positionDebutObjet, _
                    positionFinObjet - positionDebutObjet + 1)

                If ObjetContientValeurChaineJson( _
                    objet, _
                    "type", _
                    "output_text") Then

                    texteContenu = _
                        ExtraireValeurChaineJsonParCle( _
                            objet, _
                            "text", _
                            1)

                    If Len(texteContenu) > 0 Then

                        If resultat <> "" Then
                            resultat = resultat & vbCrLf
                        End If

                        resultat = resultat & texteContenu

                    End If

                    positionRecherche = positionFinObjet + 1

                Else

                    'L'occurrence peut �tre une propri�t� agr�g�e output_text
                    'du document racine. Ne pas sauter tout l'objet racine, car
                    'd'autres objets de contenu peuvent appara�tre plus loin.
                    positionRecherche = _
                        positionType + Len("""output_text""")

                End If

            Else

                positionRecherche = _
                    positionType + Len("""output_text""")

            End If

        Else

            positionRecherche = _
                positionType + Len("""output_text""")

        End If

    Loop

    ExtraireTousTextesOutput = resultat

End Function

Private Function ExtrairePremierTexteDansOutput( _
    ByVal json As String) As String

    Dim positionOutput As Long

    positionOutput = _
        TrouverPositionCleJson( _
            json, _
            "output", _
            1)

    If positionOutput = 0 Then positionOutput = 1

    ExtrairePremierTexteDansOutput = _
        ExtraireValeurChaineJsonParCle( _
            json, _
            "text", _
            positionOutput)

End Function

Private Function TrouverPositionCleJson( _
    ByVal json As String, _
    ByVal nomCle As String, _
    ByVal positionDepart As Long) As Long

    Dim motif As String
    Dim positionCle As Long
    Dim positionApresCle As Long

    motif = """" & nomCle & """"

    If positionDepart < 1 Then positionDepart = 1

    positionCle = InStr( _
        positionDepart, _
        json, _
        motif, _
        vbTextCompare)

    Do While positionCle > 0

        positionApresCle = _
            IgnorerEspacesJson( _
                json, _
                positionCle + Len(motif))

        If positionApresCle <= Len(json) Then

            If Mid$(json, positionApresCle, 1) = ":" Then

                TrouverPositionCleJson = positionCle
                Exit Function

            End If

        End If

        positionCle = InStr( _
            positionCle + Len(motif), _
            json, _
            motif, _
            vbTextCompare)

    Loop

    TrouverPositionCleJson = 0

End Function

Private Function ObjetContientValeurChaineJson( _
    ByVal json As String, _
    ByVal nomCle As String, _
    ByVal valeurRecherchee As String) As Boolean

    Dim positionRecherche As Long
    Dim positionCle As Long
    Dim valeur As String

    ObjetContientValeurChaineJson = False
    positionRecherche = 1

    Do

        positionCle = _
            TrouverPositionCleJson( _
                json, _
                nomCle, _
                positionRecherche)

        If positionCle = 0 Then Exit Do

        valeur = _
            ExtraireValeurChaineJsonParCle( _
                json, _
                nomCle, _
                positionCle)

        If StrComp( _
            valeur, _
            valeurRecherchee, _
            vbTextCompare) = 0 Then

            ObjetContientValeurChaineJson = True
            Exit Function

        End If

        positionRecherche = _
            positionCle + Len("""" & nomCle & """")

    Loop

End Function

Private Function ExtraireValeurChaineJsonParCle( _
    ByVal json As String, _
    ByVal nomCle As String, _
    ByVal positionDepart As Long) As String

    Dim motif As String
    Dim positionCle As Long
    Dim positionDeuxPoints As Long
    Dim positionValeur As Long
    Dim positionFinChaine As Long

    ExtraireValeurChaineJsonParCle = ""

    motif = """" & nomCle & """"

    If positionDepart < 1 Then positionDepart = 1

    positionCle = InStr( _
        positionDepart, _
        json, _
        motif, _
        vbTextCompare)

    Do While positionCle > 0

        positionDeuxPoints = _
            IgnorerEspacesJson( _
                json, _
                positionCle + Len(motif))

        If positionDeuxPoints <= Len(json) Then

            If Mid$(json, positionDeuxPoints, 1) = ":" Then

                positionValeur = _
                    IgnorerEspacesJson( _
                        json, _
                        positionDeuxPoints + 1)

                If positionValeur <= Len(json) Then

                    If Mid$(json, positionValeur, 1) = """" Then

                        ExtraireValeurChaineJsonParCle = _
                            LireChaineJsonDepuisGuillemet( _
                                json, _
                                positionValeur, _
                                positionFinChaine)

                        Exit Function

                    End If

                End If

            End If

        End If

        positionCle = InStr( _
            positionCle + Len(motif), _
            json, _
            motif, _
            vbTextCompare)

    Loop

End Function

Private Function IgnorerEspacesJson( _
    ByVal s As String, _
    ByVal positionDepart As Long) As Long

    Dim i As Long
    Dim c As String

    i = positionDepart

    Do While i <= Len(s)

        c = Mid$(s, i, 1)

        If c = " " _
        Or c = vbTab _
        Or c = vbCr _
        Or c = vbLf Then

            i = i + 1

        Else

            Exit Do

        End If

    Loop

    IgnorerEspacesJson = i

End Function

Private Function TrouverDebutObjetJsonContenant( _
    ByVal json As String, _
    ByVal positionCible As Long) As Long

    Dim pile() As Long
    Dim profondeur As Long
    Dim capacite As Long
    Dim i As Long
    Dim c As String
    Dim dansChaine As Boolean
    Dim echappe As Boolean

    TrouverDebutObjetJsonContenant = 0

    If positionCible < 1 Then Exit Function
    If positionCible > Len(json) Then positionCible = Len(json)

    capacite = 32
    ReDim pile(1 To capacite)

    For i = 1 To positionCible

        c = Mid$(json, i, 1)

        If dansChaine Then

            If echappe Then

                echappe = False

            ElseIf c = "\" Then

                echappe = True

            ElseIf c = """" Then

                dansChaine = False

            End If

        Else

            If c = """" Then

                dansChaine = True

            ElseIf c = "{" Then

                profondeur = profondeur + 1

                If profondeur > capacite Then

                    capacite = capacite * 2
                    ReDim Preserve pile(1 To capacite)

                End If

                pile(profondeur) = i

            ElseIf c = "}" Then

                If profondeur > 0 Then
                    profondeur = profondeur - 1
                End If

            End If

        End If

    Next i

    If profondeur > 0 Then
        TrouverDebutObjetJsonContenant = pile(profondeur)
    End If

End Function

Private Function TrouverFinObjetJsonDepuis( _
    ByVal json As String, _
    ByVal positionDebutObjet As Long) As Long

    Dim profondeur As Long
    Dim i As Long
    Dim c As String
    Dim dansChaine As Boolean
    Dim echappe As Boolean

    TrouverFinObjetJsonDepuis = 0

    If positionDebutObjet < 1 _
    Or positionDebutObjet > Len(json) Then

        Exit Function

    End If

    For i = positionDebutObjet To Len(json)

        c = Mid$(json, i, 1)

        If dansChaine Then

            If echappe Then

                echappe = False

            ElseIf c = "\" Then

                echappe = True

            ElseIf c = """" Then

                dansChaine = False

            End If

        Else

            If c = """" Then

                dansChaine = True

            ElseIf c = "{" Then

                profondeur = profondeur + 1

            ElseIf c = "}" Then

                profondeur = profondeur - 1

                If profondeur = 0 Then

                    TrouverFinObjetJsonDepuis = i
                    Exit Function

                End If

            End If

        End If

    Next i

End Function

Private Function TrouverProchainGuillemetJson( _
    ByVal s As String, _
    ByVal positionDepart As Long) As Long

    Dim i As Long

    TrouverProchainGuillemetJson = 0

    For i = positionDepart To Len(s)

        If Mid$(s, i, 1) = """" Then

            TrouverProchainGuillemetJson = i
            Exit Function

        End If

    Next i

End Function

Private Function LireChaineJsonDepuisGuillemet( _
    ByVal json As String, _
    ByVal posGuillemetDebut As Long, _
    Optional ByRef positionGuillemetFin As Long = 0) As String

    Dim i As Long
    Dim c As String
    Dim resultat As String
    Dim echappe As Boolean
    Dim codeHex As String

    resultat = ""
    positionGuillemetFin = 0
    echappe = False
    i = posGuillemetDebut + 1

    Do While i <= Len(json)

        c = Mid$(json, i, 1)

        If echappe Then

            Select Case c

                Case """"
                    resultat = resultat & """"

                Case "\"
                    resultat = resultat & "\"

                Case "/"
                    resultat = resultat & "/"

                Case "b"
                    resultat = resultat & Chr$(8)

                Case "f"
                    resultat = resultat & Chr$(12)

                Case "n"
                    resultat = resultat & vbCrLf

                Case "r"
                    resultat = resultat & vbCr

                Case "t"
                    resultat = resultat & vbTab

                Case "u"

                    If i + 4 <= Len(json) Then

                        codeHex = Mid$(json, i + 1, 4)

                        If EstCodeHexadecimal4(codeHex) Then

                            resultat = resultat & _
                                ChrW$(CLng("&H" & codeHex))

                            i = i + 4

                        Else

                            resultat = resultat & "\u"

                        End If

                    Else

                        resultat = resultat & "\u"

                    End If

                Case Else
                    resultat = resultat & c

            End Select

            echappe = False

        Else

            If c = "\" Then

                echappe = True

            ElseIf c = """" Then

                positionGuillemetFin = i
                Exit Do

            Else

                resultat = resultat & c

            End If

        End If

        i = i + 1

    Loop

    LireChaineJsonDepuisGuillemet = resultat

End Function

Private Function EstCodeHexadecimal4( _
    ByVal s As String) As Boolean

    Dim i As Long
    Dim c As String

    EstCodeHexadecimal4 = False

    If Len(s) <> 4 Then Exit Function

    For i = 1 To 4

        c = UCase$(Mid$(s, i, 1))

        If Not ( _
            (c >= "0" And c <= "9") _
            Or (c >= "A" And c <= "F")) Then

            Exit Function

        End If

    Next i

    EstCodeHexadecimal4 = True

End Function

Public Function AppelerOpenAI( _
    ByVal prompt As String) As String

    Const NOMBRE_TENTATIVES_MAX As Long = 2
    Const MAX_OUTPUT_TOKENS_API As Long = 8000

    Dim tentative As Long
    Dim promptTentative As String
    Dim reponseRaw As String
    Dim texteExtrait As String
    Dim diagnostic As String
    Dim cheminDiagnostic As String

    AppelerOpenAI = ""

    If Trim$(prompt) = "" Then

        MsgBox _
            "Le prompt envoy� � l'API est vide.", _
            vbExclamation

        Exit Function

    End If

    For tentative = 1 To NOMBRE_TENTATIVES_MAX

        If tentative = 1 Then

            promptTentative = prompt

        Else

            'La premi�re r�ponse �tait techniquement termin�e, mais le mod�le
            'n'avait produit aucun caract�re utile. On relance une seule fois
            'avec une instruction courte et explicite, sans modifier le fond.
            promptTentative = _
                ConstruirePromptRelanceSortieVide( _
                    prompt)

            Application.StatusBar = _
                "Reponse OpenAI vide - nouvelle tentative automatique..."

            DoEvents

        End If

        reponseRaw = _
            AppelerOpenAIRaw( _
                promptTentative, _
                MAX_OUTPUT_TOKENS_API)

        If reponseRaw = "" Then Exit Function

        texteExtrait = _
            ExtraireTexteOpenAI( _
                reponseRaw)

        If Len(Trim$(texteExtrait)) > 0 Then

            AppelerOpenAI = texteExtrait
            Exit Function

        End If

        'Ne relancer que le cas pr�cis observ� : r�ponse completed,
        'sans erreur ni refus, mais avec output_text vide.
        If Not ReponseCompleteSansTexte( _
            reponseRaw) Then

            Exit For

        End If

    Next tentative

    diagnostic = _
        ConstruireDiagnosticReponseOpenAI( _
            reponseRaw)

    If diagnostic <> "" Then
        diagnostic = diagnostic & vbCrLf
    End If

    diagnostic = diagnostic & _
        "Tentatives automatiques effectu�es : " & _
        CStr(NOMBRE_TENTATIVES_MAX)

    cheminDiagnostic = _
        SauvegarderReponseBruteOpenAI( _
            reponseRaw)

    MsgBox _
        "La r�ponse API est rest�e vide apr�s la relance automatique." & _
        IIf(diagnostic <> "", vbCrLf & vbCrLf & diagnostic, "") & _
        IIf(cheminDiagnostic <> "", _
            vbCrLf & vbCrLf & _
            "Derni�re r�ponse brute enregistr�e localement dans :" & _
            vbCrLf & cheminDiagnostic, _
            ""), _
        vbExclamation, _
        "OpenAI - sortie vide apr�s relance"

End Function

Private Function ConstruirePromptRelanceSortieVide( _
    ByVal promptOriginal As String) As String

    Dim instructionRelance As String

    instructionRelance = _
        "RELANCE IMP�RATIVE : la tentative pr�c�dente a renvoy� une sortie vide. " & _
        "Ne retourne jamais une r�ponse vide. Produis maintenant int�gralement " & _
        "le r�sultat demand�, en respectant exactement les balises, l'ordre et " & _
        "les contraintes du prompt ci-dessous. N'ajoute aucun commentaire avant " & _
        "ou apr�s les blocs exig�s."

    If InStr(1, _
        promptOriginal, _
        "Ne pas produire le bloc ---CORPS_COURRIER---", _
        vbTextCompare) > 0 Then

        instructionRelance = instructionRelance & _
            " Commence directement par " & _
            BALISE_DEBUT_DEMANDE_DESTINATION & "."

    ElseIf InStr(1, _
        promptOriginal, _
        "---CORPS_COURRIER---", _
        vbTextCompare) > 0 Then

        instructionRelance = instructionRelance & _
            " Commence exactement par ---CORPS_COURRIER---."

    End If

    ConstruirePromptRelanceSortieVide = _
        instructionRelance & _
        vbCrLf & vbCrLf & _
        promptOriginal

End Function

Private Function ReponseCompleteSansTexte( _
    ByVal reponseJson As String) As Boolean

    Dim statut As String
    Dim refus As String
    Dim messageErreur As String

    ReponseCompleteSansTexte = False

    statut = _
        ExtraireValeurChaineJsonParCle( _
            reponseJson, _
            "status", _
            1)

    If StrComp( _
        Trim$(statut), _
        "completed", _
        vbTextCompare) <> 0 Then

        Exit Function

    End If

    refus = _
        ExtraireValeurChaineJsonParCle( _
            reponseJson, _
            "refusal", _
            1)

    messageErreur = _
        ExtraireValeurChaineJsonParCle( _
            reponseJson, _
            "message", _
            1)

    If Len(Trim$(refus)) > 0 Then Exit Function
    If Len(Trim$(messageErreur)) > 0 Then Exit Function

    ReponseCompleteSansTexte = True

End Function

Private Function ConstruireDiagnosticReponseOpenAI( _
    ByVal reponseJson As String) As String

    Dim statut As String
    Dim motif As String
    Dim refus As String
    Dim messageErreur As String
    Dim resultat As String

    statut = _
        ExtraireValeurChaineJsonParCle( _
            reponseJson, _
            "status", _
            1)

    motif = _
        ExtraireValeurChaineJsonParCle( _
            reponseJson, _
            "reason", _
            1)

    refus = _
        ExtraireValeurChaineJsonParCle( _
            reponseJson, _
            "refusal", _
            1)

    messageErreur = _
        ExtraireValeurChaineJsonParCle( _
            reponseJson, _
            "message", _
            1)

    resultat = ""

    If statut <> "" Then
        resultat = "Statut de la r�ponse : " & statut
    End If

    If motif <> "" Then

        If resultat <> "" Then resultat = resultat & vbCrLf
        resultat = resultat & "Motif indiqu� par l'API : " & motif

    End If

    If refus <> "" Then

        If resultat <> "" Then resultat = resultat & vbCrLf
        resultat = resultat & "Refus retourn� par le mod�le : " & refus

    End If

    If messageErreur <> "" Then

        If resultat <> "" Then resultat = resultat & vbCrLf
        resultat = resultat & "Message API : " & messageErreur

    End If

    ConstruireDiagnosticReponseOpenAI = resultat

End Function

Private Function SauvegarderReponseBruteOpenAI( _
    ByVal reponseJson As String) As String

    Dim chemin As String
    Dim flux As Object

    SauvegarderReponseBruteOpenAI = ""

    If Len(reponseJson) = 0 Then Exit Function

    chemin = Environ$("TEMP") & _
              "\OpenAI_reponse_brute_" & _
              Format$(Now, "yyyymmdd_hhnnss") & _
              ".json"

    On Error GoTo Echec

    Set flux = CreateObject("ADODB.Stream")

    With flux
        .Type = 2
        .Charset = "utf-8"
        .Open
        .WriteText reponseJson
        .SaveToFile chemin, 2
        .Close
    End With

    SauvegarderReponseBruteOpenAI = chemin
    Exit Function

Echec:

    On Error Resume Next

    If Not flux Is Nothing Then
        flux.Close
    End If

    Set flux = Nothing
    On Error GoTo 0

End Function

Public Sub TesterExtractionTexteOpenAIOrdreChamps()

    Dim jsonTypeAvant As String
    Dim jsonTexteAvant As String
    Dim resultat1 As String
    Dim resultat2 As String

    jsonTypeAvant = _
        "{""output"":[{""type"":""message"",""content"":[" & _
        "{""type"":""output_text"",""text"":""TEST TYPE AVANT""}" & _
        "]}]}"

    jsonTexteAvant = _
        "{""output"":[{""type"":""message"",""content"":[" & _
        "{""text"":""TEST TEXTE AVANT"",""annotations"":[]," & _
        """type"":""output_text""}" & _
        "]}]}"

    resultat1 = ExtraireTexteOpenAI(jsonTypeAvant)
    resultat2 = ExtraireTexteOpenAI(jsonTexteAvant)

    If resultat1 = "TEST TYPE AVANT" _
    And resultat2 = "TEST TEXTE AVANT" Then

        MsgBox _
            "OK : le parseur extrait le texte quel que soit l'ordre " & _
            "des propri�t�s JSON.", _
            vbInformation, _
            "Test parseur OpenAI"

    Else

        MsgBox _
            "�CHEC du test du parseur." & vbCrLf & _
            "R�sultat 1 : [" & resultat1 & "]" & vbCrLf & _
            "R�sultat 2 : [" & resultat2 & "]", _
            vbExclamation, _
            "Test parseur OpenAI"

    End If

End Sub

Public Sub TesterDetectionSortieVideComplete()

    Dim jsonTest As String

    jsonTest = _
        "{""status"":""completed"",""error"":null,""output"":[" & _
        "{""type"":""message"",""content"":[" & _
        "{""type"":""output_text"",""text"":""""}" & _
        "]}],""usage"":{""output_tokens"":1}}"

    If ReponseCompleteSansTexte(jsonTest) Then

        MsgBox _
            "OK : une r�ponse completed avec output_text vide d�clenche " & _
            "la relance automatique.", _
            vbInformation, _
            "Test sortie OpenAI vide"

    Else

        MsgBox _
            "�CHEC : la r�ponse vide n'est pas reconnue.", _
            vbExclamation, _
            "Test sortie OpenAI vide"

    End If

End Sub

'===============================================================================
' FONCTION HISTORIQUE CONSERV�E
'
' En v22, cette fonction recherche d�sormais les blocs :
'   ---DEMANDE_DESTINATION---
'   ...
'   ---FIN_DEMANDE_DESTINATION---
'
' R12 : l'API 2 remplit les profils ; l'API 3 revise les brouillons eligibles.
'===============================================================================

Public Function CompleterReponseAvecDemandeExamenSiNecessaire( _
    ByVal reponseAPI As String, _
    ByVal texteAnonymise As String) As String

    Dim texteDetection As String
    Dim promptDemande As String
    Dim reponseDemande As String
    Dim blocsDemandes As String
    Dim reponsePrincipaleNettoyee As String
    Dim messageConversion As String
    Dim nombreBrouillons As Long

    CompleterReponseAvecDemandeExamenSiNecessaire = reponseAPI

    If Trim$(reponseAPI) = "" Then Exit Function
    If Trim$(texteAnonymise) = "" Then Exit Function

    If Trim$(gTexteAnonymise) <> "" Then
        texteDetection = gTexteAnonymise
    Else
        texteDetection = texteAnonymise
    End If

    If Not TexteContientDemandeExamenEligible(texteDetection) Then
        Exit Function
    End If

    'R12 : le plan des demandes, leurs identifiants, examens et destinations
    'est construit localement avant le deuxieme appel.
    If Not R12_PreparerPlanDemandes(texteDetection) Then

        MsgBox _
            "La demande complementaire a ete detectee, mais son plan local " & _
            "n'a pas pu etre construit." & vbCrLf & vbCrLf & _
            R12_DernierMessage(), _
            vbExclamation, _
            "Demandes par profils R12"

        CompleterReponseAvecDemandeExamenSiNecessaire = ""
        Exit Function
    End If

    promptDemande = ConstruirePromptDemandeExamenSeule(texteAnonymise)

    If Trim$(promptDemande) = "" Then
        MsgBox _
            "Le prompt structure du deuxieme appel n'a pas pu etre construit.", _
            vbExclamation, _
            "Demandes par profils R12"
        CompleterReponseAvecDemandeExamenSiNecessaire = ""
        Exit Function
    End If

    reponseDemande = AppelerOpenAI(promptDemande)

    'Une reponse API 2 vide n'empeche pas le brouillon local. L'API 3 n'est
    'appelee que pour les lettres completes et eligibles selon leur profil.
    blocsDemandes = R12_ConvertirFichesEnBlocsDemandes( _
        reponseDemande, _
        texteAnonymise, _
        messageConversion, _
        nombreBrouillons)

    If Trim$(blocsDemandes) = "" Then

        MsgBox _
            "Les lettres complementaires n'ont pas pu etre assemblees " & _
            "localement." & vbCrLf & vbCrLf & messageConversion, _
            vbExclamation, _
            "Demandes par profils R12"

        CompleterReponseAvecDemandeExamenSiNecessaire = ""
        Exit Function
    End If

    reponsePrincipaleNettoyee = _
        SupprimerZoneDemandesDestination(reponseAPI)

    CompleterReponseAvecDemandeExamenSiNecessaire = _
        TrimFinRetoursSimples(reponsePrincipaleNettoyee) & _
        vbCrLf & vbCrLf & blocsDemandes

End Function

Private Function SupprimerZoneDemandesDestination( _
    ByVal texte As String) As String

    Dim positionPremierBloc As Long

    positionPremierBloc = InStr( _
        1, _
        texte, _
        BALISE_DEBUT_DEMANDE_DESTINATION, _
        vbTextCompare)

    If positionPremierBloc = 0 Then

        SupprimerZoneDemandesDestination = texte

    Else

        SupprimerZoneDemandesDestination = _
            Left$(texte, positionPremierBloc - 1)

    End If

End Function

Private Function ReponseContientBlocDemandeDestinationValide( _
    ByVal texte As String) As Boolean

    ReponseContientBlocDemandeDestinationValide = _
        (Trim$(ExtraireTousBlocsDemandesDestination(texte)) <> "")

End Function

Private Function ExtraireTousBlocsDemandesDestination( _
    ByVal texte As String) As String

    Dim positionRecherche As Long
    Dim positionDebut As Long
    Dim positionFin As Long
    Dim longueurBloc As Long

    Dim bloc As String
    Dim resultat As String

    resultat = ""
    positionRecherche = 1

    Do

        positionDebut = InStr( _
            positionRecherche, _
            texte, _
            BALISE_DEBUT_DEMANDE_DESTINATION, _
            vbTextCompare)

        If positionDebut = 0 Then Exit Do

        positionFin = InStr( _
            positionDebut + _
                Len(BALISE_DEBUT_DEMANDE_DESTINATION), _
            texte, _
            BALISE_FIN_DEMANDE_DESTINATION, _
            vbTextCompare)

        If positionFin = 0 Then Exit Do

        longueurBloc = _
            positionFin - positionDebut + _
            Len(BALISE_FIN_DEMANDE_DESTINATION)

        bloc = Mid$( _
            texte, _
            positionDebut, _
            longueurBloc)

        If BlocDemandeDestinationValide(bloc) Then

            If resultat <> "" Then
                resultat = resultat & vbCrLf & vbCrLf
            End If

            resultat = resultat & _
                TrimFinRetoursSimples(bloc)

        End If

        positionRecherche = _
            positionFin + _
            Len(BALISE_FIN_DEMANDE_DESTINATION)

    Loop

    ExtraireTousBlocsDemandesDestination = resultat

End Function

Private Function BlocDemandeDestinationValide( _
    ByVal bloc As String) As Boolean

    Dim positionCle As Long
    Dim positionValeurCle As Long
    Dim positionFinLigne As Long

    Dim positionDebutCorps As Long
    Dim positionFinCorps As Long
    Dim positionTexteCorps As Long
    Dim positionFinBloc As Long

    Dim cleDestination As String
    Dim corpsDestination As String

    BlocDemandeDestinationValide = False

    positionCle = InStr( _
        1, _
        bloc, _
        PREFIXE_CLE_DESTINATION, _
        vbTextCompare)

    positionDebutCorps = InStr( _
        1, _
        bloc, _
        BALISE_DEBUT_CORPS_DESTINATION, _
        vbTextCompare)

    positionFinCorps = InStr( _
        1, _
        bloc, _
        BALISE_FIN_CORPS_DESTINATION, _
        vbTextCompare)

    positionFinBloc = InStr( _
        1, _
        bloc, _
        BALISE_FIN_DEMANDE_DESTINATION, _
        vbTextCompare)

    If positionCle = 0 _
    Or positionDebutCorps = 0 _
    Or positionFinCorps = 0 _
    Or positionFinBloc = 0 Then

        Exit Function

    End If

    If positionDebutCorps <= positionCle Then Exit Function
    If positionFinCorps <= positionDebutCorps Then Exit Function
    If positionFinBloc <= positionFinCorps Then Exit Function

    'Lecture de la cl� jusqu'� la fin de sa ligne.
    positionValeurCle = _
        positionCle + _
        Len(PREFIXE_CLE_DESTINATION)

    positionFinLigne = InStr( _
        positionValeurCle, _
        bloc, _
        vbCr, _
        vbBinaryCompare)

    If positionFinLigne = 0 Then

        positionFinLigne = InStr( _
            positionValeurCle, _
            bloc, _
            vbLf, _
            vbBinaryCompare)

    End If

    If positionFinLigne = 0 Then
        positionFinLigne = Len(bloc) + 1
    End If

    cleDestination = Mid$( _
        bloc, _
        positionValeurCle, _
        positionFinLigne - positionValeurCle)

    cleDestination = Replace(cleDestination, vbCr, "")
    cleDestination = Replace(cleDestination, vbLf, "")
    cleDestination = Trim$(cleDestination)

    If cleDestination = "" Then Exit Function

    'CLE_EXACTE est seulement l'exemple donn� dans le prompt.
    'Elle ne doit jamais �tre accept�e dans une r�ponse r�elle.
    If StrComp( _
        cleDestination, _
        "CLE_EXACTE", _
        vbTextCompare) = 0 Then

        Exit Function

    End If

    'V�rification que le corps contient r�ellement du texte.
    positionTexteCorps = _
        positionDebutCorps + _
        Len(BALISE_DEBUT_CORPS_DESTINATION)

    corpsDestination = Mid$( _
        bloc, _
        positionTexteCorps, _
        positionFinCorps - positionTexteCorps)

    corpsDestination = Replace(corpsDestination, vbCr, "")
    corpsDestination = Replace(corpsDestination, vbLf, "")
    corpsDestination = Replace(corpsDestination, vbTab, "")
    corpsDestination = Replace(corpsDestination, Chr(160), " ")

    If Trim$(corpsDestination) = "" Then Exit Function

    BlocDemandeDestinationValide = True

End Function

'Nom historique conserv� au cas o� une ancienne proc�dure du m�me module
'y ferait encore r�f�rence. En v22, cette fonction renvoie tous les blocs
'DEMANDE_DESTINATION valides.
Private Function NettoyerBlocReponseDemande( _
    ByVal texte As String) As String

    NettoyerBlocReponseDemande = _
        ExtraireTousBlocsDemandesDestination(texte)

End Function

Private Function TrimFinRetoursSimples( _
    ByVal texte As String) As String

    Do While Len(texte) > 0

        If Right$(texte, 1) = vbCr _
        Or Right$(texte, 1) = vbLf _
        Or Right$(texte, 1) = Chr(11) _
        Or Right$(texte, 1) = Chr(12) _
        Or Right$(texte, 1) = " " _
        Or Right$(texte, 1) = Chr(160) Then

            texte = Left$(texte, Len(texte) - 1)

        Else

            Exit Do

        End If

    Loop

    TrimFinRetoursSimples = texte

End Function


