Attribute VB_Name = "modPrompts"
Option Explicit

'===============================================================================
' MODULE : modPrompts
' VERSION : R12 - PROFILS EXTERNES PAR TYPE D EXAMEN
'
' Prompt simplifi� � partir de 4 307 courriers r�cents du cabinet.
' Le prompt principal produit UNIQUEMENT le bloc CORPS_COURRIER.
' Les demandes compl�mentaires sont produites par un second appel API s�par�.
'
' L'ancien format ---DEMANDE_EXAMEN--- n'est plus demand� par le prompt v24.
' Les fonctions publiques historiques sont conserv�es afin de ne pas casser
' les appels provenant des autres modules pendant la transition.
'===============================================================================
' La casse et le gras sont d�sormais appliqu�s localement par modNormalisationGrasLocal.
' L'API ne re�oit plus aucune consigne de mise en gras / Markdown.

Public Function ConstruirePromptReecritureMedicale( _
    ByVal texteAnonymise As String) As String

    Dim p As String

    p = ""

    AjouterLignePrompt p, "Tu r��cris le corps d'un courrier m�dical de cardiologie dict� par le Docteur Olivier Mandagout."
    AjouterLignePrompt p, "Produis un fran�ais m�dical correct tout en restant au plus pr�s de la formulation, du rythme, de la concision et de la logique du texte source."
    AjouterLignePrompt p, "Corrige les erreurs de dict�e, d'orthographe, d'accord, de conjugaison, de syntaxe et de ponctuation, sans transformer le courrier en texte acad�mique ou administratif."
    AjouterLignePrompt p, "Ne r�sume pas, ne simplifie pas excessivement, ne supprime aucune donn�e m�dicale et n'ajoute aucune information absente du texte source."
    AjouterLignePrompt p, "Conserve exactement le marqueur [[PATIENT]] et n'invente jamais de nom, de pr�nom, d'�ge, de diagnostic, de r�sultat, de traitement ou de destinataire."
    AjouterLignePrompt p, "Dans le courrier principal, le confr�re destinataire peut �tre d�sign� par tu ou vous ; le patient doit rester � la troisi�me personne : il, elle, le, la, lui, l' ou Monsieur/Madame [[PATIENT]]."
    AjouterLignePrompt p, "Conserve le tutoiement ou le vouvoiement du texte source et son degr� de proximit� confraternelle."
    AjouterLignePrompt p, "N'utilise ni liste � puces, ni tableau, ni titre visible, ni commentaire avant ou apr�s les blocs demand�s."
    AjouterLignePrompt p, "Conserve les formulations caract�ristiques du texte source lorsqu'elles sont m�dicalement et grammaticalement correctes ; n'introduis pas de tournures administratives ou emphatiques inutiles."
    AjouterLignePrompt p, "R�dige des paragraphes courts et denses, g�n�ralement compos�s d'une ou deux phrases, avec une seule unit� m�dico-logique par paragraphe."
    AjouterLignePrompt p, "Ne r�organise pas un courrier d�j� coh�rent ; lorsque le texte est d�sordonn�, respecte l'ordre m�dico-logique d�fini ci-dessous sans inventer de rubrique absente."
    AjouterLignePrompt p, "Le premier paragraphe conserve l'amorce naturelle du courrier, notamment Je revois Monsieur/Madame [[PATIENT]] ou Je vois pour la premi�re fois, lorsqu'elle figure dans la source."
    AjouterLignePrompt p, "Pr�sente les ant�c�dents et l'�volution clinique dans un ou plusieurs paragraphes distincts selon leur longueur et leur coh�rence."
    AjouterLignePrompt p, "Pr�sente les sympt�mes actuels ou le caract�re asymptomatique dans un paragraphe distinct lorsqu'ils sont d�crits."
    AjouterLignePrompt p, "Pr�sente le traitement actuel et ses modifications dans un paragraphe distinct lorsqu'ils sont d�crits."
    AjouterLignePrompt p, "Toute donn�e d'examen clinique doit former un paragraphe distinct."
    AjouterLignePrompt p, "Toute description d'�lectrocardiogramme doit former un paragraphe distinct et ne doit jamais �tre coll�e aux sympt�mes, aux ant�c�dents ou � la conclusion."
    AjouterLignePrompt p, "Toute �chographie cardiaque, �chocardiographie, �choscopie, exploration Holter, MAPA, imagerie, test d'effort, scintigraphie, coroscanner ou autre examen d�crit doit former son propre paragraphe lorsqu'il comporte un r�sultat."
    AjouterLignePrompt p, "La biologie ou le bilan biologique doit former un paragraphe distinct lorsqu'il est d�crit."
    AjouterLignePrompt p, "Lorsqu'une synth�se existe dans le texte source, introduis-la de pr�f�rence par Au total : et place-la dans un paragraphe distinct."
    AjouterLignePrompt p, "Place la conduite � tenir, les modifications th�rapeutiques, les examens demand�s et le d�lai de suivi dans un ou plusieurs paragraphes distincts apr�s la synth�se."
    AjouterLignePrompt p, "N'invente jamais un examen clinique, un ECG, une �chographie, un Holter, une biologie, un ant�c�dent ou une conclusion pour compl�ter artificiellement la structure."
    AjouterLignePrompt p, "Conserve strictement les art�res, segments, pourcentages de st�nose, dates, gestes de revascularisation, valeurs chiffr�es, doses, d�lais et consignes pr�sents dans le texte source."
    AjouterLignePrompt p, "Retourne le courrier principal exclusivement entre les balises ---CORPS_COURRIER--- et ---FIN_CORPS_COURRIER---."

    AjouterLignePrompt p, "Ne r�dige aucune lettre compl�mentaire et aucun bloc DEMANDE_DESTINATION dans ce premier appel."
    AjouterLignePrompt p, ""
    AjouterLignePrompt p, "COURRIER M�DICAL ANONYMIS� � TRAITER :"
    AjouterLignePrompt p, "--------------------"
    p = p & texteAnonymise & vbCrLf
    AjouterLignePrompt p, "--------------------"

    ConstruirePromptReecritureMedicale = p

End Function

Public Function TexteContientDemandeExamenEligible( _
    ByVal texte As String) As Boolean

    Dim t As String

    t = NormaliserTexteDetectionDemande(texte)
    TexteContientDemandeExamenEligible = False

    'La rythmologie conserve sa securite specifique anti-faux-positif.
    If ContientDemandeRythmologiqueExplicite(t) Then
        TexteContientDemandeExamenEligible = True
        Exit Function
    End If

    'Tous les autres examens utilisent les dictionnaires NAS extensibles.
    If DDE_ContientDemandeEligible(texte) Then
        TexteContientDemandeExamenEligible = True
    End If

End Function

Public Sub TesterDetectionJeProposeEchodopplerVeineux()

    Dim texteTest As String

    texteTest = _
        "Par ailleurs, je propose la r�alisation d'un �chodoppler veineux " & _
        "des membres inf�rieurs afin d'exclure une origine veineuse � cet oed�me."

    If TexteContientDemandeExamenEligible(texteTest) Then
        MsgBox _
            "OK : la formulation 'je propose la r�alisation de' est reconnue " & _
            "comme une demande d'examen �ligible.", _
            vbInformation, _
            "Test d�tection demande"
    Else
        MsgBox _
            "ECHEC : la demande d'�cho-Doppler veineux n'a pas �t� d�tect�e.", _
            vbExclamation, _
            "Test d�tection demande"
    End If

End Sub


Public Sub TesterDetectionDictionnairesDDE1()
    DDE_TesterFormulationsInitiales
End Sub

Private Function NormaliserTexteDetectionDemande( _
    ByVal texte As String) As String

    texte = LCase$(texte)
    texte = Replace(texte, "'", "'")
    texte = Replace(texte, Chr(160), " ")
    texte = Replace(texte, vbTab, " ")
    texte = Replace(texte, vbCr, " ")
    texte = Replace(texte, vbLf, " ")

    Do While InStr(texte, "  ") > 0
        texte = Replace(texte, "  ", " ")
    Loop

    NormaliserTexteDetectionDemande = Trim$(texte)

End Function

Private Function ContientFormulationDemandeExamen( _
    ByVal t As String) As Boolean

    ContientFormulationDemandeExamen = False

    If InStr(1, t, "je lui demande", vbTextCompare) > 0 Then
        ContientFormulationDemandeExamen = True
        Exit Function
    End If

    If InStr(1, t, "je demande", vbTextCompare) > 0 Then
        ContientFormulationDemandeExamen = True
        Exit Function
    End If

    If InStr(1, t, "je sollicite", vbTextCompare) > 0 Then
        ContientFormulationDemandeExamen = True
        Exit Function
    End If

    If InStr(1, t, "je compl�te par", vbTextCompare) > 0 _
    Or InStr(1, t, "je complete par", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "je compl�te le bilan par", vbTextCompare) > 0 _
    Or InStr(1, t, "je complete le bilan par", vbTextCompare) > 0 _
    Or InStr(1, t, "je compl�terai par", vbTextCompare) > 0 _
    Or InStr(1, t, "je completerai par", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "je prescris", vbTextCompare) > 0 _
    Or InStr(1, t, "prescription de", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "merci de r�aliser", vbTextCompare) > 0 _
    Or InStr(1, t, "merci de realiser", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "il faut r�aliser", vbTextCompare) > 0 _
    Or InStr(1, t, "il faut realiser", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "je l'adresse", vbTextCompare) > 0 _
    Or InStr(1, t, "je l'adresse", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "je te laisse le soin de le diriger", vbTextCompare) > 0 _
    Or InStr(1, t, "je vous laisse le soin de le diriger", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "sera compl�t� par", vbTextCompare) > 0 _
    Or InStr(1, t, "sera complete par", vbTextCompare) > 0 _
    Or InStr(1, t, "nous compl�terons par", vbTextCompare) > 0 _
    Or InStr(1, t, "nous completerons par", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    'LETTRES-2N : orientation / adressage vers un centre ou un sp�cialiste.
    'Exemple : "Nous allons la diriger vers le CCN pour une ablation par radiofr�quence".
    If InStr(1, t, "nous allons le diriger", vbTextCompare) > 0 _
    Or InStr(1, t, "nous allons la diriger", vbTextCompare) > 0 _
    Or InStr(1, t, "je vais le diriger", vbTextCompare) > 0 _
    Or InStr(1, t, "je vais la diriger", vbTextCompare) > 0 _
    Or InStr(1, t, "nous allons l'adresser", vbTextCompare) > 0 _
    Or InStr(1, t, "nous allons l'adresser", vbTextCompare) > 0 _
    Or InStr(1, t, "je vais l'adresser", vbTextCompare) > 0 _
    Or InStr(1, t, "je vais l'adresser", vbTextCompare) > 0 _
    Or InStr(1, t, "je l'oriente", vbTextCompare) > 0 _
    Or InStr(1, t, "je l'oriente", vbTextCompare) > 0 _
    Or InStr(1, t, "nous l'orientons", vbTextCompare) > 0 _
    Or InStr(1, t, "nous l'orientons", vbTextCompare) > 0 _
    Or InStr(1, t, "je le confie", vbTextCompare) > 0 _
    Or InStr(1, t, "je la confie", vbTextCompare) > 0 _
    Or InStr(1, t, "nous le confions", vbTextCompare) > 0 _
    Or InStr(1, t, "nous la confions", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    'LETTRES-2L : une proposition explicite de r�alisation constitue une demande.
    'Cette r�gle couvre notamment : "je propose la r�alisation d'un �cho-Doppler".
    If InStr(1, t, "je propose", vbTextCompare) > 0 _
    Or InStr(1, t, "nous proposons", vbTextCompare) > 0 _
    Or InStr(1, t, "je pr�conise", vbTextCompare) > 0 _
    Or InStr(1, t, "je preconise", vbTextCompare) > 0 _
    Or InStr(1, t, "nous pr�conisons", vbTextCompare) > 0 _
    Or InStr(1, t, "nous preconisons", vbTextCompare) > 0 _
    Or InStr(1, t, "je recommande", vbTextCompare) > 0 _
    Or InStr(1, t, "nous recommandons", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    'LETTRES-2D : formulations prospectives de prescription.
    If InStr(1, t, "je pr�vois", vbTextCompare) > 0 _
    Or InStr(1, t, "je prevois", vbTextCompare) > 0 _
    Or InStr(1, t, "nous pr�voyons", vbTextCompare) > 0 _
    Or InStr(1, t, "nous prevoyons", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "je programme", vbTextCompare) > 0 _
    Or InStr(1, t, "nous programmons", vbTextCompare) > 0 _
    Or InStr(1, t, "je vais programmer", vbTextCompare) > 0 _
    Or InStr(1, t, "nous allons programmer", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "je souhaite r�aliser", vbTextCompare) > 0 _
    Or InStr(1, t, "je souhaite realiser", vbTextCompare) > 0 _
    Or InStr(1, t, "je souhaite faire r�aliser", vbTextCompare) > 0 _
    Or InStr(1, t, "je souhaite faire realiser", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "je vais lui faire r�aliser", vbTextCompare) > 0 _
    Or InStr(1, t, "je vais lui faire realiser", vbTextCompare) > 0 _
    Or InStr(1, t, "nous allons r�aliser", vbTextCompare) > 0 _
    Or InStr(1, t, "nous allons realiser", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

    If InStr(1, t, "avis sp�cialis�", vbTextCompare) > 0 _
    Or InStr(1, t, "avis specialise", vbTextCompare) > 0 Then

        ContientFormulationDemandeExamen = True
        Exit Function

    End If

End Function

Private Function ContientExamenEligible( _
    ByVal t As String) As Boolean

    ContientExamenEligible = False

    If InStr(1, t, "test d'effort", vbTextCompare) > 0 _
    Or InStr(1, t, "�preuve d'effort", vbTextCompare) > 0 _
    Or InStr(1, t, "epreuve d'effort", vbTextCompare) > 0 Then

        ContientExamenEligible = True
        Exit Function

    End If

    If InStr(1, t, "scintigraphie", vbTextCompare) > 0 _
    Or InStr(1, t, "coroscanner", vbTextCompare) > 0 _
    Or InStr(1, t, "coro-scanner", vbTextCompare) > 0 _
    Or InStr(1, t, "score calcique", vbTextCompare) > 0 Then

        ContientExamenEligible = True
        Exit Function

    End If

    If InStr(1, t, "scanner", vbTextCompare) > 0 _
    Or InStr(1, t, "angioscanner", vbTextCompare) > 0 _
    Or InStr(1, t, "irm", vbTextCompare) > 0 _
    Or InStr(1, t, "coronarographie", vbTextCompare) > 0 Then

        ContientExamenEligible = True
        Exit Function

    End If

    If InStr(1, t, "�cho-doppler", vbTextCompare) > 0 _
    Or InStr(1, t, "echo-doppler", vbTextCompare) > 0 _
    Or InStr(1, t, "echodoppler", vbTextCompare) > 0 _
    Or InStr(1, t, "doppler des vaisseaux", vbTextCompare) > 0 _
    Or InStr(1, t, "troncs supra-aortiques", vbTextCompare) > 0 _
    Or InStr(1, t, "bilan vasculaire", vbTextCompare) > 0 Then

        ContientExamenEligible = True
        Exit Function

    End If

    If InStr(1, t, "avis neurologique", vbTextCompare) > 0 _
    Or InStr(1, t, "neurologue", vbTextCompare) > 0 _
    Or InStr(1, t, "avis vasculaire", vbTextCompare) > 0 _
    Or InStr(1, t, "chirurgien vasculaire", vbTextCompare) > 0 _
    Or InStr(1, t, "avis sp�cialis�", vbTextCompare) > 0 _
    Or InStr(1, t, "avis specialise", vbTextCompare) > 0 Then

        ContientExamenEligible = True
        Exit Function

    End If

End Function

'===============================================================================
' Fonction conserv�e sous son nom historique afin de ne pas casser les appels
' existants. En v22, elle demande d�sormais les nouveaux blocs structur�s.
'===============================================================================

Private Function ContientDemandeRythmologiqueExplicite( _
    ByVal t As String) As Boolean

    Dim textePhrases As String
    Dim phrases() As String
    Dim phrase As String
    Dim i As Long

    ContientDemandeRythmologiqueExplicite = False

    textePhrases = Replace(t, "!", ".")
    textePhrases = Replace(textePhrases, "?", ".")
    phrases = Split(textePhrases, ".")

    For i = LBound(phrases) To UBound(phrases)

        phrase = Trim$(CStr(phrases(i)))

        If phrase <> "" Then
            If PRM_ContientCibleRythmologique(phrase) _
            And PRM_ContientIntentionRythmologique(phrase) Then

                ContientDemandeRythmologiqueExplicite = True
                Exit Function

            End If
        End If

    Next i

End Function

Private Function PRM_ContientCibleRythmologique( _
    ByVal phrase As String) As Boolean

    PRM_ContientCibleRythmologique = False

    If InStr(1, phrase, "ablation par radiofr�quence", vbTextCompare) > 0 _
    Or InStr(1, phrase, "ablation par radiofrequence", vbTextCompare) > 0 _
    Or InStr(1, phrase, "ablation de fibrillation auriculaire", vbTextCompare) > 0 _
    Or InStr(1, phrase, "ablation de fa", vbTextCompare) > 0 _
    Or InStr(1, phrase, "ablation de flutter", vbTextCompare) > 0 _
    Or InStr(1, phrase, "ablation rythmologique", vbTextCompare) > 0 _
    Or InStr(1, phrase, "exploration �lectrophysiologique", vbTextCompare) > 0 _
    Or InStr(1, phrase, "exploration electrophysiologique", vbTextCompare) > 0 _
    Or InStr(1, phrase, "�lectrophysiologie", vbTextCompare) > 0 _
    Or InStr(1, phrase, "electrophysiologie", vbTextCompare) > 0 _
    Or InStr(1, phrase, "avis rythmologique", vbTextCompare) > 0 _
    Or InStr(1, phrase, "rythmologue", vbTextCompare) > 0 _
    Or InStr(1, phrase, "rythmologie", vbTextCompare) > 0 _
    Or InStr(1, phrase, "ccn", vbTextCompare) > 0 Then

        PRM_ContientCibleRythmologique = True

    End If

End Function

Private Function PRM_ContientIntentionRythmologique( _
    ByVal phrase As String) As Boolean

    Dim futurPremierePersonne As Boolean
    Dim verbeOrientation As Boolean

    PRM_ContientIntentionRythmologique = False

    'Intentions explicites suffisamment sp�cifiques � elles seules.
    If InStr(1, phrase, "je lui demande", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je demande", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je sollicite", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je prescris", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je propose", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous proposons", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je pr�conise", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je preconise", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous pr�conisons", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous preconisons", vbTextCompare) > 0 Then

        PRM_ContientIntentionRythmologique = True
        Exit Function

    End If

    If InStr(1, phrase, "je recommande", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous recommandons", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je pr�vois", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je prevois", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous pr�voyons", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous prevoyons", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je programme", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous programmons", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je souhaite", vbTextCompare) > 0 Then

        PRM_ContientIntentionRythmologique = True
        Exit Function

    End If

    If InStr(1, phrase, "je l'adresse", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je l'oriente", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous l'orientons", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je le confie", vbTextCompare) > 0 _
    Or InStr(1, phrase, "je la confie", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous le confions", vbTextCompare) > 0 _
    Or InStr(1, phrase, "nous la confions", vbTextCompare) > 0 Then

        PRM_ContientIntentionRythmologique = True
        Exit Function

    End If

    'Pour "nous allons" / "je vais", exiger en plus un verbe d'action afin
    'd'�viter qu'une phrase comme "nous allons poursuivre le traitement ; une
    'ablation avait �t� discut�e" ne soit prise pour une prescription.
    futurPremierePersonne = _
        (InStr(1, phrase, "nous allons", vbTextCompare) > 0) _
        Or (InStr(1, phrase, "je vais", vbTextCompare) > 0)

    verbeOrientation = _
        (InStr(1, phrase, "diriger", vbTextCompare) > 0) _
        Or (InStr(1, phrase, "adresser", vbTextCompare) > 0) _
        Or (InStr(1, phrase, "orienter", vbTextCompare) > 0) _
        Or (InStr(1, phrase, "confier", vbTextCompare) > 0) _
        Or (InStr(1, phrase, "r�aliser", vbTextCompare) > 0) _
        Or (InStr(1, phrase, "realiser", vbTextCompare) > 0) _
        Or (InStr(1, phrase, "programmer", vbTextCompare) > 0)

    If futurPremierePersonne And verbeOrientation Then
        PRM_ContientIntentionRythmologique = True
    End If

End Function

Public Sub TesterDetectionDirigerCCNAblation()

    Dim texteTest As String

    texteTest = _
        "Nous allons donc la diriger vers le CCN pour une " & _
        "ablation par radiofr�quence."

    If TexteContientDemandeExamenEligible(texteTest) Then
        MsgBox _
            "OK : l'orientation vers le CCN pour ablation est reconnue " & _
            "comme une demande de prise en charge sp�cialis�e.", _
            vbInformation, _
            "Test d�tection rythmologie"
    Else
        MsgBox _
            "�CHEC : la formulation n'est pas reconnue.", _
            vbExclamation, _
            "Test d�tection rythmologie"
    End If

End Sub

Public Sub TesterAbsenceDeclenchementMentionRythmologie()

    Dim texteTest As String

    texteTest = _
        "Une ablation par radiofr�quence avait �t� discut�e ant�rieurement au CCN, " & _
        "sans indication retenue � ce jour. Je poursuis le traitement m�dical."

    If TexteContientDemandeExamenEligible(texteTest) Then
        MsgBox _
            "ECHEC : une simple mention historique d�clenche encore une demande.", _
            vbExclamation, _
            "Test absence de faux positif"
    Else
        MsgBox _
            "OK : la mention historique d'ablation / CCN ne d�clenche aucune lettre.", _
            vbInformation, _
            "Test absence de faux positif"
    End If

End Sub

Public Function ConstruirePromptDemandeExamenSeule( _
    ByVal texteAnonymise As String) As String

    'R12 : le deuxieme appel ne redige plus de lettre complete.
    'Le plan local a ete prepare par modDemandesStructureesR8.
    ConstruirePromptDemandeExamenSeule = _
        R12_ConstruirePromptDeuxiemeAppel(texteAnonymise)

End Function

Public Function ConstruireConsignesDemandesExamensDetaillees() As String

    Dim p As String

    p = ""

    AjouterLignePrompt p, "Le corps d'une demande d'examen commence normalement par : Merci de r�aliser un/une NOM DE L'EXAMEN � Monsieur/Madame [[PATIENT]], [�ge], [motif ou contexte utile]."
    AjouterLignePrompt p, "Le corps d'une demande de consultation sp�cialis�e commence normalement par : Merci de prendre en charge Monsieur/Madame [[PATIENT]], [�ge], pour [motif]."
    AjouterLignePrompt p, "Le premier paragraphe de chaque demande doit contenir l'identit� du patient, son �ge lorsqu'il est pr�sent, l'examen ou l'avis demand� et le motif r�el de la demande."
    AjouterLignePrompt p, "Les paragraphes suivants ne reprennent que les ant�c�dents, sympt�mes, traitements et r�sultats n�cessaires � la compr�hension de l'indication ; ne recopie pas tout le courrier principal."
    AjouterLignePrompt p, "Reprends syst�matiquement le contexte anamnestique pertinent lorsqu'il existe."
    AjouterLignePrompt p, "Reprends syst�matiquement l'examen clinique dans un paragraphe autonome lorsqu'il existe dans le courrier principal."
    AjouterLignePrompt p, "Reprends syst�matiquement l'�lectrocardiogramme dans un paragraphe autonome lorsqu'il existe dans le courrier principal."
    AjouterLignePrompt p, "Dans une demande compl�mentaire, pr�sente s�par�ment les donn�es d'examen clinique, d'�lectrocardiogramme, d'�chographie cardiaque, de Holter et de bilan biologique lorsqu'elles sont reprises."
    AjouterLignePrompt p, "Fais commencer ces paragraphes de fa�on naturelle, par exemple L'�lectrocardiogramme..., L'�chographie cardiaque..., Le Holter rythmique... ou Le bilan biologique..., sans cr�er de titre artificiel."
    AjouterLignePrompt p, "Conserve exactement toute consigne d'arr�t ou de reprise d'un m�dicament avant l'examen, avec le nom du m�dicament et le d�lai indiqu�s."
    AjouterLignePrompt p, "Termine, si cela apporte une information utile et non redondante, par une formule br�ve du type Merci de v�rifier..., Merci de confirmer... ou Merci d'�valuer...."
    AjouterLignePrompt p, "Une demande de score calcique doit rester tr�s br�ve et reprendre seulement le terrain de risque ou l'objectif pr�ventif r�ellement pr�sent."
    AjouterLignePrompt p, "Une demande d'�cho-Doppler doit reprendre seulement le terrain vasculaire, les sympt�mes, les anomalies de pouls, les ant�c�dents vasculaires et l'objectif r�ellement utiles."
    AjouterLignePrompt p, "Une demande de test d'effort ou de scintigraphie myocardique doit reprendre les sympt�mes, le contexte coronarien ou la revascularisation, l'ECG pertinent, les examens ant�rieurs utiles et toute consigne d'arr�t m�dicamenteux pr�sente."
    AjouterLignePrompt p, "Une demande de coroscanner ou d'angioscanner coronaire doit reprendre les sympt�mes, les facteurs de risque, les examens ant�rieurs et la question anatomique r�ellement pos�e."
    AjouterLignePrompt p, "Une demande de consultation sp�cialis�e doit �tre concise, exposer la probl�matique et les �l�ments utiles, puis formuler clairement la question ou la prise en charge attendue."
    AjouterLignePrompt p, "Le corps d'une demande ne doit contenir ni adresse, ni bloc destinataire, ni formule d'appel, ni formule de politesse, ni signature."

    ConstruireConsignesDemandesExamensDetaillees = p

End Function


Public Function ConstruireConsignesDemandesStructureesAPI() As String

    Dim p As String

    p = ""

    AjouterLignePrompt p, "Apr�s le bloc du courrier principal, produis un bloc de demande compl�mentaire uniquement lorsqu'une d�cision explicite et actuelle ou future de prescrire, programmer, faire r�aliser, adresser, orienter, diriger ou confier le patient est r�ellement exprim�e."
    AjouterLignePrompt p, "Une simple mention historique, un r�sultat d'examen, une possibilit� discut�e, une hypoth�se, une formulation conditionnelle ou un projet non d�cid� ne doit d�clencher aucun courrier compl�mentaire."
    AjouterLignePrompt p, "Sont des formulations explicites de demande, lorsqu'elles sont li�es � l'examen ou � l'avis dans le m�me passage : Je pr�vois, Je programme, Je lui demande, Je compl�te par, Je propose la r�alisation de, Merci de r�aliser, Nous allons l'adresser, Nous allons le/la diriger, Je l'oriente ou Je le/la confie."
    AjouterLignePrompt p, "Pour une ablation, une exploration �lectrophysiologique, un avis rythmologique, un rythmologue ou le CCN, ne produis une demande que si la d�cision d'orientation est explicitement exprim�e dans la m�me phrase ou le m�me passage imm�diat."
    AjouterLignePrompt p, "Ne produis pas de courrier compl�mentaire s�par� pour une �chographie cardiaque, une �chographie transthoracique, une ETT, un Holter rythmique, un Holter ECG, un Holter tensionnel ou une MAPA."
    AjouterLignePrompt p, "Regroupe dans un m�me bloc les examens ayant exactement la m�me cl� de destination r�elle ; produis des blocs distincts pour des destinations diff�rentes."
    AjouterLignePrompt p, "Utilise exclusivement les cl�s de destination fournies ci-dessous ; utilise A_COMPLETER si aucune cl� ne convient ou si le correspondant pr�cis n'est pas connu."
    AjouterLignePrompt p, "Pour une consultation, un avis ou un geste th�rapeutique, si le texte ne cite qu'un �tablissement, un centre, un service ou un acronyme institutionnel sans nommer de m�decin correspondant, utilise CLE_DESTINATION=A_COMPLETER."

    AjouterLignePrompt p, ""
    p = p & ConstruireReglesDestinationsPrompt()
    AjouterLignePrompt p, ""
    p = p & ConstruireConsignesDemandesExamensDetaillees()
    AjouterLignePrompt p, "Chaque demande doit respecter exactement le format indiqu� ci-dessous."
    AjouterFormatDemandeAuPrompt p
    AjouterLignePrompt p, "N'�cris aucun bloc DEMANDE_DESTINATION si aucune demande �ligible n'est explicitement d�cid�e dans le courrier source."
    AjouterLignePrompt p, "N'�cris rien en dehors du bloc CORPS_COURRIER et des �ventuels blocs DEMANDE_DESTINATION."

    ConstruireConsignesDemandesStructureesAPI = p

End Function

Private Function ConstruireReglesDestinationsPrompt() As String

    Dim p As String

    p = ""
    AjouterLignePrompt p, "R�gles de destination issues de la base Excel :"

    AjouterRegleDestinationDepuisBase p, "TEST_EFFORT", "Test d'effort ou �preuve d'effort"
    AjouterRegleDestinationDepuisBase p, "SCINTIGRAPHIE_MYOCARDIQUE", "Scintigraphie myocardique"
    AjouterRegleDestinationDepuisBase p, "COROSCANNER", "Coroscanner ou scanner coronaire"
    AjouterRegleDestinationDepuisBase p, "SCORE_CALCIQUE", "Score calcique"
    AjouterRegleDestinationDepuisBase p, "ECHODOPPLER_VAISSEAUX_DU_COU", "�cho-Doppler des vaisseaux du cou ou des troncs supra-aortiques"
    AjouterRegleDestinationDepuisBase p, "ECHODOPPLER_MEMBRES_INFERIEURS", "�cho-Doppler des membres inf�rieurs"
    AjouterRegleDestinationDepuisBase p, "ECHODOPPLER_ARTERIEL", "�cho-Doppler art�riel"
    AjouterRegleDestinationDepuisBase p, "ECHODOPPLER_VEINEUX", "�cho-Doppler veineux"
    AjouterRegleDestinationDepuisBase p, "AVIS_NEUROLOGIE", "Avis neurologique"
    AjouterRegleDestinationDepuisBase p, "AVIS_RYTHMOLOGIE", "Avis rythmologique"
    AjouterRegleDestinationDepuisBase p, "AVIS_VASCULAIRE", "Avis vasculaire"

    AjouterLignePrompt p, "- Tout autre examen ou avis sp�cialis� : " & PREFIXE_CLE_DESTINATION & "A_COMPLETER"

    ConstruireReglesDestinationsPrompt = p

End Function

Private Sub AjouterFormatDemandeAuPrompt(ByRef p As String)

    AjouterLignePrompt p, BALISE_DEBUT_DEMANDE_DESTINATION
    AjouterLignePrompt p, PREFIXE_CLE_DESTINATION & "CLE_EXACTE"
    AjouterLignePrompt p, BALISE_DEBUT_CORPS_DESTINATION
    AjouterLignePrompt p, "Corps m�dical de la demande"
    AjouterLignePrompt p, BALISE_FIN_CORPS_DESTINATION
    AjouterLignePrompt p, BALISE_FIN_DEMANDE_DESTINATION

End Sub

Private Sub AjouterLignePrompt( _
    ByRef p As String, _
    ByVal ligne As String)

    p = p & ligne & vbCrLf

End Sub

Public Sub TesterPromptCorpus4307()

    Dim p As String
    Dim texteTest As String

    texteTest = _
        "Je revois Madame [[PATIENT]], 70 ans. " & _
        "Je lui demande une scintigraphie myocardique."

    p = ConstruirePromptReecritureMedicale(texteTest)

    If InStr(1, p, "---CORPS_COURRIER---", vbTextCompare) > 0 _
    And InStr(1, p, "Ne redige aucune lettre complementaire", vbTextCompare) > 0 _
    And InStr(1, p, texteTest, vbTextCompare) > 0 _
    And InStr(1, p, BALISE_DEBUT_DEMANDE_DESTINATION, vbTextCompare) = 0 Then

        MsgBox _
            "OK : le premier prompt produit uniquement le courrier principal." & _
            vbCrLf & "Longueur : " & Len(p) & " caracteres.", _
            vbInformation, _
            "Test prompt R8"
    Else
        MsgBox _
            "ECHEC : le contrat du premier prompt R8 n'est pas respecte.", _
            vbExclamation, _
            "Test prompt R8"
    End If

End Sub

Private Sub AjouterRegleDestinationDepuisBase( _
    ByRef prompt As String, _
    ByVal typeExamen As String, _
    ByVal libelle As String)

    prompt = prompt & _
        "- " & libelle & " [" & typeExamen & "] : " & _
        PREFIXE_CLE_DESTINATION & _
        CleDestinationPourPrompt(typeExamen) & vbCrLf

End Sub

Private Function CleDestinationPourPrompt( _
    ByVal typeExamen As String) As String

    Dim recordDestination As String
    Dim cleDestination As String

    On Error GoTo GestionErreur

    recordDestination = _
        DestinationParDefautPourTypeExamen(typeExamen)

    If Trim$(recordDestination) = "" Then
        CleDestinationPourPrompt = "A_COMPLETER"
        Exit Function
    End If

    cleDestination = _
        Trim$(ChampDestination(recordDestination, 10))

    If cleDestination = "" Then
        cleDestination = "A_COMPLETER"
    End If

    CleDestinationPourPrompt = UCase$(cleDestination)
    Exit Function

GestionErreur:

    CleDestinationPourPrompt = "A_COMPLETER"

End Function
