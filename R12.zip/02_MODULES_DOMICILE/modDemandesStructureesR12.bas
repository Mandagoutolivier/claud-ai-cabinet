Attribute VB_Name = "modDemandesStructureesR12"
Option Explicit
Option Private Module

'===============================================================================
' MODULE : modDemandesStructureesR12
' VERSION : R12 - PROFILS EXTERNES PAR TYPE D'EXAMEN
'
' Architecture :
' - la detection des demandes reste locale et extensible via DDE ;
' - le plan local fixe les identifiants, examens, nature et destination ;
' - le deuxieme appel API ne redige jamais une lettre complete ;
' - il renvoie uniquement des rubriques medicales neutres ;
' - le VBA construit le premier paragraphe, les paragraphes techniques et le
'   bloc DEMANDE_DESTINATION attendu par le reste du modele ;
' - toute rubrique non conforme est remplacee par un brouillon a completer ;
' - un troisieme appel API optionnel revise uniquement le brouillon assemble ;
' - le VBA refuse toute revision qui modifie les tags ou les valeurs critiques.
'===============================================================================

Private Const R12_DOSSIER_CONFIG As String = _
    "\\DS224\home\logiciel_chatgpt_cabinet"
Private Const R12_FICHIER_EXAMENS As String = _
    "\\DS224\home\logiciel_chatgpt_cabinet\examens_complementaires.txt"

Private Const R12_DEBUT_FICHE As String = _
    "---FICHE_MEDICALE_DEMANDE---"
Private Const R12_FIN_FICHE As String = _
    "---FIN_FICHE_MEDICALE_DEMANDE---"
Private Const R12_PREFIXE_ID As String = "ID_DEMANDE="

Private Const R12_DEBUT_MOTIF As String = "---MOTIF---"
Private Const R12_FIN_MOTIF As String = "---FIN_MOTIF---"
Private Const R12_DEBUT_ANAMNESE As String = "---ANAMNESE---"
Private Const R12_FIN_ANAMNESE As String = "---FIN_ANAMNESE---"
Private Const R12_DEBUT_TRAITEMENTS As String = "---TRAITEMENTS---"
Private Const R12_FIN_TRAITEMENTS As String = "---FIN_TRAITEMENTS---"
Private Const R12_DEBUT_CLINIQUE As String = "---EXAMEN_CLINIQUE---"
Private Const R12_FIN_CLINIQUE As String = "---FIN_EXAMEN_CLINIQUE---"
Private Const R12_DEBUT_ECG As String = "---ECG---"
Private Const R12_FIN_ECG As String = "---FIN_ECG---"
Private Const R12_DEBUT_ECHO As String = "---ECHOGRAPHIE---"
Private Const R12_FIN_ECHO As String = "---FIN_ECHOGRAPHIE---"
Private Const R12_DEBUT_HOLTER As String = "---HOLTER---"
Private Const R12_FIN_HOLTER As String = "---FIN_HOLTER---"
Private Const R12_DEBUT_BIOLOGIE As String = "---BIOLOGIE---"
Private Const R12_FIN_BIOLOGIE As String = "---FIN_BIOLOGIE---"
Private Const R12_DEBUT_AUTRES As String = "---AUTRES_EXAMENS---"
Private Const R12_FIN_AUTRES As String = "---FIN_AUTRES_EXAMENS---"
Private Const R12_DEBUT_QUESTION As String = "---QUESTION---"
Private Const R12_FIN_QUESTION As String = "---FIN_QUESTION---"


Private Const R12_SEP_LISTE As String = "|||R12|||"

Private mPlanDemandes As Collection
Private mTexteSourcePlan As String
Private mDernierMessage As String
Private mDernierNombreBrouillons As Long

Public Sub R12_ReinitialiserEtatDemandes()
    Set mPlanDemandes = Nothing
    mTexteSourcePlan = ""
    mDernierMessage = ""
    mDernierNombreBrouillons = 0
End Sub

'-------------------------------------------------------------------------------
' API PUBLIQUE
'-------------------------------------------------------------------------------

Public Function R12_PreparerPlanDemandes( _
    ByVal texteSourceAnonymise As String) As Boolean

    On Error GoTo GestionErreur

    mDernierMessage = ""
    mDernierNombreBrouillons = 0
    mTexteSourcePlan = texteSourceAnonymise

    Set mPlanDemandes = R12_ConstruirePlanDemandes(texteSourceAnonymise)

    If mPlanDemandes Is Nothing Then
        mDernierMessage = "Le plan local des demandes n'a pas pu etre construit."
        Exit Function
    End If

    If mPlanDemandes.Count = 0 Then
        mDernierMessage = _
            "Une demande a ete detectee, mais aucun examen ou avis n'a pu " & _
            "etre identifie dans examens_complementaires.txt."
        Exit Function
    End If

    R12_PreparerPlanDemandes = True
    Exit Function

GestionErreur:

    Set mPlanDemandes = Nothing
    mDernierMessage = _
        "Erreur pendant la construction du plan local : " & _
        Err.Number & " - " & Err.Description

End Function

Public Function R12_ConstruirePromptDeuxiemeAppel( _
    ByVal courrierPrincipalCorrige As String) As String

    R12_ConstruirePromptDeuxiemeAppel = _
        R12_ConstruirePromptProfils( _
            mPlanDemandes, _
            courrierPrincipalCorrige)

End Function

Public Function R12_ConvertirFichesEnBlocsDemandes( _
    ByVal reponseStructuree As String, _
    ByVal courrierPrincipalCorrige As String, _
    ByRef messageConversion As String, _
    ByRef nombreBrouillons As Long) As String

    R12_ConvertirFichesEnBlocsDemandes = _
        R12_ConvertirReponseProfils( _
            mPlanDemandes, _
            reponseStructuree, _
            courrierPrincipalCorrige, _
            messageConversion, _
            nombreBrouillons)

    mDernierMessage = messageConversion
    mDernierNombreBrouillons = nombreBrouillons

End Function

Public Function R12_DernierMessage() As String
    R12_DernierMessage = mDernierMessage
End Function

Public Function R12_DernierNombreBrouillons() As Long
    R12_DernierNombreBrouillons = mDernierNombreBrouillons
End Function

Public Function R12_Version() As String
    R12_Version = "R12-PROFILS-3-API"
End Function

'-------------------------------------------------------------------------------
' CONSTRUCTION DU PLAN LOCAL A PARTIR DES DICTIONNAIRES DDE
'-------------------------------------------------------------------------------

Private Function R12_ConstruirePlanDemandes( _
    ByVal texteSource As String) As Collection

    Dim resultat As Collection
    Dim groupes As Object
    Dim ordreGroupes As Collection
    Dim unites As Collection
    Dim unite As Variant
    Dim detections As Collection
    Dim detection As Object
    Dim demande As Object
    Dim cleGroupe As String
    Dim cle As Variant
    Dim compteur As Long

    Set resultat = New Collection
    Set groupes = CreateObject("Scripting.Dictionary")
    Set ordreGroupes = New Collection
    Set unites = R12_DecouperUnites(texteSource)

    For Each unite In unites

        If DDE_ContientDemandeEligible(CStr(unite)) Or _
           R12_DemandeRythmologiqueExplicite(CStr(unite)) Then

            Set detections = R12_ExamensDansUnite(CStr(unite))

            For Each detection In detections

                Set demande = R12_CreerDemandeElementaire( _
                    CStr(detection("Type")), _
                    CStr(detection("Expression")), _
                    CStr(unite))

                cleGroupe = R12_CleGroupe(demande)

                If groupes.Exists(cleGroupe) Then
                    R12_FusionnerDemande groupes(cleGroupe), demande
                Else
                    groupes.Add cleGroupe, demande
                    ordreGroupes.Add cleGroupe
                End If

            Next detection

        End If

    Next unite

    compteur = 0

    For Each cle In ordreGroupes
        compteur = compteur + 1
        Set demande = groupes(CStr(cle))
        demande("IDDemande") = "D" & Format$(compteur, "000")
        resultat.Add demande
    Next cle

    Set R12_ConstruirePlanDemandes = resultat

End Function

Private Function R12_ExamensDansUnite( _
    ByVal unite As String) As Collection

    Dim resultat As Collection
    Dim meilleurs As Object
    Dim lignes As Variant
    Dim ligne As Variant
    Dim morceaux As Variant
    Dim expression As String
    Dim typeExamen As String
    Dim t As String
    Dim detection As Object
    Dim cle As Variant

    Set resultat = New Collection
    Set meilleurs = CreateObject("Scripting.Dictionary")
    t = R12_Normaliser(unite)

    lignes = R12_LireLignesFichier(R12_FICHIER_EXAMENS)

    If IsArray(lignes) Then
        For Each ligne In lignes

            expression = Trim$(CStr(ligne))

            If expression <> "" And Left$(expression, 1) <> "#" Then

                morceaux = Split(expression, "|")
                expression = Trim$(CStr(morceaux(0)))

                If UBound(morceaux) >= 1 Then
                    typeExamen = UCase$(Trim$(CStr(morceaux(1))))
                Else
                    typeExamen = UCase$(Replace(expression, " ", "_"))
                End If

                If expression <> "" And _
                   InStr(1, t, R12_Normaliser(expression), vbTextCompare) > 0 Then

                    If Not meilleurs.Exists(typeExamen) Then
                        meilleurs.Add typeExamen, expression
                    ElseIf Len(expression) > Len(CStr(meilleurs(typeExamen))) Then
                        meilleurs(typeExamen) = expression
                    End If

                End If

            End If

        Next ligne
    End If

    If R12_DemandeRythmologiqueExplicite(unite) Then
        meilleurs("AVIS_RYTHMOLOGIE") = "prise en charge rythmologique"
    End If

    R12_SupprimerTypesGeneriques meilleurs

    For Each cle In meilleurs.Keys
        Set detection = CreateObject("Scripting.Dictionary")
        detection.Add "Type", CStr(cle)
        detection.Add "Expression", CStr(meilleurs(cle))
        resultat.Add detection
    Next cle

    Set R12_ExamensDansUnite = resultat

End Function

Private Sub R12_SupprimerTypesGeneriques(ByVal d As Object)

    If d.Exists("HOSPITALISATION_CCN") Then
        If d.Exists("HOSPITALISATION_AUTRE_CENTRE") Then
            d.Remove "HOSPITALISATION_AUTRE_CENTRE"
        End If
        If d.Exists("AVIS_RYTHMOLOGIE") Then d.Remove "AVIS_RYTHMOLOGIE"
        If d.Exists("AVIS_RYTHMOLOGIQUE") Then d.Remove "AVIS_RYTHMOLOGIQUE"
    End If

    If d.Exists("ECHODOPPLER_ARTERIEL_TSA_ET_MEMBRES_INFERIEURS") Then
        If d.Exists("ECHODOPPLER_TSA") Then d.Remove "ECHODOPPLER_TSA"
        If d.Exists("ECHODOPPLER_ARTERIEL") Then d.Remove "ECHODOPPLER_ARTERIEL"
        If d.Exists("ECHODOPPLER_MI") Then d.Remove "ECHODOPPLER_MI"
        If d.Exists("DOPPLER") Then d.Remove "DOPPLER"
        If d.Exists("BILAN_VASCULAIRE") Then d.Remove "BILAN_VASCULAIRE"
    End If

    If d.Exists("ANGIOSCANNER_PULMONAIRE") Or _
       d.Exists("ANGIOSCANNER_TSA") Or _
       d.Exists("ANGIOSCANNER_AORTE_MEMBRES_INFERIEURS") Or _
       d.Exists("ANGIOSCANNER_ARTERES_RENALES") Or _
       d.Exists("ANGIOSCANNER_RENAL_SURRENALIEN") Then

        If d.Exists("ANGIOSCANNER") Then d.Remove "ANGIOSCANNER"
        If d.Exists("SCANNER") Then d.Remove "SCANNER"
    End If

    If d.Exists("SCANNER_THORACIQUE") Or _
       d.Exists("SCANNER_RENAL") Or _
       d.Exists("SCANNER_SURRENALIEN") Or _
       d.Exists("COROSCANNER") Then

        If d.Exists("SCANNER") Then d.Remove "SCANNER"
    End If

    If d.Exists("ECHODOPPLER_VEINEUX") Or _
       d.Exists("ECHODOPPLER_ARTERIEL") Or _
       d.Exists("ECHODOPPLER_TSA") Or _
       d.Exists("ECHODOPPLER_MI") Or _
       d.Exists("ECHODOPPLER_ARTERIEL_MEMBRES_INFERIEURS") Then

        If d.Exists("DOPPLER") Then d.Remove "DOPPLER"
        If d.Exists("BILAN_VASCULAIRE") Then d.Remove "BILAN_VASCULAIRE"
    End If

    If d.Exists("AVIS_NEUROLOGIE") Or _
       d.Exists("AVIS_NEUROLOGIQUE") Or _
       d.Exists("AVIS_GASTROENTEROLOGIE") Or _
       d.Exists("AVIS_GASTROENTEROLOGIQUE") Or _
       d.Exists("AVIS_PNEUMOLOGIE") Or _
       d.Exists("AVIS_PNEUMOLOGIQUE") Or _
       d.Exists("AVIS_NEPHROLOGIE") Or _
       d.Exists("AVIS_NEPHROLOGIQUE") Or _
       d.Exists("AVIS_HEMATOLOGIE") Or _
       d.Exists("AVIS_HEMATOLOGIQUE") Or _
       d.Exists("AVIS_VASCULAIRE") Or _
       d.Exists("AVIS_RYTHMOLOGIE") Or _
       d.Exists("AVIS_RYTHMOLOGIQUE") Then

        If d.Exists("AVIS_SPECIALISE") Then d.Remove "AVIS_SPECIALISE"
    End If

End Sub

Private Function R12_CreerDemandeElementaire( _
    ByVal typeExamen As String, _
    ByVal expressionTrouvee As String, _
    ByVal phraseSource As String) As Object

    Dim d As Object
    Dim profil As Object
    Dim profilCode As String
    Dim nature As String
    Dim typeBase As String
    Dim modeDestination As String
    Dim recordDestination As String
    Dim cleDestination As String
    Dim intitule As String

    Set d = CreateObject("Scripting.Dictionary")

    profilCode = R12_ProfilPourType( _
        typeExamen, _
        expressionTrouvee, _
        phraseSource)

    Set profil = R12_ChargerProfil(profilCode)

    nature = UCase$(R12_ProfilValeur( _
        profil, _
        "IDENTITE", _
        "NATURE", _
        "EXAMEN"))

    typeBase = UCase$(R12_ProfilValeur( _
        profil, _
        "IDENTITE", _
        "TYPE_BASE", _
        profilCode))

    modeDestination = UCase$(R12_ProfilValeur( _
        profil, _
        "IDENTITE", _
        "DESTINATION_MODE", _
        "BASE"))

    If modeDestination = "A_COMPLETER" Then
        cleDestination = "A_COMPLETER"
    Else
        recordDestination = DestinationParDefautPourTypeExamen(typeBase)
        cleDestination = UCase$(Trim$(ChampDestination(recordDestination, 10)))
        If cleDestination = "" Then cleDestination = "A_COMPLETER"
    End If

    If nature = "CONSULTATION" Or nature = "HOSPITALISATION" Then
        If Not R12_ContientMedecinNomme(phraseSource) Then
            cleDestination = "A_COMPLETER"
        End If
    End If

    intitule = R12_ProfilValeur( _
        profil, _
        "IDENTITE", _
        "LIBELLE", _
        Trim$(expressionTrouvee))

    If profilCode = R12_PROFIL_SECOURS Then
        intitule = Trim$(expressionTrouvee)
    End If

    d.Add "IDDemande", ""
    d.Add "TypesExamens", UCase$(typeExamen)
    d.Add "ProfilCode", profilCode
    d.Add "Intitules", intitule
    d.Add "Nature", nature
    d.Add "PhraseSource", Trim$(phraseSource)
    d.Add "MotifLocal", R12_ExtraireMotifLocal(phraseSource, typeExamen)
    d.Add "CleDestination", cleDestination

    Set R12_CreerDemandeElementaire = d

End Function

Private Function R12_CleGroupe(ByVal demande As Object) As String

    Dim cle As String
    Dim nature As String
    Dim profilCode As String
    Dim modeRegroupement As String
    Dim profil As Object

    cle = UCase$(Trim$(CStr(demande("CleDestination"))))
    nature = UCase$(CStr(demande("Nature")))
    profilCode = UCase$(Trim$(CStr(demande("ProfilCode"))))
    Set profil = R12_ChargerProfil(profilCode)

    modeRegroupement = UCase$(R12_ProfilValeur( _
        profil, _
        "IDENTITE", _
        "REGROUPEMENT", _
        "MEME_PROFIL"))

    If cle = "" Or cle = "A_COMPLETER" Or _
       modeRegroupement = "JAMAIS" Then

        R12_CleGroupe = _
            "UNIQUE|" & profilCode & "|" & _
            R12_Normaliser(CStr(demande("PhraseSource"))) & "|" & nature

    ElseIf modeRegroupement = "MEME_DESTINATION" Then

        R12_CleGroupe = cle & "|" & nature

    Else

        R12_CleGroupe = cle & "|" & profilCode & "|" & nature

    End If

End Function

Private Sub R12_FusionnerDemande( _
    ByVal cible As Object, _
    ByVal ajout As Object)

    If InStr(1, _
             R12_SEP_LISTE & CStr(cible("TypesExamens")) & R12_SEP_LISTE, _
             R12_SEP_LISTE & CStr(ajout("TypesExamens")) & R12_SEP_LISTE, _
             vbTextCompare) = 0 Then

        cible("TypesExamens") = _
            CStr(cible("TypesExamens")) & R12_SEP_LISTE & _
            CStr(ajout("TypesExamens"))

        cible("Intitules") = _
            CStr(cible("Intitules")) & R12_SEP_LISTE & _
            CStr(ajout("Intitules"))
    End If

    If InStr(1, _
             CStr(cible("PhraseSource")), _
             CStr(ajout("PhraseSource")), _
             vbTextCompare) = 0 Then

        cible("PhraseSource") = _
            CStr(cible("PhraseSource")) & vbCr & _
            CStr(ajout("PhraseSource"))
    End If

    If Trim$(CStr(cible("MotifLocal"))) = "" Then
        cible("MotifLocal") = CStr(ajout("MotifLocal"))
    End If

End Sub

'-------------------------------------------------------------------------------
' ASSEMBLAGE LOCAL DE LA LETTRE
'-------------------------------------------------------------------------------

Private Function R12_ConstruireCorpsDemande( _
    ByVal demande As Object, _
    ByVal fiche As Object, _
    ByVal courrier As String, _
    ByRef raisons As String) As String

    Dim corps As String
    Dim motif As String
    Dim anamnese As String
    Dim traitements As String
    Dim clinique As String
    Dim ecg As String
    Dim echoTexte As String
    Dim holter As String
    Dim biologie As String
    Dim autres As String
    Dim question As String

    If fiche Is Nothing Then
        raisons = R12_AjouterRaison(raisons, "fiche API absente")
    End If

    motif = R12_ValeurFiche(fiche, "MOTIF")
    motif = R12_ValiderRubrique(motif, "motif", raisons)

    If motif = "" Then motif = Trim$(CStr(demande("MotifLocal")))
    If motif = "" Then motif = R12_MotifParDefaut(demande)

    anamnese = R12_ValeurFiche(fiche, "ANAMNESE")
    anamnese = R12_ValiderRubrique(anamnese, "anamnese", raisons)

    If anamnese = "" Then
        anamnese = R12_ExtraireAnamneseLocale(courrier)
        anamnese = R12_ValiderRubrique(anamnese, "anamnese locale", raisons)
    End If

    If anamnese = "" Then
        raisons = R12_AjouterRaison(raisons, "contexte anamnestique a completer")
    End If

    traitements = R12_ValeurFiche(fiche, "TRAITEMENTS")
    traitements = R12_ValiderRubrique(traitements, "traitements", raisons)

    clinique = R12_ValeurFiche(fiche, "EXAMEN_CLINIQUE")
    clinique = R12_ValiderRubrique(clinique, "examen clinique", raisons)

    If R12_SourceContientClinique(courrier) And clinique = "" Then
        clinique = R12_ExtraireCliniqueLocale(courrier)
        clinique = R12_ValiderRubrique(clinique, "examen clinique local", raisons)
        If clinique = "" Then
            raisons = R12_AjouterRaison(raisons, "examen clinique manquant")
        End If
    End If

    ecg = R12_ValeurFiche(fiche, "ECG")
    ecg = R12_ValiderRubrique(ecg, "ECG", raisons)

    If R12_SourceContientECG(courrier) And ecg = "" Then
        ecg = R12_ExtraireECGLocal(courrier)
        ecg = R12_ValiderRubrique(ecg, "ECG local", raisons)
        If ecg = "" Then
            raisons = R12_AjouterRaison(raisons, "electrocardiogramme manquant")
        End If
    End If

    echoTexte = R12_ValiderRubrique( _
        R12_ValeurFiche(fiche, "ECHOGRAPHIE"), _
        "echographie", _
        raisons)

    holter = R12_ValiderRubrique( _
        R12_ValeurFiche(fiche, "HOLTER"), _
        "Holter", _
        raisons)

    biologie = R12_ValiderRubrique( _
        R12_ValeurFiche(fiche, "BIOLOGIE"), _
        "biologie", _
        raisons)

    autres = R12_ValiderRubrique( _
        R12_ValeurFiche(fiche, "AUTRES_EXAMENS"), _
        "autres examens", _
        raisons)

    question = R12_ValiderRubrique( _
        R12_ValeurFiche(fiche, "QUESTION"), _
        "question medicale", _
        raisons)

    corps = R12_ConstruirePremierParagrapheAvecMotif(demande, motif)

    R12_AjouterTexte corps, anamnese
    R12_AjouterTexte corps, traitements
    R12_AjouterTexte corps, R12_AvecTitre("Examen clinique", clinique)
    R12_AjouterTexte corps, R12_AvecTitre("�lectrocardiogramme", ecg)
    R12_AjouterTexte corps, R12_AvecTitre("�chographie cardiaque", echoTexte)
    R12_AjouterTexte corps, R12_AvecTitre("Holter rythmique", holter)
    R12_AjouterTexte corps, R12_AvecTitre("Bilan biologique", biologie)
    R12_AjouterTexte corps, R12_AvecTitre("Autres examens", autres)
    R12_AjouterTexte corps, R12_FormulerQuestion(demande, question)

    R12_ConstruireCorpsDemande = R12_NormaliserParagraphes(corps)

End Function

Private Function R12_ConstruirePremierParagraphe( _
    ByVal demande As Object) As String

    R12_ConstruirePremierParagraphe = _
        R12_ConstruirePremierParagrapheAvecMotif( _
            demande, _
            R12_MotifParDefaut(demande))

End Function

Private Function R12_ConstruirePremierParagrapheAvecMotif( _
    ByVal demande As Object, _
    ByVal motif As String) As String

    Dim identite As String
    Dim ageTexte As String
    Dim phrase As String
    Dim examens As String

    identite = Trim$(gPatient.civilite)
    If identite = "" Then identite = "Monsieur/Madame"
    identite = identite & " " & MARQUEUR_PATIENT

    ageTexte = ""
    If Trim$(gPatient.Age) <> "" Then
        ageTexte = ", " & Trim$(gPatient.Age) & " ans"
    Else
        ageTexte = R12_ExtraireAgeTexte(mTexteSourcePlan)
    End If

    motif = R12_NettoyerMotif(motif)

    If UCase$(CStr(demande("Nature"))) = "CONSULTATION" Then

        examens = R12_ListeLisible(CStr(demande("Intitules")), False)
        phrase = "Merci de prendre en charge " & identite & ageTexte & _
            ", pour " & examens

        If motif <> "" Then
            If InStr(1, R12_Normaliser(motif), R12_Normaliser(examens), vbTextCompare) = 0 Then
                phrase = phrase & R12_AccrocherMotif(motif, False)
            End If
        End If

    Else

        examens = R12_ListeLisible(CStr(demande("Intitules")), True)
        phrase = "Merci de r�aliser " & examens & " � " & identite & ageTexte
        phrase = phrase & R12_AccrocherMotif(motif, False)

    End If

    phrase = Trim$(phrase)
    If Right$(phrase, 1) <> "." Then phrase = phrase & "."

    R12_ConstruirePremierParagrapheAvecMotif = phrase

End Function

Private Function R12_AccrocherMotif( _
    ByVal motif As String, _
    ByVal consultation As Boolean) As String

    Dim t As String

    motif = Trim$(motif)
    If motif = "" Then Exit Function

    t = LCase$(motif)

    If Left$(t, 5) = "pour " Or _
       Left$(t, 7) = "devant " Or _
       Left$(t, 15) = "dans le cadre de" Or _
       Left$(t, 12) = "en raison de" Or _
       Left$(t, 14) = "compte tenu de" Or _
       Left$(t, 8) = "afin de " Or _
       Left$(t, 8) = "en vue d" Then

        R12_AccrocherMotif = ", " & motif

    ElseIf consultation Then
        R12_AccrocherMotif = ", pour " & motif
    Else
        R12_AccrocherMotif = ", dans le contexte de " & motif
    End If

End Function

Private Function R12_AvecTitre( _
    ByVal titre As String, _
    ByVal texte As String) As String

    Dim t As String
    Dim p As Long

    texte = Trim$(texte)
    If texte = "" Then Exit Function

    t = R12_Normaliser(texte)

    If InStr(1, t, R12_Normaliser(titre), vbTextCompare) = 1 Then
        p = InStr(1, texte, ":", vbBinaryCompare)
        If p > 0 Then texte = Trim$(Mid$(texte, p + 1))
    End If

    If texte = "" Then Exit Function

    R12_AvecTitre = titre & " : " & texte

End Function

Private Function R12_FormulerQuestion( _
    ByVal demande As Object, _
    ByVal question As String) As String

    Dim q As String

    question = Trim$(question)
    If question = "" Then Exit Function

    q = LCase$(question)

    If Left$(q, 12) = "l'objectif " Or _
       Left$(q, 11) = "cet examen " Or _
       Left$(q, 13) = "cette demande" Or _
       Left$(q, 16) = "la prise en charge" Then

        R12_FormulerQuestion = question
        Exit Function
    End If

    question = R12_MinusculeInitiale(question)

    If UCase$(CStr(demande("Nature"))) = "CONSULTATION" Then
        R12_FormulerQuestion = _
            "La prise en charge demandee vise a " & question
    Else
        R12_FormulerQuestion = _
            "L'objectif de cette demande est de " & question
    End If

    If Right$(R12_FormulerQuestion, 1) <> "." Then
        R12_FormulerQuestion = R12_FormulerQuestion & "."
    End If

End Function

Private Sub R12_AjouterTexte( _
    ByRef corps As String, _
    ByVal texte As String)

    texte = R12_NormaliserParagraphes(texte)
    If Trim$(texte) = "" Then Exit Sub

    If Trim$(corps) <> "" Then corps = corps & vbCr & vbCr
    corps = corps & texte

End Sub

'-------------------------------------------------------------------------------
' EXTRACTION ET VALIDATION DES FICHES API
'-------------------------------------------------------------------------------

Private Function R12_ExtraireFiches( _
    ByVal reponse As String) As Object

    Dim resultat As Object
    Dim position As Long
    Dim p1 As Long
    Dim p2 As Long
    Dim bloc As String
    Dim idDemande As String
    Dim fiche As Object

    Set resultat = CreateObject("Scripting.Dictionary")
    position = 1

    Do
        p1 = InStr(position, reponse, R12_DEBUT_FICHE, vbTextCompare)
        If p1 = 0 Then Exit Do

        p2 = InStr(p1 + Len(R12_DEBUT_FICHE), reponse, R12_FIN_FICHE, vbTextCompare)
        If p2 = 0 Then Exit Do

        bloc = Mid$(reponse, p1, p2 - p1 + Len(R12_FIN_FICHE))
        idDemande = UCase$(Trim$(R12_LireLigneApresPrefixe(bloc, R12_PREFIXE_ID)))

        If idDemande <> "" Then
            Set fiche = CreateObject("Scripting.Dictionary")
            fiche.Add "MOTIF", R12_ExtraireSection(bloc, R12_DEBUT_MOTIF, R12_FIN_MOTIF)
            fiche.Add "ANAMNESE", R12_ExtraireSection(bloc, R12_DEBUT_ANAMNESE, R12_FIN_ANAMNESE)
            fiche.Add "TRAITEMENTS", R12_ExtraireSection(bloc, R12_DEBUT_TRAITEMENTS, R12_FIN_TRAITEMENTS)
            fiche.Add "EXAMEN_CLINIQUE", R12_ExtraireSection(bloc, R12_DEBUT_CLINIQUE, R12_FIN_CLINIQUE)
            fiche.Add "ECG", R12_ExtraireSection(bloc, R12_DEBUT_ECG, R12_FIN_ECG)
            fiche.Add "ECHOGRAPHIE", R12_ExtraireSection(bloc, R12_DEBUT_ECHO, R12_FIN_ECHO)
            fiche.Add "HOLTER", R12_ExtraireSection(bloc, R12_DEBUT_HOLTER, R12_FIN_HOLTER)
            fiche.Add "BIOLOGIE", R12_ExtraireSection(bloc, R12_DEBUT_BIOLOGIE, R12_FIN_BIOLOGIE)
            fiche.Add "AUTRES_EXAMENS", R12_ExtraireSection(bloc, R12_DEBUT_AUTRES, R12_FIN_AUTRES)
            fiche.Add "QUESTION", R12_ExtraireSection(bloc, R12_DEBUT_QUESTION, R12_FIN_QUESTION)

            If resultat.Exists(idDemande) Then resultat.Remove idDemande
            resultat.Add idDemande, fiche
        End If

        position = p2 + Len(R12_FIN_FICHE)
    Loop

    Set R12_ExtraireFiches = resultat

End Function

Private Function R12_ValeurFiche( _
    ByVal fiche As Object, _
    ByVal cle As String) As String

    If fiche Is Nothing Then Exit Function
    If Not fiche.Exists(cle) Then Exit Function

    R12_ValeurFiche = R12_NettoyerValeur(CStr(fiche(cle)))

End Function

Private Function R12_ValiderRubrique( _
    ByVal texte As String, _
    ByVal nomRubrique As String, _
    ByRef raisons As String) As String

    texte = R12_NettoyerValeur(texte)
    If texte = "" Then Exit Function

    If R12_ContientAdresseDirecte(texte) Then
        raisons = R12_AjouterRaison( _
            raisons, _
            nomRubrique & " formule avec un interlocuteur direct")
        Exit Function
    End If

    R12_ValiderRubrique = texte

End Function

Private Function R12_ContientAdresseDirecte( _
    ByVal texte As String) As Boolean

    Dim t As String
    Dim mots As Variant
    Dim mot As Variant
    Dim interdits As Object

    t = R12_Normaliser(texte)
    t = Replace(t, "'", " ")
    t = Replace(t, "-", " ")
    t = Replace(t, ".", " ")
    t = Replace(t, ",", " ")
    t = Replace(t, ";", " ")
    t = Replace(t, ":", " ")
    t = Replace(t, "!", " ")
    t = Replace(t, "?", " ")
    t = Replace(t, "(", " ")
    t = Replace(t, ")", " ")

    Do While InStr(t, "  ") > 0
        t = Replace(t, "  ", " ")
    Loop

    Set interdits = CreateObject("Scripting.Dictionary")

    For Each mot In Array( _
        "je", "j", "nous", "notre", "nos", _
        "vous", "votre", "vos", "tu", "te", "toi", _
        "me", "m", "moi", "mon", "ma", "mes")

        interdits(CStr(mot)) = True
    Next mot

    mots = Split(Trim$(t), " ")

    For Each mot In mots
        If interdits.Exists(CStr(mot)) Then
            R12_ContientAdresseDirecte = True
            Exit Function
        End If
    Next mot

End Function

Private Function R12_NettoyerValeur( _
    ByVal texte As String) As String

    Dim t As String

    texte = Replace(texte, "**", "")
    texte = R12_NormaliserParagraphes(texte)
    t = UCase$(Trim$(texte))

    If t = "ABSENT" Or t = "NEANT" Or t = "N/A" Or t = "NA" Then
        R12_NettoyerValeur = ""
    Else
        R12_NettoyerValeur = Trim$(texte)
    End If

End Function

Private Function R12_LireLigneApresPrefixe( _
    ByVal texte As String, _
    ByVal prefixe As String) As String

    Dim p As Long
    Dim debutValeur As Long
    Dim finCR As Long
    Dim finLF As Long
    Dim finLigne As Long

    p = InStr(1, texte, prefixe, vbTextCompare)
    If p = 0 Then Exit Function

    debutValeur = p + Len(prefixe)
    finCR = InStr(debutValeur, texte, vbCr, vbBinaryCompare)
    finLF = InStr(debutValeur, texte, vbLf, vbBinaryCompare)

    If finCR > 0 And finLF > 0 Then
        If finCR < finLF Then finLigne = finCR Else finLigne = finLF
    ElseIf finCR > 0 Then
        finLigne = finCR
    ElseIf finLF > 0 Then
        finLigne = finLF
    Else
        finLigne = Len(texte) + 1
    End If

    R12_LireLigneApresPrefixe = _
        Trim$(Mid$(texte, debutValeur, finLigne - debutValeur))

End Function

Private Function R12_ExtraireSection( _
    ByVal texte As String, _
    ByVal baliseDebut As String, _
    ByVal baliseFin As String) As String

    Dim p1 As Long
    Dim p2 As Long

    p1 = InStr(1, texte, baliseDebut, vbTextCompare)
    If p1 = 0 Then Exit Function

    p1 = p1 + Len(baliseDebut)
    p2 = InStr(p1, texte, baliseFin, vbTextCompare)
    If p2 = 0 Then Exit Function

    R12_ExtraireSection = Trim$(Mid$(texte, p1, p2 - p1))

End Function

'-------------------------------------------------------------------------------
' EXTRACTIONS LOCALES DE SECOURS
'-------------------------------------------------------------------------------

Private Function R12_SourceContientClinique(ByVal texte As String) As Boolean

    Dim paragraphes As Variant
    Dim p As Variant

    paragraphes = R12_Paragraphes(texte)

    For Each p In paragraphes
        If R12_ParagrapheClinique(CStr(p)) Then
            R12_SourceContientClinique = True
            Exit Function
        End If
    Next p

End Function

Private Function R12_SourceContientECG(ByVal texte As String) As Boolean

    Dim paragraphes As Variant
    Dim p As Variant

    paragraphes = R12_Paragraphes(texte)

    For Each p In paragraphes
        If R12_ParagrapheECG(CStr(p)) Then
            R12_SourceContientECG = True
            Exit Function
        End If
    Next p

End Function

Private Function R12_ExtraireCliniqueLocale(ByVal texte As String) As String

    Dim paragraphes As Variant
    Dim p As Variant
    Dim resultat As String

    paragraphes = R12_Paragraphes(texte)

    For Each p In paragraphes
        If R12_ParagrapheClinique(CStr(p)) Then
            resultat = R12_NeutraliserClinique(CStr(p))
            If resultat <> "" Then
                R12_ExtraireCliniqueLocale = resultat
                Exit Function
            End If
        End If
    Next p

End Function

Private Function R12_ExtraireECGLocal(ByVal texte As String) As String

    Dim paragraphes As Variant
    Dim p As Variant
    Dim resultat As String

    paragraphes = R12_Paragraphes(texte)

    For Each p In paragraphes
        If R12_ParagrapheECG(CStr(p)) Then
            resultat = R12_NeutraliserECG(CStr(p))
            If resultat <> "" Then
                R12_ExtraireECGLocal = resultat
                Exit Function
            End If
        End If
    Next p

End Function

Private Function R12_ExtraireAnamneseLocale(ByVal texte As String) As String

    Dim paragraphes As Variant
    Dim p As Variant
    Dim paragraphe As String
    Dim t As String
    Dim resultat As String
    Dim compteur As Long

    paragraphes = R12_Paragraphes(texte)

    For Each p In paragraphes

        paragraphe = Trim$(CStr(p))
        t = R12_Normaliser(paragraphe)

        If paragraphe <> "" And _
           Not R12_ParagrapheClinique(paragraphe) And _
           Not R12_ParagrapheECG(paragraphe) And _
           Not R12_ParagrapheTechniqueOuRelationnel(t) Then

            paragraphe = R12_NeutraliserIntroductionPatient(paragraphe)

            If paragraphe <> "" And _
               Not R12_ContientAdresseDirecte(paragraphe) Then

                If resultat <> "" Then resultat = resultat & vbCr & vbCr
                resultat = resultat & paragraphe
                compteur = compteur + 1

                If compteur >= 3 Then Exit For
            End If

        End If

    Next p

    R12_ExtraireAnamneseLocale = resultat

End Function

Private Function R12_ParagrapheClinique( _
    ByVal paragraphe As String) As Boolean

    Dim t As String

    t = R12_Normaliser(paragraphe)

    R12_ParagrapheClinique = _
        InStr(1, t, "examen clinique", vbTextCompare) > 0 Or _
        InStr(1, t, "pression arterielle", vbTextCompare) > 0 Or _
        InStr(1, t, "tension arterielle", vbTextCompare) > 0 Or _
        InStr(1, t, "bruits du coeur", vbTextCompare) > 0 Or _
        InStr(1, t, "auscultation pulmonaire", vbTextCompare) > 0 Or _
        InStr(1, t, "sans souffle", vbTextCompare) > 0 Or _
        InStr(1, t, "signe peripherique", vbTextCompare) > 0 Or _
        InStr(1, t, "examen vasculaire", vbTextCompare) > 0

End Function

Private Function R12_ParagrapheECG( _
    ByVal paragraphe As String) As Boolean

    Dim t As String

    t = " " & R12_Normaliser(paragraphe) & " "

    R12_ParagrapheECG = _
        InStr(1, t, " electrocardiogramme ", vbTextCompare) > 0 Or _
        InStr(1, t, " ecg ", vbTextCompare) > 0 Or _
        InStr(1, t, " trace ecg ", vbTextCompare) > 0

End Function

Private Function R12_ParagrapheTechniqueOuRelationnel( _
    ByVal t As String) As Boolean

    R12_ParagrapheTechniqueOuRelationnel = _
        InStr(1, t, "echographie", vbTextCompare) > 0 Or _
        InStr(1, t, "holter", vbTextCompare) > 0 Or _
        InStr(1, t, "biologie", vbTextCompare) > 0 Or _
        InStr(1, t, "bilan biologique", vbTextCompare) > 0 Or _
        InStr(1, t, "au total", vbTextCompare) > 0 Or _
        InStr(1, t, "merci de", vbTextCompare) > 0 Or _
        InStr(1, t, "je lui demande", vbTextCompare) > 0 Or _
        InStr(1, t, "je demande", vbTextCompare) > 0 Or _
        InStr(1, t, "je propose", vbTextCompare) > 0 Or _
        InStr(1, t, "je programme", vbTextCompare) > 0 Or _
        InStr(1, t, "confiance", vbTextCompare) > 0 Or _
        InStr(1, t, "amit", vbTextCompare) > 0 Or _
        InStr(1, t, "tiendrai informe", vbTextCompare) > 0

End Function

Private Function R12_NeutraliserClinique(ByVal texte As String) As String

    texte = Trim$(texte)
    texte = R12_RetirerPrefixe(texte, "Examen clinique :")
    texte = R12_RetirerPrefixe(texte, "L'examen clinique retrouve")
    texte = R12_RetirerPrefixe(texte, "Je retrouve")
    texte = Replace(texte, "je retrouve", "", 1, 1, vbTextCompare)
    texte = Replace(texte, "je note", "", 1, 1, vbTextCompare)
    texte = Trim$(texte)

    If Len(texte) > 0 Then
        texte = R12_MajusculeInitiale(texte)
    End If

    R12_NeutraliserClinique = texte

End Function

Private Function R12_NeutraliserECG(ByVal texte As String) As String

    texte = Trim$(texte)
    texte = R12_RetirerPrefixe(texte, "Electrocardiogramme :")
    texte = R12_RetirerPrefixe(texte, "L'electrocardiogramme")
    texte = R12_RetirerPrefixe(texte, "ECG :")
    texte = Replace(texte, "je retrouve", "", 1, 1, vbTextCompare)
    texte = Trim$(texte)

    If Len(texte) > 0 Then
        texte = R12_MajusculeInitiale(texte)
    End If

    R12_NeutraliserECG = texte

End Function

Private Function R12_NeutraliserIntroductionPatient( _
    ByVal texte As String) As String

    Dim t As String
    Dim p As Long

    texte = Trim$(texte)
    t = R12_Normaliser(texte)

    If Left$(t, 9) = "je revois " Or _
       Left$(t, 8) = "je vois " Or _
       Left$(t, 18) = "je vois pour la prem" Then

        p = InStr(1, t, " ans,", vbTextCompare)

        If p > 0 Then
            p = InStr(p, texte, ",", vbBinaryCompare)
            If p > 0 Then texte = Trim$(Mid$(texte, p + 1))
        Else
            texte = ""
        End If
    End If

    If Len(texte) > 0 Then texte = R12_MajusculeInitiale(texte)
    R12_NeutraliserIntroductionPatient = texte

End Function

'-------------------------------------------------------------------------------
' TYPES, LIBELLES, DESTINATIONS ET MOTIFS
'-------------------------------------------------------------------------------

Private Function R12_NatureDemande(ByVal typeExamen As String) As String

    If Left$(UCase$(typeExamen), 5) = "AVIS_" Then
        R12_NatureDemande = "CONSULTATION"
    Else
        R12_NatureDemande = "EXAMEN"
    End If

End Function

Private Function R12_TypePourBase(ByVal typeExamen As String) As String

    Select Case UCase$(typeExamen)
        Case "ECHODOPPLER_TSA"
            R12_TypePourBase = "ECHODOPPLER_VAISSEAUX_DU_COU"
        Case "ECHODOPPLER_MI"
            R12_TypePourBase = "ECHODOPPLER_MEMBRES_INFERIEURS"
        Case "IRM_STRESS"
            R12_TypePourBase = "IRM"
        Case Else
            R12_TypePourBase = UCase$(typeExamen)
    End Select

End Function

Private Function R12_LibelleType( _
    ByVal typeExamen As String, _
    ByVal expressionTrouvee As String, _
    ByVal phraseSource As String) As String

    Dim t As String

    t = R12_Normaliser(phraseSource)

    Select Case UCase$(typeExamen)
        Case "TEST_EFFORT": R12_LibelleType = "test d'effort"
        Case "SCINTIGRAPHIE_MYOCARDIQUE": R12_LibelleType = "scintigraphie myocardique"
        Case "SCORE_CALCIQUE": R12_LibelleType = "score calcique"
        Case "COROSCANNER": R12_LibelleType = "coroscanner"
        Case "SCANNER_THORACIQUE"
            If InStr(1, t, "sans injection", vbTextCompare) > 0 Then
                R12_LibelleType = "scanner thoracique sans injection"
            Else
                R12_LibelleType = "scanner thoracique"
            End If
        Case "SCANNER": R12_LibelleType = "scanner"
        Case "ANGIOSCANNER": R12_LibelleType = "angioscanner"
        Case "IRM_STRESS": R12_LibelleType = "IRM de stress"
        Case "IRM": R12_LibelleType = "IRM"
        Case "CORONAROGRAPHIE": R12_LibelleType = "coronarographie"
        Case "ECHODOPPLER_VEINEUX": R12_LibelleType = "�cho-Doppler veineux"
        Case "ECHODOPPLER_ARTERIEL": R12_LibelleType = "�cho-Doppler art�riel"
        Case "ECHODOPPLER_TSA": R12_LibelleType = "�cho-Doppler des troncs supra-aortiques"
        Case "ECHODOPPLER_MI": R12_LibelleType = "�cho-Doppler des membres inf�rieurs"
        Case "AVIS_NEUROLOGIE": R12_LibelleType = "avis neurologique"
        Case "AVIS_GASTROENTEROLOGIE": R12_LibelleType = "avis gastro-ent�rologique"
        Case "AVIS_PNEUMOLOGIE": R12_LibelleType = "avis pneumologique"
        Case "AVIS_NEPHROLOGIE": R12_LibelleType = "avis n�phrologique"
        Case "AVIS_HEMATOLOGIE": R12_LibelleType = "avis h�matologique"
        Case "AVIS_VASCULAIRE": R12_LibelleType = "avis vasculaire"
        Case "AVIS_RYTHMOLOGIE": R12_LibelleType = "prise en charge rythmologique"
        Case "AVIS_SPECIALISE": R12_LibelleType = "avis sp�cialis�"
        Case Else
            R12_LibelleType = Trim$(expressionTrouvee)
    End Select

End Function

Private Function R12_ExtraireMotifLocal( _
    ByVal phrase As String, _
    ByVal typeExamen As String) As String

    Dim marqueurs As Variant
    Dim marqueur As Variant
    Dim position As Long
    Dim meilleurPosition As Long
    Dim t As String

    t = Trim$(phrase)
    meilleurPosition = 0

    marqueurs = Array( _
        "afin de", "en raison de", "compte tenu de", _
        "d'autant que", "d'autant qu'", "car", "du fait de", _
        "dans le cadre de", "devant", "pour rechercher", _
        "pour exclure", "pour evaluer", "pour apprecier", _
        "pour controler", "en vue d'une ablation", "pour une ablation")

    For Each marqueur In marqueurs
        position = InStr(1, R12_Normaliser(t), CStr(marqueur), vbTextCompare)
        If position > 0 Then
            If meilleurPosition = 0 Or position < meilleurPosition Then
                meilleurPosition = position
            End If
        End If
    Next marqueur

    If meilleurPosition > 0 Then
        R12_ExtraireMotifLocal = Trim$(Mid$(t, meilleurPosition))
        Exit Function
    End If

    If InStr(1, R12_Normaliser(t), "terrain a risque", vbTextCompare) > 0 Then
        R12_ExtraireMotifLocal = "dans le cadre de ce terrain a risque"
    End If

End Function

Private Function R12_MotifParDefaut(ByVal demande As Object) As String

    If UCase$(CStr(demande("Nature"))) = "CONSULTATION" Then
        R12_MotifParDefaut = _
            "pour " & R12_ListeLisible(CStr(demande("Intitules")), False) & _
            " dans le contexte expose ci-dessous"
    Else
        R12_MotifParDefaut = "dans le contexte expose ci-dessous"
    End If

End Function

Private Function R12_DemandeRythmologiqueExplicite( _
    ByVal unite As String) As Boolean

    Dim t As String
    Dim cible As Boolean
    Dim intention As Boolean

    t = R12_Normaliser(unite)

    cible = _
        InStr(1, t, "ablation", vbTextCompare) > 0 Or _
        InStr(1, t, "rythmolog", vbTextCompare) > 0 Or _
        InStr(1, t, "exploration electrophysiologique", vbTextCompare) > 0 Or _
        InStr(1, t, "ccn", vbTextCompare) > 0

    intention = DDE_ContientDeclencheur(unite)

    R12_DemandeRythmologiqueExplicite = _
        cible And intention And Not DDE_ContientExclusion(unite)

End Function

Private Function R12_ContientMedecinNomme(ByVal texte As String) As Boolean

    Dim regex As Object
    Dim t As String

    t = R12_Normaliser(texte)
    Set regex = CreateObject("VBScript.RegExp")

    With regex
        .Global = False
        .IgnoreCase = True
        .Pattern = "(docteur|dr[.]?|professeur|pr[.]?)[ ]+[a-z'-]{2,}"
    End With

    R12_ContientMedecinNomme = regex.Test(t)

End Function

Private Function R12_ListeLisible( _
    ByVal intitules As String, _
    ByVal avecArticle As Boolean) As String

    Dim elements As Variant
    Dim i As Long
    Dim element As String
    Dim resultat As String

    elements = Split(intitules, R12_SEP_LISTE)

    For i = LBound(elements) To UBound(elements)

        element = Trim$(CStr(elements(i)))
        If avecArticle Then element = R12_AvecArticle(element)

        If i > LBound(elements) Then
            If i = UBound(elements) Then
                resultat = resultat & " et "
            Else
                resultat = resultat & ", "
            End If
        End If

        resultat = resultat & element
    Next i

    R12_ListeLisible = resultat

End Function

Private Function R12_AvecArticle(ByVal intitule As String) As String

    Dim t As String

    intitule = Trim$(intitule)
    t = LCase$(intitule)

    If Left$(t, 3) = "un " Or _
       Left$(t, 4) = "une " Or _
       Left$(t, 4) = "des " Or _
       Left$(t, 2) = "l'" Or _
       Left$(t, 3) = "la " Or _
       Left$(t, 3) = "le " Then

        R12_AvecArticle = intitule
        Exit Function
    End If

    If InStr(1, t, "scintigraphie", vbTextCompare) > 0 Or _
       Left$(t, 3) = "irm" Or _
       InStr(1, t, "coronarographie", vbTextCompare) > 0 Then

        R12_AvecArticle = "une " & intitule
    Else
        R12_AvecArticle = "un " & intitule
    End If

End Function

'-------------------------------------------------------------------------------
' OUTILS GENERAUX
'-------------------------------------------------------------------------------

Private Function R12_DecouperUnites(ByVal texte As String) As Collection

    Dim resultat As Collection
    Dim courant As String
    Dim c As String
    Dim precedent As String
    Dim suivant As String
    Dim i As Long

    Set resultat = New Collection
    texte = Replace(texte, Chr(11), vbCr)
    texte = Replace(texte, Chr(12), vbCr)

    For i = 1 To Len(texte)

        c = Mid$(texte, i, 1)
        precedent = ""
        suivant = ""

        If i > 1 Then precedent = Mid$(texte, i - 1, 1)
        If i < Len(texte) Then suivant = Mid$(texte, i + 1, 1)

        courant = courant & c

        If c = vbCr Or c = vbLf Or c = "!" Or c = "?" Then
            R12_AjouterUnite resultat, courant
            courant = ""
        ElseIf c = "." Then
            If Not (R12_EstChiffre(precedent) And R12_EstChiffre(suivant)) Then
                R12_AjouterUnite resultat, courant
                courant = ""
            End If
        End If

    Next i

    R12_AjouterUnite resultat, courant
    Set R12_DecouperUnites = resultat

End Function

Private Sub R12_AjouterUnite( _
    ByVal c As Collection, _
    ByVal texte As String)

    texte = R12_NettoyerUnite(texte)
    If texte <> "" Then c.Add texte

End Sub

Private Function R12_NettoyerUnite(ByVal texte As String) As String

    texte = Replace(texte, vbCr, " ")
    texte = Replace(texte, vbLf, " ")
    texte = Replace(texte, Chr(160), " ")

    Do While InStr(texte, "  ") > 0
        texte = Replace(texte, "  ", " ")
    Loop

    R12_NettoyerUnite = Trim$(texte)

End Function

Private Function R12_LireLignesFichier(ByVal chemin As String) As Variant

    Dim numero As Integer
    Dim contenu As String

    If Dir$(chemin) = "" Then
        R12_LireLignesFichier = Array()
        Exit Function
    End If

    numero = FreeFile
    Open chemin For Binary Access Read As #numero
    If LOF(numero) > 0 Then
        contenu = Space$(LOF(numero))
        Get #numero, , contenu
    End If
    Close #numero

    contenu = Replace(contenu, vbCrLf, vbLf)
    contenu = Replace(contenu, vbCr, vbLf)
    R12_LireLignesFichier = Split(contenu, vbLf)

End Function

Private Function R12_Paragraphes(ByVal texte As String) As Variant

    texte = Replace(texte, vbCrLf, vbCr)
    texte = Replace(texte, vbLf, vbCr)
    R12_Paragraphes = Split(texte, vbCr)

End Function

Private Function R12_Normaliser(ByVal texte As String) As String

    texte = LCase$(texte)
    texte = Replace(texte, "�", "'")
    texte = Replace(texte, "�", "oe")
    texte = Replace(texte, "�", "e")
    texte = Replace(texte, "�", "e")
    texte = Replace(texte, "�", "e")
    texte = Replace(texte, "�", "e")
    texte = Replace(texte, "�", "a")
    texte = Replace(texte, "�", "a")
    texte = Replace(texte, "�", "a")
    texte = Replace(texte, "�", "i")
    texte = Replace(texte, "�", "i")
    texte = Replace(texte, "�", "o")
    texte = Replace(texte, "�", "o")
    texte = Replace(texte, "�", "u")
    texte = Replace(texte, "�", "u")
    texte = Replace(texte, "�", "u")
    texte = Replace(texte, "�", "c")
    texte = Replace(texte, Chr(160), " ")
    texte = Replace(texte, vbTab, " ")
    texte = Replace(texte, vbCr, " ")
    texte = Replace(texte, vbLf, " ")

    Do While InStr(texte, "  ") > 0
        texte = Replace(texte, "  ", " ")
    Loop

    R12_Normaliser = Trim$(texte)

End Function

Private Function R12_NormaliserParagraphes(ByVal texte As String) As String

    texte = Replace(texte, vbCrLf, vbCr)
    texte = Replace(texte, vbLf, vbCr)

    Do While InStr(texte, vbCr & vbCr & vbCr) > 0
        texte = Replace(texte, vbCr & vbCr & vbCr, vbCr & vbCr)
    Loop

    R12_NormaliserParagraphes = Trim$(texte)

End Function

Private Function R12_Aplatir(ByVal texte As String) As String

    texte = Replace(texte, vbCr, " ")
    texte = Replace(texte, vbLf, " ")

    Do While InStr(texte, "  ") > 0
        texte = Replace(texte, "  ", " ")
    Loop

    R12_Aplatir = Trim$(texte)

End Function

Private Function R12_NettoyerMotif(ByVal motif As String) As String

    motif = Trim$(motif)

    Do While Len(motif) > 0 And _
        (Right$(motif, 1) = "." Or _
         Right$(motif, 1) = ";" Or _
         Right$(motif, 1) = ",")

        motif = Left$(motif, Len(motif) - 1)
    Loop

    R12_NettoyerMotif = Trim$(motif)

End Function

Private Function R12_AjouterRaison( _
    ByVal raisons As String, _
    ByVal nouvelle As String) As String

    If Trim$(nouvelle) = "" Then
        R12_AjouterRaison = raisons
    ElseIf Trim$(raisons) = "" Then
        R12_AjouterRaison = Trim$(nouvelle)
    ElseIf InStr(1, raisons, nouvelle, vbTextCompare) > 0 Then
        R12_AjouterRaison = raisons
    Else
        R12_AjouterRaison = raisons & " ; " & Trim$(nouvelle)
    End If

End Function

Private Function R12_RetirerPrefixe( _
    ByVal texte As String, _
    ByVal prefixe As String) As String

    If InStr(1, texte, prefixe, vbTextCompare) = 1 Then
        texte = Trim$(Mid$(texte, Len(prefixe) + 1))
    End If

    R12_RetirerPrefixe = texte

End Function

Private Function R12_MajusculeInitiale(ByVal texte As String) As String

    If Len(texte) = 0 Then Exit Function
    R12_MajusculeInitiale = UCase$(Left$(texte, 1)) & Mid$(texte, 2)

End Function

Private Function R12_MinusculeInitiale(ByVal texte As String) As String

    If Len(texte) = 0 Then Exit Function
    R12_MinusculeInitiale = LCase$(Left$(texte, 1)) & Mid$(texte, 2)

End Function

Private Function R12_ExtraireAgeTexte(ByVal texte As String) As String

    Dim regex As Object
    Dim matches As Object

    Set regex = CreateObject("VBScript.RegExp")

    With regex
        .Global = False
        .IgnoreCase = True
        .Pattern = "([0-9]{1,3})[ ]*ans"
    End With

    If regex.Test(texte) Then
        Set matches = regex.Execute(texte)
        R12_ExtraireAgeTexte = ", " & matches(0).SubMatches(0) & " ans"
    End If

End Function

Private Function R12_EstChiffre(ByVal c As String) As Boolean
    R12_EstChiffre = (Len(c) = 1 And c >= "0" And c <= "9")
End Function

Private Sub R12_AjouterLigne(ByRef p As String, ByVal ligne As String)
    p = p & ligne & vbCrLf
End Sub

'-------------------------------------------------------------------------------
' TESTS PUBLICS
'-------------------------------------------------------------------------------



Public Function R12_Core_VersionArchitecture() As String
    R12_Core_VersionArchitecture = R12_VERSION_PROFILS & " / " & R12_VERSION_MOTEUR
End Function

Public Sub R12_Core_TesterPlanEtPrompt()

    Dim texte As String
    Dim prompt As String

    texte = _
        "Je complete ce terrain a risque par un test d'effort."

    If Not R12_PreparerPlanDemandes(texte) Then
        MsgBox "ECHEC : plan R12 non construit.", vbExclamation, "R12"
        Exit Sub
    End If

    prompt = R12_ConstruirePromptDeuxiemeAppel( _
        "Madame [[PATIENT]], 70 ans, est asymptomatique. " & _
        "L'examen clinique est normal. " & _
        "L'electrocardiogramme est en rythme sinusal.")

    If InStr(1, prompt, "CODE_PROFIL : TEST_EFFORT", vbTextCompare) > 0 _
    And InStr(1, prompt, "RUBRIQUE EXAMEN_CLINIQUE", vbTextCompare) > 0 _
    And InStr(1, prompt, "RUBRIQUE ECG", vbTextCompare) > 0 Then

        MsgBox _
            "OK R12 : le plan local charge le profil TEST_EFFORT.", _
            vbInformation, _
            "R12"
    Else
        MsgBox _
            "ECHEC R12 : le profil TEST_EFFORT n'est pas present dans le prompt.", _
            vbExclamation, _
            "R12"
    End If

End Sub

Public Sub R12_Core_TesterAssemblageProfil()

    Dim texte As String
    Dim reponse As String
    Dim blocs As String
    Dim message As String
    Dim brouillons As Long

    texte = _
        "Je complete ce terrain a risque par un test d'effort."

    If Not R12_PreparerPlanDemandes(texte) Then
        MsgBox "ECHEC : plan R12 non construit.", vbExclamation, "R12"
        Exit Sub
    End If

    reponse = "---FICHE_PROFIL_R12---" & vbCrLf
    reponse = reponse & "ID_DEMANDE=D001" & vbCrLf
    reponse = reponse & "CODE_PROFIL=TEST_EFFORT" & vbCrLf
    reponse = reponse & "---CHAMP:MOTIF---" & vbCrLf
    reponse = reponse & "dans le cadre de l'evaluation de son terrain a risque" & vbCrLf
    reponse = reponse & "---FIN_CHAMP:MOTIF---" & vbCrLf
    reponse = reponse & "---CHAMP:ANAMNESE---" & vbCrLf
    reponse = reponse & "La patiente ne rapporte aucune douleur thoracique d'effort." & vbCrLf
    reponse = reponse & "---FIN_CHAMP:ANAMNESE---" & vbCrLf
    reponse = reponse & "---CHAMP:TRAITEMENTS---" & vbCrLf
    reponse = reponse & "BISOPROLOL 5 mg." & vbCrLf
    reponse = reponse & "---FIN_CHAMP:TRAITEMENTS---" & vbCrLf
    reponse = reponse & "---CHAMP:EXAMEN_CLINIQUE---" & vbCrLf
    reponse = reponse & "Une pression arterielle a 130/80 mmHg et une auscultation normale." & vbCrLf
    reponse = reponse & "---FIN_CHAMP:EXAMEN_CLINIQUE---" & vbCrLf
    reponse = reponse & "---CHAMP:ECG---" & vbCrLf
    reponse = reponse & "Un rythme sinusal a 65/min avec une repolarisation normale." & vbCrLf
    reponse = reponse & "---FIN_CHAMP:ECG---" & vbCrLf
    reponse = reponse & "---CHAMP:OBJECTIF---" & vbCrLf
    reponse = reponse & "Evaluer la tolerance a l'effort." & vbCrLf
    reponse = reponse & "---FIN_CHAMP:OBJECTIF---" & vbCrLf
    reponse = reponse & "---FIN_FICHE_PROFIL_R12---"

    blocs = R12_ConvertirFichesEnBlocsDemandes( _
        reponse, _
        "Madame [[PATIENT]], 70 ans. " & _
        "L'examen clinique retrouve une pression arterielle a 130/80 mmHg. " & _
        "L'electrocardiogramme est en rythme sinusal a 65/min.", _
        message, _
        brouillons)

    If InStr(1, blocs, "test d'effort", vbTextCompare) > 0 _
    And InStr(1, blocs, vbCr & "L'examen clinique", vbTextCompare) > 0 _
    And InStr(1, blocs, vbCr & "L'�lectrocardiogramme", vbTextCompare) > 0 Then

        MsgBox _
            "OK R12 : le canevas TEST_EFFORT produit des paragraphes distincts.", _
            vbInformation, _
            "R12"
    Else
        MsgBox _
            "ECHEC R12 : assemblage du profil incorrect." & vbCrLf & vbCrLf & _
            Left$(blocs, 1500), _
            vbExclamation, _
            "R12"
    End If

End Sub

Public Sub R12_Core_TesterPlanLocal()

    'Nom historique conserve : le test actif est celui de R11.
    R12_Core_TesterPlanEtPrompt

End Sub

Public Sub R12_Core_TesterConversionStructuree()

    'Nom historique conserve : le test actif est celui de R11.
    R12_Core_TesterAssemblageProfil

End Sub
