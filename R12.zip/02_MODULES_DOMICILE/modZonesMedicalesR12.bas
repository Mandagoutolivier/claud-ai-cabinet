Attribute VB_Name = "modZonesMedicalesR12"
Option Explicit
Option Private Module

'===============================================================================
' R12 - DELIMITATION DES ZONES MEDICALES ET STATUT DU DOCUMENT
'===============================================================================

Private Const R12_PREFIXE_ZONE As String = "MCP_ZONE_MED_"
Private Const R12_VAR_STATUT As String = "MCP_STATUT_R12"
Private Const R12_VAR_DETAIL_STATUT As String = "MCP_DETAIL_STATUT_R12"

Public Sub R12_StockerStatutDocument( _
    ByVal doc As Document, _
    ByVal statut As String, _
    ByVal detail As String)

    If doc Is Nothing Then Exit Sub

    R12_DefinirVariable doc, R12_VAR_STATUT, UCase$(Trim$(statut))
    R12_DefinirVariable doc, R12_VAR_DETAIL_STATUT, Left$(detail, 3000)
End Sub

Public Sub R12_MarquerZonesMedicales(ByVal doc As Document)

    Dim i As Long
    Dim debut As Long
    Dim fin As Long
    Dim compteur As Long
    Dim p As Paragraph
    Dim texte As String
    Dim nom As String
    Dim nomsSupprimer As Collection
    Dim b As Bookmark
    Dim element As Variant

    If doc Is Nothing Then Exit Sub

    Set nomsSupprimer = New Collection
    For Each b In doc.Bookmarks
        If Left$(b.Name, Len(R12_PREFIXE_ZONE)) = R12_PREFIXE_ZONE Then
            nomsSupprimer.Add b.Name
        End If
    Next b

    For Each element In nomsSupprimer
        doc.Bookmarks(CStr(element)).Delete
    Next element

    debut = 0

    For i = 1 To doc.Paragraphs.Count
        Set p = doc.Paragraphs(i)
        texte = R12_NormaliserZone(p.Range.Text)

        If debut = 0 Then
            If R12_EstFormuleAppel(texte) Then
                debut = p.Range.End
            End If
        Else
            If R12_EstFinCorps(texte) Then
                fin = p.Range.Start
                If fin > debut Then
                    compteur = compteur + 1
                    nom = R12_PREFIXE_ZONE & Format$(compteur, "000")
                    doc.Bookmarks.Add nom, doc.Range(debut, fin)
                End If
                debut = 0
            End If
        End If
    Next i

    If debut > 0 Then
        fin = doc.Content.End - 1
        If fin > debut Then
            compteur = compteur + 1
            nom = R12_PREFIXE_ZONE & Format$(compteur, "000")
            doc.Bookmarks.Add nom, doc.Range(debut, fin)
        End If
    End If
End Sub

Private Function R12_EstFormuleAppel(ByVal t As String) As Boolean

    If Len(t) = 0 Or Len(t) > 90 Then Exit Function

    R12_EstFormuleAppel = _
        Left$(t, 5) = "cher " Or _
        Left$(t, 6) = "chere " Or _
        Left$(t, 9) = "mon cher " Or _
        Left$(t, 9) = "ma chere " Or _
        Left$(t, 14) = "mon tres cher " Or _
        Left$(t, 14) = "ma tres chere " Or _
        t = "cher ami" Or t = "chere amie" Or _
        t = "madame" Or t = "monsieur" Or _
        t = "madame monsieur"
End Function

Private Function R12_EstFinCorps(ByVal t As String) As Boolean

    R12_EstFinCorps = _
        InStr(1, t, "merci de votre confiance", vbTextCompare) > 0 Or _
        InStr(1, t, "je vous remercie de votre confiance", vbTextCompare) > 0 Or _
        InStr(1, t, "je vous prie", vbTextCompare) > 0 Or _
        InStr(1, t, "bien confraternellement", vbTextCompare) > 0 Or _
        t = "amities" Or t = "amitie" Or _
        t = "cordialement" Or _
        InStr(1, t, "docteur olivier mandagout", vbTextCompare) > 0
End Function

Private Function R12_NormaliserZone(ByVal texte As String) As String

    texte = LCase$(texte)
    texte = Replace(texte, ChrW(8217), "'")
    texte = Replace(texte, vbCr, " ")
    texte = Replace(texte, vbLf, " ")
    texte = Replace(texte, vbTab, " ")
    texte = Replace(texte, Chr$(160), " ")

    Do While InStr(1, texte, "  ", vbBinaryCompare) > 0
        texte = Replace(texte, "  ", " ")
    Loop

    texte = Trim$(texte)
    Do While Len(texte) > 0
        If InStr(1, ".,:;!?", Right$(texte, 1), vbBinaryCompare) > 0 Then
            texte = Trim$(Left$(texte, Len(texte) - 1))
        Else
            Exit Do
        End If
    Loop

    R12_NormaliserZone = texte
End Function

Private Sub R12_DefinirVariable( _
    ByVal doc As Document, _
    ByVal nom As String, _
    ByVal valeur As String)

    On Error Resume Next
    doc.Variables(nom).Delete
    On Error GoTo 0
    doc.Variables.Add Name:=nom, Value:=valeur
End Sub

Public Sub R12_Core_TesterZonesMedicales()

    Dim doc As Document
    Dim b As Bookmark
    Dim n As Long

    If Documents.Count = 0 Then
        MsgBox "Aucun document ouvert.", vbExclamation, "R12"
        Exit Sub
    End If

    Set doc = ActiveDocument
    R12_MarquerZonesMedicales doc

    For Each b In doc.Bookmarks
        If Left$(b.Name, Len(R12_PREFIXE_ZONE)) = R12_PREFIXE_ZONE Then
            n = n + 1
        End If
    Next b

    MsgBox CStr(n) & " zone(s) medicale(s) delimitee(s).", _
        IIf(n > 0, vbInformation, vbExclamation), "R12"
End Sub
