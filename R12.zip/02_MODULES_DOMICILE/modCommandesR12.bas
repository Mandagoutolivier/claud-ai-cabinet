Attribute VB_Name = "modCommandesR12"
Option Explicit

'===============================================================================
' R12 - COMMANDES PUBLIQUES VISIBLES DANS ALT+F8
' Module separe afin de ne jamais masquer les macros DDE/RAC R4 validees.
'===============================================================================

Public Sub R12_TesterConfigurationProfils()
    R12_Core_TesterConfigurationProfils
End Sub

Public Sub R12_TesterTousProfils()
    R12_Core_TesterTousProfils
End Sub

Public Sub R12_AfficherCatalogueProfils()
    R12_Core_AfficherCatalogueProfils
End Sub

Public Sub R12_OuvrirDossierProfils()
    R12_Core_OuvrirDossierProfils
End Sub

Public Sub R12_OuvrirProfil()
    R12_Core_OuvrirProfil
End Sub

Public Sub R12_TesterPlanEtPrompt()
    R12_Core_TesterPlanEtPrompt
End Sub

Public Sub R12_TesterAssemblageProfil()
    R12_Core_TesterAssemblageProfil
End Sub

Public Sub R12_TesterRevisionFinale()
    R12_Core_TesterRevisionFinale
End Sub

Public Sub R12_TesterZonesMedicales()
    R12_Core_TesterZonesMedicales
End Sub
