@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp004_INSTALLER_R12_VALIDE_AU_CABINET.ps1"
pause
