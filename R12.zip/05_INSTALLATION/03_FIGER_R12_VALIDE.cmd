@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp003_FIGER_R12_VALIDE.ps1"
pause
