@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp007_RESTAURER_NORMAL_PRECEDENT.ps1"
pause
