﻿$ErrorActionPreference = 'Stop'
$backupDir='C:\ModeleCourrierChatGPT_TEST\SAUVEGARDES_NORMAL'
$normalPath=Join-Path $env:APPDATA 'Microsoft\Templates\Normal.dotm'
if(Get-Process WINWORD -ErrorAction SilentlyContinue){ throw 'Word est encore ouvert.' }
$files=@(Get-ChildItem $backupDir -Filter '*.dotm' | Sort-Object LastWriteTime -Descending)
if($files.Count -eq 0){ throw 'Aucune sauvegarde Normal.dotm.' }
for($i=0;$i -lt $files.Count;$i++){ Write-Host "[$($i+1)] $($files[$i].Name)" }
$rep=Read-Host 'Numero a restaurer'; $n=0
if(-not [int]::TryParse($rep,[ref]$n) -or $n -lt 1 -or $n -gt $files.Count){ throw 'Choix invalide.' }
Copy-Item -LiteralPath $files[$n-1].FullName -Destination $normalPath -Force
Write-Host "Normal.dotm restaure : $($files[$n-1].FullName)" -ForegroundColor Green
