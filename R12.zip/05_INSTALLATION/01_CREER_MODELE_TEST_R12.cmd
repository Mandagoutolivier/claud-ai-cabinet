@echo off
if not exist "%~dp001_CREER_MODELE_TEST_R12.ps1" (
  echo ERREUR : le script PS1 est introuvable.
  echo Decompressez entierement R12.zip avec "Extraire tout".
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp001_CREER_MODELE_TEST_R12.ps1"
pause
