@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp005_RESTAURER_MODELE_PRECEDENT.ps1"
pause
