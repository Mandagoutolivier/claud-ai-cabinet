﻿$ErrorActionPreference = 'Stop'
$workModel = 'C:\ModeleCourrierChatGPT_TEST\ModeleCourrierChatGPT_TEST_R12_PROFILS_3_API.dotm'
$validatedDir = 'C:\ModeleCourrierChatGPT_TEST\VALIDE'
$validatedModel = Join-Path $validatedDir 'ModeleCourrierChatGPT_R12_PROFILS_3_API_VALIDE.dotm'
$hashFile = Join-Path $validatedDir 'ModeleCourrierChatGPT_R12_PROFILS_3_API_VALIDE.sha256.txt'
if (Get-Process WINWORD -ErrorAction SilentlyContinue) { throw 'Word est encore ouvert.' }
if (-not (Test-Path -LiteralPath $workModel)) { throw "Modele TEST introuvable : $workModel" }
New-Item -ItemType Directory -Force -Path $validatedDir | Out-Null
Copy-Item -LiteralPath $workModel -Destination $validatedModel -Force
$hash=(Get-FileHash -LiteralPath $validatedModel -Algorithm SHA256).Hash
@("SHA256=$hash","FILE=$validatedModel","DATE=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')") | Set-Content -LiteralPath $hashFile -Encoding ASCII
Write-Host "Modele R12 fige : $validatedModel" -ForegroundColor Green
Write-Host "SHA256 : $hash" -ForegroundColor Cyan
