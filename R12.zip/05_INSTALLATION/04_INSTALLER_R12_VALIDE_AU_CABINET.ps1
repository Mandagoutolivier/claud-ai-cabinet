﻿$ErrorActionPreference = 'Stop'
$validatedModel = 'C:\ModeleCourrierChatGPT_TEST\VALIDE\ModeleCourrierChatGPT_R12_PROFILS_3_API_VALIDE.dotm'
$startupDir = Join-Path $env:APPDATA 'Microsoft\Word\STARTUP'
$target = Join-Path $startupDir 'ModeleCourrierChatGPT_PROD.dotm'
$backupDir = 'C:\ModeleCourrierChatGPT_TEST\SAUVEGARDES_CABINET'
if (Get-Process WINWORD -ErrorAction SilentlyContinue) { throw 'Word est encore ouvert.' }
if (-not (Test-Path -LiteralPath $validatedModel)) { throw "Modele valide introuvable : $validatedModel" }
if (-not (Test-Path -LiteralPath '\\DS224\home')) { throw 'Le NAS DS224 est inaccessible.' }
New-Item -ItemType Directory -Force -Path $startupDir,$backupDir | Out-Null
if (Test-Path -LiteralPath $target) {
  $stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
  $backup=Join-Path $backupDir ("ModeleCourrierChatGPT_PROD_AVANT_R12_"+$stamp+".dotm")
  Copy-Item -LiteralPath $target -Destination $backup -Force
  Write-Host "Sauvegarde : $backup"
}
$src=(Get-FileHash -LiteralPath $validatedModel -Algorithm SHA256).Hash
Copy-Item -LiteralPath $validatedModel -Destination $target -Force
$dst=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
if ($src -ne $dst) { throw 'Le fichier installe n est pas identique au modele valide.' }
Write-Host "Meme DOTM R12 installe au cabinet : $target" -ForegroundColor Green
Write-Host "SHA256 : $dst" -ForegroundColor Cyan
