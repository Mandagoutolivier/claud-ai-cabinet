@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp002_ACTIVER_MODELE_TEST_R12.ps1"
pause
