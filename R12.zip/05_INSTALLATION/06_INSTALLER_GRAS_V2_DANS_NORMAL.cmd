@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp006_INSTALLER_GRAS_V2_DANS_NORMAL.ps1"
pause
