﻿$ErrorActionPreference = 'Stop'
$workModel = 'C:\ModeleCourrierChatGPT_TEST\ModeleCourrierChatGPT_TEST_R12_PROFILS_3_API.dotm'
$startupDir = Join-Path $env:APPDATA 'Microsoft\Word\STARTUP'
$target = Join-Path $startupDir 'ModeleCourrierChatGPT_PROD.dotm'
$backupDir = 'C:\ModeleCourrierChatGPT_TEST\SAUVEGARDES'
if (Get-Process WINWORD -ErrorAction SilentlyContinue) { throw 'Word est encore ouvert.' }
if (-not (Test-Path -LiteralPath $workModel)) { throw "Modele TEST introuvable : $workModel" }
New-Item -ItemType Directory -Force -Path $startupDir,$backupDir | Out-Null
if (Test-Path -LiteralPath $target) {
  $stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
  $backup=Join-Path $backupDir ("ModeleCourrierChatGPT_AVANT_R12_"+$stamp+".dotm")
  Copy-Item -LiteralPath $target -Destination $backup -Force
  Write-Host "Sauvegarde : $backup"
}
Copy-Item -LiteralPath $workModel -Destination $target -Force
$src=(Get-FileHash -LiteralPath $workModel -Algorithm SHA256).Hash
$dst=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
if ($src -ne $dst) { throw 'La copie dans STARTUP n est pas identique.' }
Write-Host "R12 active : $target" -ForegroundColor Green
Write-Host "SHA256 : $dst" -ForegroundColor Cyan
