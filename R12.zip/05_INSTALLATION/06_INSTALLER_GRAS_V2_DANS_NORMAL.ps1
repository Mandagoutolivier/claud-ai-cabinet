﻿$ErrorActionPreference = 'Stop'

function Step([string]$Text) { Write-Host "`n=== $Text ===" -ForegroundColor Cyan }
function Get-Component([object]$Project,[string]$Name) { try { return $Project.VBComponents.Item($Name) } catch { return $null } }
function Assert-PublicMacros([object]$Project,[string]$ModuleName,[string[]]$Names) {
  $component=Get-Component $Project $ModuleName
  if ($null -eq $component) { throw "Module absent : $ModuleName" }
  $code=$component.CodeModule.Lines(1,$component.CodeModule.CountOfLines)
  foreach($name in $Names) {
    $pattern='(?mi)^\s*Public\s+Sub\s+'+[regex]::Escape($name)+'\s*\(\s*\)'
    if($code -notmatch $pattern) { throw "Macro publique absente : $name" }
  }
}

$packageRoot=Split-Path -Parent $PSScriptRoot
$srcModule=Join-Path $packageRoot '03_SECRETARIAT\modSecretariatGrasV2.bas'
$srcForm=Join-Path $packageRoot '03_SECRETARIAT\frmSECGrasV2.frm'
$normalPath=Join-Path $env:APPDATA 'Microsoft\Templates\Normal.dotm'
$backupDir='C:\ModeleCourrierChatGPT_TEST\SAUVEGARDES_NORMAL'
$report='C:\ModeleCourrierChatGPT_TEST\RAPPORT_INSTALLATION_GRAS_V2.txt'
$publicSec=@(
    'SEC_ValiderGrasSansImprimer',
    'SEC_MettreEnGras',
    'SEC_ValiderEtFermer',
    'SEC_ImprimerAvecValidation',
    'FilePrint',
    'SEC_ImpressionRapideAvecValidation',
    'FilePrintDefault',
    'SEC_InstallerRaccourcisGrasV2',
    'SEC_InstallerInterceptionImpression',
    'SEC_VerifierInstallation',
    'SEC_TesterInstallation',
    'SEC_TesterDialogue',
    'SEC_DiagnostiquerGrasInconnus'
)

if (Get-Process WINWORD -ErrorAction SilentlyContinue) { throw 'Word est encore ouvert.' }
if (-not (Test-Path -LiteralPath $srcModule)) { throw "Module absent : $srcModule" }
if (-not (Test-Path -LiteralPath $srcForm)) { throw "Formulaire absent : $srcForm" }
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
if (Test-Path -LiteralPath $normalPath) {
  $stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
  Copy-Item -LiteralPath $normalPath -Destination (Join-Path $backupDir ("Normal_AVANT_GRAS_V2_"+$stamp+".dotm")) -Force
}

$securityKey='HKCU:\Software\Microsoft\Office\16.0\Word\Security'
$old=$null; $oldExists=$false
try { $old=(Get-ItemProperty -Path $securityKey -Name AccessVBOM -ErrorAction Stop).AccessVBOM; $oldExists=$true } catch {}
New-Item -Path $securityKey -Force | Out-Null
New-ItemProperty -Path $securityKey -Name AccessVBOM -Value 1 -PropertyType DWord -Force | Out-Null

$word=$null
try {
  Step 'Injection dans Normal.dotm'
  $word=New-Object -ComObject Word.Application
  $word.Visible=$false
  $word.DisplayAlerts=0
  $project=$word.NormalTemplate.VBProject
  if($project.Protection -ne 0) { throw 'Le projet Normal est protege.' }

  foreach($name in @('modSecretariatValidation','modSecretariatGrasV2','frmSECGrasV2')) {
    $c=Get-Component $project $name
    if($null -ne $c) { $project.VBComponents.Remove($c) }
  }
  $m=$project.VBComponents.Import($srcModule)
  if($m.Name -ne 'modSecretariatGrasV2') { throw "Nom module importe incorrect : $($m.Name)" }
  $f=$project.VBComponents.Import($srcForm)
  if($f.Name -ne 'frmSECGrasV2') { throw "Nom formulaire importe incorrect : $($f.Name)" }
  Assert-PublicMacros $project 'modSecretariatGrasV2' $publicSec
  $word.NormalTemplate.Save()
  $word.Quit(); $word=$null

  Step 'Controle apres reouverture'
  $word=New-Object -ComObject Word.Application
  $word.Visible=$false
  $word.DisplayAlerts=0
  $project=$word.NormalTemplate.VBProject
  Assert-PublicMacros $project 'modSecretariatGrasV2' $publicSec
  if($null -eq (Get-Component $project 'frmSECGrasV2')) { throw 'Formulaire absent apres reouverture.' }
  @(
    'INSTALLATION GRAS V2 DANS NORMAL.DOTM',
    ('Date : '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')),
    'Module : OK',
    'Formulaire : OK',
    ('Macros publiques : '+$publicSec.Count+'/'+$publicSec.Count),
    '',
    'ETAPE MANUELLE : ouvrir Word, compiler Normal, puis lancer SEC_InstallerRaccourcisGrasV2.'
  ) | Set-Content -LiteralPath $report -Encoding UTF8
  $word.Quit(); $word=$null
}
finally {
  if($null -ne $word) { try { $word.Quit() } catch {} }
  [GC]::Collect(); [GC]::WaitForPendingFinalizers()
  if($oldExists) { New-ItemProperty -Path $securityKey -Name AccessVBOM -Value $old -PropertyType DWord -Force | Out-Null }
  else { Remove-ItemProperty -Path $securityKey -Name AccessVBOM -ErrorAction SilentlyContinue }
}

Step 'Gras V2 installe dans Normal.dotm'
Write-Host 'Ouvrez Word : Alt+F11 > Compiler Normal > Enregistrer.' -ForegroundColor Yellow
Write-Host 'Puis lancez SEC_InstallerRaccourcisGrasV2 et SEC_VerifierInstallation.' -ForegroundColor Yellow
