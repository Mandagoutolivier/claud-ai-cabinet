﻿$ErrorActionPreference = 'Stop'

function Step([string]$Text) {
    Write-Host "`n=== $Text ===" -ForegroundColor Cyan
}

function Get-VbaModuleName([string]$Path) {
    $enc = [System.Text.Encoding]::GetEncoding(1252)
    $txt = [System.IO.File]::ReadAllText($Path, $enc)
    $m = [regex]::Match($txt, '(?m)^Attribute VB_Name = "([^"]+)"')
    if (-not $m.Success) { throw "Nom VBA introuvable dans $Path" }
    return $m.Groups[1].Value
}

function Get-Component([object]$Project, [string]$Name) {
    try { return $Project.VBComponents.Item($Name) } catch { return $null }
}

function Assert-PublicMacros([object]$Project, [string]$ModuleName, [string[]]$Names) {
    $component = Get-Component $Project $ModuleName
    if ($null -eq $component) { throw "Module public absent : $ModuleName" }
    $codeModule = $component.CodeModule
    $code = $codeModule.Lines(1, $codeModule.CountOfLines)
    if ($code -match '(?mi)^\s*Option\s+Private\s+Module\s*$') {
        throw "Le module $ModuleName contient Option Private Module."
    }
    foreach ($name in $Names) {
        $pattern = '(?mi)^\s*Public\s+Sub\s+' + [regex]::Escape($name) + '\s*\(\s*\)'
        if ($code -notmatch $pattern) { throw "Macro publique absente : $name" }
    }
}

function Merge-AnsiLines([string]$Source, [string]$Destination) {
    $enc = [System.Text.Encoding]::GetEncoding(1252)
    if (-not (Test-Path -LiteralPath $Destination)) {
        Copy-Item -LiteralPath $Source -Destination $Destination -Force
        return
    }
    $destText = [System.IO.File]::ReadAllText($Destination, $enc)
    $srcText = [System.IO.File]::ReadAllText($Source, $enc)
    $existing = @{}
    foreach ($line in ($destText -replace "`r`n", "`n" -replace "`r", "`n" -split "`n")) {
        $v = $line.Trim()
        if ($v -ne '') { $existing[$v.ToLowerInvariant()] = $true }
    }
    $lines = New-Object System.Collections.Generic.List[string]
    foreach ($line in ($destText -replace "`r`n", "`n" -replace "`r", "`n" -split "`n")) {
        if ($line -ne '') { [void]$lines.Add($line) }
    }
    foreach ($line in ($srcText -replace "`r`n", "`n" -replace "`r", "`n" -split "`n")) {
        $v = $line.Trim()
        if ($v -ne '' -and -not $existing.ContainsKey($v.ToLowerInvariant())) {
            [void]$lines.Add($v)
            $existing[$v.ToLowerInvariant()] = $true
        }
    }
    [System.IO.File]::WriteAllText($Destination, (($lines -join "`r`n") + "`r`n"), $enc)
}

$packageRoot = Split-Path -Parent $PSScriptRoot
$baseModel = Join-Path $packageRoot '01_BASE_VALIDEE\ModeleCourrierChatGPT_PROD_VALIDEE_POINT_DE_DEPART.dotm'
$modulesDir = Join-Path $packageRoot '02_MODULES_DOMICILE'
$dicoDir = Join-Path $packageRoot '04_DICTIONNAIRES_INITIAUX'
$profilesSource = Join-Path $packageRoot '04_PROFILS_EXAMENS'
$workRoot = 'C:\ModeleCourrierChatGPT_TEST'
$workModel = Join-Path $workRoot 'ModeleCourrierChatGPT_TEST_R12_PROFILS_3_API.dotm'
$reportPath = Join-Path $workRoot 'RAPPORT_INSTALLATION_R12.txt'
$outputDir = '\\DS224\home\sortiedragon'
$nasConfig = '\\DS224\home\logiciel_chatgpt_cabinet'
$profilesTarget = Join-Path $nasConfig 'profils_examens'

$requiredModules = @(
    @{ File = 'modAnonymisation_DOUBLE_API_DETAILLE_1_UNC_HF1.bas'; Name = 'modAnonymisation' },
    @{ File = 'modCommandesDDERAC_R12_DIRECT_GRAS_V2.bas'; Name = 'modCommandesDDERAC' },
    @{ File = 'modCommandesR12.bas'; Name = 'modCommandesR12' },
    @{ File = 'modDemandesStructureesR12.bas'; Name = 'modDemandesStructureesR12' },
    @{ File = 'modDetectionDemandesDico_DDE2_R4_CORE.bas'; Name = 'modDetectionDemandesDico' },
    @{ File = 'modGenerationDemandes_DOUBLE_API_DETAILLE_1_UNC_HF1.bas'; Name = 'modGenerationDemandes' },
    @{ File = 'modMoteurLettresProfilsR12.bas'; Name = 'modMoteurLettresProfilsR12' },
    @{ File = 'modNormalisationGrasLocal_DOUBLE_API_DETAILLE_1_UNC.bas'; Name = 'modNormalisationGrasLocal' },
    @{ File = 'modProdRapide_R12_PROFILS_3_API.bas'; Name = 'modProdRapide' },
    @{ File = 'modProfilsExamensR12.bas'; Name = 'modProfilsExamensR12' },
    @{ File = 'modPrompts_R12_PROFILS_3_API.bas'; Name = 'modPrompts' },
    @{ File = 'modRevisionFinaleR12.bas'; Name = 'modRevisionFinaleR12' },
    @{ File = 'modSortieDragon_DOUBLE_API_DETAILLE_1_UNC.bas'; Name = 'modSortieDragon' },
    @{ File = 'modZonesMedicalesR12.bas'; Name = 'modZonesMedicalesR12' },
    @{ File = 'module_API_OpenAI_R12_PROFILS_3_API.bas'; Name = 'modOpenAI_v22_corrige' }
)

$publicDde = @(
    'DDE_AjouterDeclencheurSelection',
    'DDE_AjouterExamenSelection',
    'DDE_AjouterExclusionSelection',
    'DDE_TesterConfiguration',
    'DDE_TesterFormulationsInitiales',
    'DDE_TesterFauxPositifs'
)
$publicRac = @(
    'RAC_InstallerRaccourcis',
    'RAC_GrasSelection',
    'RAC_ValiderGras',
    'RAC_AjouterDeclencheur',
    'RAC_AjouterExamen',
    'RAC_AjouterExclusion',
    'RAC_InstallerCtrlPSecretariat',
    'RAC_AfficherRaccourcis',
    'RAC_VerifierMacrosDDEEtRAC',
    'RAC_SupprimerRaccourcis'
)
$publicR12 = @(
    'R12_TesterConfigurationProfils',
    'R12_TesterTousProfils',
    'R12_AfficherCatalogueProfils',
    'R12_OuvrirDossierProfils',
    'R12_OuvrirProfil',
    'R12_TesterPlanEtPrompt',
    'R12_TesterAssemblageProfil',
    'R12_TesterRevisionFinale',
    'R12_TesterZonesMedicales'
)

Step 'Verification du paquet R12'
if (-not (Test-Path -LiteralPath $baseModel)) { throw "Modele de base absent : $baseModel" }
$baseHash = (Get-FileHash -LiteralPath $baseModel -Algorithm SHA256).Hash
if ($baseHash -ne 'FBA23464FF5BEDD46E644A0A729C6F0350179CD24CDD115F0E7BDD0D025B8D26') {
    throw "Le DOTM de base n'est pas la production R7 attendue. SHA256=$baseHash"
}
foreach ($item in $requiredModules) {
    $path = Join-Path $modulesDir $item.File
    if (-not (Test-Path -LiteralPath $path)) { throw "Module absent : $path" }
    $actualName = Get-VbaModuleName $path
    if ($actualName -ne $item.Name) {
        throw "Nom VBA incorrect pour $($item.File) : $actualName au lieu de $($item.Name)"
    }
}
$unexpected = @(Get-ChildItem $modulesDir -Filter '*.bas' | Where-Object {
    -not ($requiredModules.File -contains $_.Name)
})
if ($unexpected.Count -gt 0) { throw "Modules inattendus : $($unexpected.Name -join ', ')" }
$profileCount = @(Get-ChildItem $profilesSource -Filter '*.ini').Count
if ($profileCount -ne 32) { throw "Nombre de profils inattendu : $profileCount au lieu de 32" }

Step 'Verification que Word est ferme'
if (Get-Process WINWORD -ErrorAction SilentlyContinue) { throw 'Word est encore ouvert.' }

Step 'Verification du NAS DS224'
if (-not (Test-Path -LiteralPath '\\DS224\home')) {
    throw "Le NAS DS224 n'est pas accessible. Verifiez le reseau ou le VPN."
}

New-Item -ItemType Directory -Force -Path $workRoot | Out-Null
New-Item -ItemType Directory -Force -Path $outputDir | Out-Null
Copy-Item -LiteralPath $baseModel -Destination $workModel -Force

Step 'Preparation des dictionnaires partages'
New-Item -ItemType Directory -Force -Path $nasConfig | Out-Null
foreach ($name in @('medicaments.txt','termes_gras.txt','journal_apprentissage.txt')) {
    $src = Join-Path $dicoDir $name
    $dst = Join-Path $nasConfig $name
    if (-not (Test-Path -LiteralPath $dst)) {
        Copy-Item -LiteralPath $src -Destination $dst -Force
        Write-Host "Cree : $dst"
    } else { Write-Host "Conserve : $dst" }
}
foreach ($name in @('declencheurs_demandes.txt','examens_complementaires.txt','exclusions_demandes.txt')) {
    Merge-AnsiLines (Join-Path $dicoDir $name) (Join-Path $nasConfig $name)
    Write-Host "Fusionne sans suppression : $name"
}

Step 'Installation des 32 profils R12 sur le NAS'
New-Item -ItemType Directory -Force -Path $profilesTarget | Out-Null
$existingProfiles = @(Get-ChildItem $profilesTarget -Filter '*.ini' -ErrorAction SilentlyContinue)
if ($existingProfiles.Count -gt 0) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $backup = Join-Path $nasConfig ("SAUVEGARDE_PROFILS_AVANT_R12_" + $stamp)
    New-Item -ItemType Directory -Force -Path $backup | Out-Null
    Copy-Item -Path (Join-Path $profilesTarget '*.ini') -Destination $backup -Force
    Write-Host "Sauvegarde profils : $backup"
}
Copy-Item -Path (Join-Path $profilesSource '*.ini') -Destination $profilesTarget -Force
Write-Host "Profils R12 installes : $profileCount"

$securityKey = 'HKCU:\Software\Microsoft\Office\16.0\Word\Security'
$oldAccessVbom = $null
$oldExists = $false
try {
    $oldAccessVbom = (Get-ItemProperty -Path $securityKey -Name AccessVBOM -ErrorAction Stop).AccessVBOM
    $oldExists = $true
} catch { $oldExists = $false }

Step 'Autorisation temporaire VBOM'
New-Item -Path $securityKey -Force | Out-Null
New-ItemProperty -Path $securityKey -Name AccessVBOM -Value 1 -PropertyType DWord -Force | Out-Null

$word = $null
$doc = $null
try {
    Step 'Injection des 15 modules R12 avec Microsoft Word'
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($workModel, $false, $false)
    $project = $doc.VBProject
    if ($project.Protection -ne 0) { throw 'Projet VBA protege.' }

    $legacyNames = @(
        'modCommandesR11','modDemandesStructureesR8','modDemandesStructureesR10',
        'modProfilsExamensR11','modMoteurLettresProfilsR11',
        'modParagraphesDemandesR10','modRevisionFinaleR12','modZonesMedicalesR12',
        'modCommandesR12','modDemandesStructureesR12','modProfilsExamensR12',
        'modMoteurLettresProfilsR12'
    )
    foreach ($legacyName in $legacyNames) {
        $legacy = Get-Component $project $legacyName
        if ($null -ne $legacy -and $legacy.Type -eq 1) { $project.VBComponents.Remove($legacy) }
    }

    foreach ($item in $requiredModules) {
        $modulePath = Join-Path $modulesDir $item.File
        $existing = Get-Component $project $item.Name
        if ($null -ne $existing) {
            if ($existing.Type -ne 1) { throw "$($item.Name) n'est pas un module standard." }
            $project.VBComponents.Remove($existing)
        }
        $imported = $project.VBComponents.Import($modulePath)
        if ($imported.Name -ne $item.Name) { throw "Import incorrect : $($item.File) -> $($imported.Name)" }
        Write-Host "Installe : $($item.Name)"
    }

    Assert-PublicMacros $project 'modCommandesDDERAC' ($publicDde + $publicRac)
    Assert-PublicMacros $project 'modCommandesR12' $publicR12

    $doc.Save()
    $doc.Close(-1)
    $doc = $null
    $word.Quit()
    $word = $null

    Step 'Reouverture et controle apres enregistrement'
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($workModel, $false, $false)
    $project = $doc.VBProject
    foreach ($item in $requiredModules) {
        if ($null -eq (Get-Component $project $item.Name)) { throw "Module absent apres reouverture : $($item.Name)" }
    }
    Assert-PublicMacros $project 'modCommandesDDERAC' ($publicDde + $publicRac)
    Assert-PublicMacros $project 'modCommandesR12' $publicR12

    $report = @()
    $report += 'INSTALLATION R12 PROFILS 3 API'
    $report += ('Date : ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    $report += ('Modele : ' + $workModel)
    $report += ('Base SHA256 : ' + $baseHash)
    $report += ''
    $report += 'MODULES : 15/15'
    foreach ($item in $requiredModules) { $report += ('OK - ' + $item.Name) }
    $report += ''
    $report += 'MACROS DDE : 6/6'
    foreach ($name in $publicDde) { $report += ('OK - ' + $name) }
    $report += 'MACROS RAC : 10/10'
    foreach ($name in $publicRac) { $report += ('OK - ' + $name) }
    $report += 'MACROS R12 : 9/9'
    foreach ($name in $publicR12) { $report += ('OK - ' + $name) }
    $report += ('PROFILS R12 : ' + $profileCount + '/32')
    $report | Set-Content -LiteralPath $reportPath -Encoding UTF8

    $doc.Close(0)
    $doc = $null
    $word.Quit()
    $word = $null
}
finally {
    if ($null -ne $doc) { try { $doc.Close(0) } catch {} }
    if ($null -ne $word) { try { $word.Quit() } catch {} }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    if ($oldExists) {
        New-ItemProperty -Path $securityKey -Name AccessVBOM -Value $oldAccessVbom -PropertyType DWord -Force | Out-Null
    } else {
        Remove-ItemProperty -Path $securityKey -Name AccessVBOM -ErrorAction SilentlyContinue
    }
}

Step 'Modele TEST R12 cree et controle'
Write-Host "Fichier : $workModel" -ForegroundColor Green
Write-Host "Rapport : $reportPath" -ForegroundColor Green
Write-Host 'Controle : 15 modules, 6 DDE, 10 RAC, 9 R12, 32 profils.' -ForegroundColor Green
Write-Host 'Ouvrez le modele, puis Alt+F11 > Debogage > Compiler TemplateProject > Ctrl+S.' -ForegroundColor Yellow
